# GameBrain (Part 5 — Final Polish & Safety)

GameBrain is a game-performance-optimizer Android app. **This is Part 5**,
the final pass on top of Part 4 (automatic detection, profiles, optimization
actions, notification, Quick Settings Tile): reliability hardening, an
optional overlay, and cleanup.

## Project facts

| | |
|---|---|
| App name | GameBrain |
| Package name | `com.gamebrain.optimizer` |
| Min SDK | 26 (Android 8.0) |
| Target SDK | 34 |
| Language | Kotlin |
| UI toolkit | Jetpack Compose (Material 3) |
| Build system | Gradle (Kotlin DSL) |
| Version | 1.4 (versionCode 5) |

## ⚠️ Known issue in this build: the Gradle wrapper jar is missing

`gradle/wrapper/gradle-wrapper.jar` was never committed to the Part 4 project
(only `gradle-wrapper.properties` is present). Without that jar, running
`./gradlew` locally fails immediately — this isn't something Part 5 broke,
it was already missing. I don't have network access in the environment I
used to do this work, so I couldn't fetch the real binary jar to fix it
directly.

**It's handled two ways:**

1. **CI doesn't need it.** `.github/workflows/android-build.yml` uses
   `gradle/actions/setup-gradle`, which provisions its own Gradle 8.7 and
   builds with a plain `gradle assembleDebug` — no wrapper jar required. This
   satisfies "buildable in GitHub Actions" as asked.
2. **Fix it locally in one command**, once you have Android Studio or any
   machine with Gradle/network access:
   ```bash
   gradle wrapper --gradle-version 8.7 --distribution-type bin
   ```
   This regenerates `gradle-wrapper.jar` correctly. Commit it, and
   `./gradlew assembleDebug` will work from then on. (Opening the project in
   Android Studio also regenerates it automatically on first sync.)

## Building

```bash
./gradlew assembleDebug     # once the wrapper jar above is restored
# or, if you have Gradle installed and don't want to bother with the wrapper:
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`

GitHub Actions builds the debug APK on every push/PR
(`.github/workflows/android-build.yml`) and uploads it as a workflow
artifact, along with a freshly regenerated `gradle-wrapper.jar` you can pull
back into the repo if you want `./gradlew` to work without running the
command above yourself.

## Required setup (on-device)

1. **Shizuku** — install, start (wireless debugging or root), grant
   GameBrain permission from the Home screen.
2. **Accessibility Service** — primary foreground-app detection.
3. **Usage Access** — backup detection if Accessibility is ever off.
4. **Notifications** — granted on first launch (Android 13+) for the status
   notification.
5. **Display Over Other Apps** — only needed if you turn on the optional
   overlay.
6. Mark apps as games on the **Games** tab and assign a profile.

## What GameBrain controls vs. TMPAD vs. Hail

| App | Responsibility |
|---|---|
| **GameBrain** | Refresh rate, animations, battery-saver/optimization exemptions, touch latency, light force-stop of background apps, restore |
| **TMPAD** | Resolution + FPS cap only |
| **Hail** | Strong freezing (optional, triggered separately — not wired up here) |

GameBrain never reads or writes resolution or FPS-cap settings, and never
triggers freezing. No networking/DNS features are included, by design.

## Fully automatic flow

1. Accessibility Service detects a marked game entering the foreground.
2. `OptimizationManager` snapshots current system settings, then applies the
   assigned profile.
3. When the game leaves the foreground, GameBrain waits ~700 ms (to absorb
   transient dialogs / notification-shade pulls / app switches), then
   restores every modified setting to its pre-game value.

## User control

- **Persistent notification** — "Restore Now" and "Stop" actions.
- **Quick Settings Tile** — toggle automatic optimization on/off.
- **Home screen "Automatic Optimization" card** — the same on/off switch,
  a **Restore Everything Now** button, and (new in Part 5) a
  **Force Restore** button for when the normal restore didn't take.
- **Home screen "Performance Overlay" card** (new in Part 5) — turn the
  floating FPS/RAM indicator on or off.

## What's new in Part 5

### Stability & reliability
- **Restore survives a killed process.** Previously, the snapshot of
  "what to restore" only lived in memory — if the app was killed while a
  game was being optimized, that snapshot was gone and the device could be
  left permanently on the optimized settings. It's now persisted to
  `SharedPreferences` on apply and cleared on restore, and reloaded on
  startup, so GameBrain picks up exactly where it left off (see
  `OptimizationManager.persistSession` / `loadSession`).
- **Force Restore** (`OptimizationManager.forceRestore`) retries a few times
  against Shizuku with short delays, for the case where Shizuku itself was
  killed or is still reconnecting. If it genuinely can't reach the device
  after retrying, it clears local state and tells you plainly to check
  refresh rate / animation / battery-saver settings by hand — it never
  leaves the UI silently stuck saying "Optimizing" forever.
- **Apply/restore are now exception-safe.** A failure partway through a
  sequence of `settings put` calls no longer leaves the app's internal state
  out of sync with reality — the active-session bookkeeping is set *before*
  mutating anything and only cleared on a real restore, so Restore Now /
  Force Restore stay available even after a partial failure.
- **Accessibility Service hardening.** `onServiceConnected` and
  `onAccessibilityEvent` are now wrapped so a wiring or event-parsing
  problem degrades detection (falls back to the Usage Access poll) instead
  of crashing. If Accessibility is disabled entirely, nothing in the rest
  of the app assumes it's running — the UI and background services still
  work, they just won't see foreground-app changes from that source.
- **Shizuku disconnects** were already handled in Part 4 (pending
  apply/restore, auto-retry on reconnect) and remain unchanged.

### Optional performance overlay
- New `overlay/GameBrainOverlayService.kt` — a small, non-touchable floating
  text box showing an approximate frame-timing reading and current RAM
  usage (`used/total GB`), updated once per second.
- **Honesty note on FPS**: Android doesn't expose the *foreground game's*
  real frame rate to a third-party app without root/GPU instrumentation.
  What's shown is the system's own vsync-driven frame timing via
  `Choreographer` — a reasonable "is the device keeping up" proxy, not a
  frame-accurate in-game counter. This is stated in the overlay card in-app
  too, not just buried here.
- Toggle lives on the Home screen, disabled until "Display Over Other Apps"
  is granted, and the setting is persisted (`overlay/OverlaySettings.kt`) so
  it resumes automatically after a restart if it was left on and the
  permission is still granted.
- Deliberately minimal (one `TextView`, no animation, 1 Hz update) so it
  doesn't cost the frame budget it's reporting on.

### GitHub Actions
- `.github/workflows/android-build.yml` builds the debug APK on every
  push/PR using `gradle/actions/setup-gradle`, which sidesteps the missing
  wrapper jar (see the warning above) and also regenerates it as a
  downloadable artifact.

### What I did *not* do, and why
Given the size of this ask, here's what's honestly out of scope for this
pass rather than silently skipped:
- **No fresh gradle build was run against this code** — the sandbox I did
  this work in has no network access, so I couldn't invoke Gradle at all to
  confirm a clean compile. Everything here was written and manually
  reviewed for correctness, and the existing Part 4 code this builds on was
  already coherent, but you should treat the very first CI run (or your
  first local build once the wrapper is restored) as the real compile
  check, not a formality.
- **No full string-resource pass.** UI text in the Compose screens was
  already inline string literals in Part 4, not `strings.xml` references;
  I added new strings inline consistently with that existing pattern rather
  than doing a one-off partial migration. A full move to `strings.xml`
  (useful mainly if you ever localize) is a bigger, separate job.
- **No broad "debug log" cull.** The existing `Log.d/i/w/e` calls are
  sparse and informative (state transitions, failures), not verbose spam —
  I left them as-is rather than remove logging that's actually useful for
  diagnosing exactly the kind of Shizuku/Accessibility issues this part is
  supposed to harden against.

## Project structure (key additions in Part 5)

```
app/src/main/java/com/gamebrain/optimizer/
├── optimization/
│   └── OptimizationManager.kt   # + persisted session, forceRestore(),
│                                #   exception-safe apply/restore
├── overlay/                     # NEW
│   ├── GameBrainOverlayService.kt
│   └── OverlaySettings.kt
├── service/
│   └── GameBrainAccessibilityService.kt  # + try/catch hardening
└── ui/
    └── HomeScreen.kt            # + Force Restore button, Overlay card
.github/workflows/android-build.yml   # NEW
```

### Intentionally NOT implemented
- Resolution scaling / FPS capping (TMPAD only)
- Strong freezing (Hail's optional trigger)
- Networking / DNS features (out of scope per spec)
