@rem
@rem Standard Gradle wrapper launcher script (Windows).
@rem
@rem Requires gradle\wrapper\gradle-wrapper.jar, which is not included in
@rem this project (see README.md for why, and how to generate it once).
@rem

@echo off
setlocal

set DIRNAME=%~dp0
set APP_HOME=%DIRNAME%

set CLASSPATH=%APP_HOME%gradle\wrapper\gradle-wrapper.jar

if not exist "%CLASSPATH%" (
  echo ERROR: %CLASSPATH% not found.
  echo Run "gradle wrapper --gradle-version 8.7" once ^(with a local Gradle install^)
  echo or open this project in Android Studio and let it generate the wrapper jar.
  exit /b 1
)

if defined JAVA_HOME (
  set JAVA_EXE=%JAVA_HOME%\bin\java.exe
) else (
  set JAVA_EXE=java.exe
)

"%JAVA_EXE%" -Xmx64m -Xms64m -classpath "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*

endlocal
