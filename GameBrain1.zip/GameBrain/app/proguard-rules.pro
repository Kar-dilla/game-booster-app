# Add project specific ProGuard rules here.
# Empty for Part 1 — no obfuscation-sensitive code yet.
