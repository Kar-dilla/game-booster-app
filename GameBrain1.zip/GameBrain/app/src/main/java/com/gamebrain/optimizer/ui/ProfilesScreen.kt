package com.gamebrain.optimizer.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.gamebrain.optimizer.data.Profile

/**
 * Read-only view of the four built-in profiles and the concrete tweaks each
 * one applies (see OptimizationManager for the implementation).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfilesScreen() {
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Profiles") })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Built-in profiles",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "Assign a profile to each game on the Games screen. " +
                    "GameBrain applies these automatically when the game is foregrounded " +
                    "and restores your previous settings when you leave.",
                style = MaterialTheme.typography.bodyMedium
            )

            Profile.entries.forEach { profile ->
                ProfileCard(profile)
            }
        }
    }
}

@Composable
private fun ProfileCard(profile: Profile) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = profile.displayName,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = profile.description,
                style = MaterialTheme.typography.bodySmall
            )
            Text(
                text = "ID: ${profile.id}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
