package com.gamebrain.optimizer.optimization

import android.util.Log
import com.gamebrain.optimizer.shizuku.ShizukuManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Manual "lock me into this game" toggle, using the real, documented AOSP
 * shell command pair (confirmed directly from `Am.java`'s own help text):
 *
 *   am task lock <taskId>   — bring taskId to front, block switching away
 *   am task lock stop       — end the lock
 *
 * This is the shell-level equivalent of Android's built-in Settings ›
 * App pinning feature — same underlying system behavior, just triggered by
 * GameBrain instead of the Recents screen, and manually toggled from the
 * overlay rather than auto-releasing when the game closes (matching what
 * was asked for: stays locked until you flip it off yourself).
 *
 * IMPORTANT SAFETY NOTE — this is standard Android screen-pinning, not
 * anything more restrictive: if GameBrain, Shizuku, or the phone itself
 * misbehaves while this is on, the system's own universal escape hatch
 * always works regardless of how pinning was triggered: hold Back and
 * Recents together (or swipe-up-and-hold on gesture nav) to exit. That
 * exists at the OS level and nothing here can disable it.
 *
 * Finding the game's taskId uses `am stack list`, a long-standing but
 * legacy AOSP shell command. It's expected to work on most Android 15
 * builds since it's kept for backward compatibility, but — like the Game
 * Mode / fixed-performance-mode tweaks — this hasn't been verified against
 * every OEM build, so failures are handled gracefully rather than assumed
 * impossible.
 */
object ScreenPinController {

    private const val TAG = "ScreenPinController"

    private val _isPinned = MutableStateFlow(false)
    val isPinned: StateFlow<Boolean> = _isPinned.asStateFlow()

    /** Attempts to pin the given package's current task. Returns true on apparent success. */
    suspend fun pin(packageName: String): Boolean {
        val taskId = findTaskId(packageName)
        if (taskId == null) {
            Log.w(TAG, "Could not resolve a taskId for $packageName — not pinning")
            return false
        }
        val result = ShizukuManager.execCommandWithOutput("am task lock $taskId")
        val ok = result.exitCode == 0
        if (ok) _isPinned.value = true
        return ok
    }

    /** Releases the lock, if any. Safe to call even if nothing is currently pinned. */
    suspend fun unpin() {
        try {
            ShizukuManager.execCommand("am task lock stop")
        } finally {
            _isPinned.value = false
        }
    }

    private suspend fun findTaskId(packageName: String): Int? {
        val result = ShizukuManager.execCommandWithOutput("am stack list")
        if (result.exitCode != 0 || result.stdout.isBlank()) return null
        // Lines look like: "  taskId=123: com.example.game/... bounds=..."
        val line = result.stdout.lineSequence().firstOrNull { it.contains(packageName) } ?: return null
        val match = Regex("taskId=(\\d+)").find(line) ?: return null
        return match.groupValues[1].toIntOrNull()
    }
}
