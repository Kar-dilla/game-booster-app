package com.gamebrain.optimizer.overlay

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Tiny persisted on/off switch for the optional performance overlay.
 * Deliberately separate from [com.gamebrain.optimizer.optimization.OptimizationManager] —
 * this is a display-only preference, not part of the apply/restore session.
 */
object OverlaySettings {

    private const val PREFS_NAME = "gamebrain_overlay_prefs"
    private const val KEY_ENABLED = "overlay_enabled"

    private var prefs: SharedPreferences? = null

    private val _isEnabled = MutableStateFlow(false)
    val isEnabled: StateFlow<Boolean> = _isEnabled.asStateFlow()

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs = p
        _isEnabled.value = p.getBoolean(KEY_ENABLED, false)
    }

    fun setEnabled(enabled: Boolean) {
        _isEnabled.value = enabled
        prefs?.edit()?.putBoolean(KEY_ENABLED, enabled)?.apply()
    }
}
