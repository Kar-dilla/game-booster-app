package com.gamebrain.optimizer.optimization

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.util.Log
import androidx.core.content.ContextCompat
import com.gamebrain.optimizer.data.GameEntry
import com.gamebrain.optimizer.data.Profile
import com.gamebrain.optimizer.detection.AppDetectionManager
import com.gamebrain.optimizer.service.GameBrainForegroundService
import com.gamebrain.optimizer.shizuku.ShizukuManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Applies and restores system tweaks when a marked game becomes / leaves the foreground.
 *
 * All privileged changes go through [ShizukuManager.execCommand].
 * Original values are snapshotted before mutation so restoration is accurate.
 *
 * Does NOT touch resolution or FPS (TMPAD territory). Strong freezing is Hail's
 * territory and is not triggered from here.
 *
 * This is the single source of truth for:
 *  - Whether automatic optimization is armed ([isEnabled]) — controlled by the
 *    in-app switch, the Quick Settings Tile, and the persistent notification's
 *    "Stop" action. Persisted so it survives process death.
 *  - Whether a profile is currently applied ([isOptimizing]).
 *  - Starting/stopping [GameBrainForegroundService] to match [isEnabled].
 *
 * Reliability notes:
 *  - All state mutation goes through [applyMutex] so detection events, manual
 *    "Restore Now" taps, and enable/disable toggles can never race each other
 *    into a double-apply or a lost restore.
 *  - Leaving a marked game debounces briefly ([LEAVE_DEBOUNCE_MS]) before
 *    restoring, so a transient system dialog, notification shade pull-down,
 *    or quick alt-tab doesn't cause apply/restore thrashing.
 *  - If Shizuku is offline when a restore (or apply) is due, the intent is
 *    remembered ([pendingRestoreDueToOffline] / [pendingApply]) instead of
 *    being silently dropped, and retried automatically once Shizuku
 *    reconnects.
 */
object OptimizationManager {

    private const val TAG = "OptimizationManager"
    private const val PREFS_NAME = "gamebrain_optimization_state"
    private const val KEY_ENABLED = "auto_optimization_enabled"

    // Keys used to persist an in-progress optimization session so a killed
    // process (crash, low-memory kill, reboot) can still restore correctly
    // once GameBrain restarts. Only written while a session is active; all
    // removed together once restored. See [persistSession] / [loadSession].
    private const val KEY_SESSION_PACKAGE = "session_package"
    private const val KEY_SESSION_PROFILE = "session_profile"
    private const val KEY_S_PEAK_REFRESH = "session_peak_refresh"
    private const val KEY_S_MIN_REFRESH = "session_min_refresh"
    private const val KEY_S_USER_REFRESH = "session_user_refresh"
    private const val KEY_S_WINDOW_ANIM = "session_window_anim"
    private const val KEY_S_TRANSITION_ANIM = "session_transition_anim"
    private const val KEY_S_ANIMATOR_DUR = "session_animator_dur"
    private const val KEY_S_LOW_POWER = "session_low_power"
    private const val KEY_S_LOW_POWER_STICKY = "session_low_power_sticky"
    private const val KEY_S_LONG_PRESS = "session_long_press"
    private const val KEY_S_MULTI_PRESS = "session_multi_press"
    private const val KEY_S_POINTER_SPEED = "session_pointer_speed"
    private const val KEY_S_GAME_MODE = "session_game_mode"
    private const val KEY_S_AUTO_SYNC = "session_auto_sync"

    /** Grace period after leaving a marked game before we actually restore. */
    private const val LEAVE_DEBOUNCE_MS = 700L

    /** Retry knobs for [forceRestore]. */
    private const val FORCE_RESTORE_ATTEMPTS = 4
    private const val FORCE_RESTORE_RETRY_DELAY_MS = 800L

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val applyMutex = Mutex()

    private var collectJob: Job? = null
    private var shizukuWatchJob: Job? = null
    private var leaveDebounceJob: Job? = null
    private var initialized = false

    private var appContext: Context? = null
    private var prefs: SharedPreferences? = null

    /** Snapshot of settings captured just before the last apply. */
    private var savedState: SavedSystemState? = null

    /** Package currently under optimization (null when idle). */
    private var activeOptimizedPackage: String? = null

    /** Set when a restore was due but Shizuku was offline; retried on reconnect. */
    private var pendingRestoreDueToOffline = false

    /** Set when an apply was due but Shizuku was offline; retried on reconnect. */
    private var pendingApply: Pair<String, Profile>? = null

    private val _isOptimizing = MutableStateFlow(false)
    val isOptimizing: StateFlow<Boolean> = _isOptimizing.asStateFlow()

    private val _lastAppliedProfile = MutableStateFlow<Profile?>(null)
    val lastAppliedProfile: StateFlow<Profile?> = _lastAppliedProfile.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    /** Whether automatic optimization is armed. Persisted across restarts. */
    private val _isEnabled = MutableStateFlow(true)
    val isEnabled: StateFlow<Boolean> = _isEnabled.asStateFlow()

    /**
     * Common background packages that are safe to force-stop while gaming.
     * Hardcoded list — can be made configurable later.
     */
    private val BACKGROUND_CLEAN_PACKAGES = listOf(
        "com.google.android.apps.maps",
        "com.google.android.youtube",
        "com.google.android.apps.photos",
        "com.google.android.apps.messaging",
        "com.facebook.katana",
        "com.facebook.orca",
        "com.instagram.android",
        "com.twitter.android",
        "com.snapchat.android",
        "com.whatsapp",
        "com.spotify.music",
        "com.netflix.mediaclient",
        "com.amazon.mShop.android.shopping",
        "com.android.chrome",
        "com.google.android.gm",
        "com.google.android.apps.docs",
        "com.microsoft.office.outlook",
        "com.discord",
        "tv.twitch.android.app",
        "com.reddit.frontpage"
    )

    /** Call once from Application.onCreate after detection + Shizuku are initialised. */
    fun init(context: Context) {
        if (initialized) return
        initialized = true

        appContext = context.applicationContext
        val p = appContext!!.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs = p
        _isEnabled.value = p.getBoolean(KEY_ENABLED, true)

        // Recover an in-progress session that survived a process kill. This
        // does not touch the device yet — it just restores our bookkeeping
        // so the very next detection event (or "Restore Now"/Force Restore)
        // knows there is something to undo instead of losing track of it.
        loadSession(p)?.let { (pkg, profile, state) ->
            activeOptimizedPackage = pkg
            savedState = state
            _lastAppliedProfile.value = profile
            _isOptimizing.value = true
            _statusMessage.value = "Recovered pending session for $pkg — verifying…"
            Log.w(TAG, "Recovered in-progress session for $pkg after restart")
        }

        collectJob = scope.launch {
            // React when either the active game entry or "is game" flag changes.
            combine(
                AppDetectionManager.isForegroundGame,
                AppDetectionManager.activeGameEntry
            ) { isGame, entry ->
                isGame to entry
            }
                .distinctUntilChanged()
                .collect { (isGame, entry) ->
                    onDetectionChanged(isGame, entry)
                }
        }

        // Watch Shizuku connectivity so pending applies/restores can be retried
        // automatically instead of being lost.
        shizukuWatchJob = scope.launch {
            combine(
                ShizukuManager.isBinderAlive,
                ShizukuManager.isPermissionGranted
            ) { alive, granted -> alive && granted }
                .distinctUntilChanged()
                .collect { ready ->
                    if (ready) retryPendingWork()
                }
        }

        // Make sure the foreground service state matches the persisted switch.
        syncServiceState()

        Log.i(TAG, "OptimizationManager started (enabled=${_isEnabled.value})")
    }

    /**
     * Turns automatic optimization on/off. Used by the in-app switch, the
     * Quick Settings Tile, and the notification's "Stop" action. Safe to call
     * from any thread; the actual work is dispatched onto [scope].
     */
    fun setEnabled(enabled: Boolean) {
        scope.launch {
            if (_isEnabled.value == enabled) return@launch
            _isEnabled.value = enabled
            prefs?.edit()?.putBoolean(KEY_ENABLED, enabled)?.apply()

            if (!enabled) {
                leaveDebounceJob?.cancel()
                leaveDebounceJob = null
                applyMutex.withLock {
                    if (activeOptimizedPackage != null || savedState != null) {
                        restoreInternal()
                    }
                }
            } else {
                // Re-evaluate whatever is currently in the foreground right away.
                onDetectionChanged(
                    AppDetectionManager.isForegroundGame.value,
                    AppDetectionManager.activeGameEntry.value
                )
            }
            syncServiceState()
        }
    }

    fun toggleEnabled() {
        setEnabled(!_isEnabled.value)
    }

    /**
     * Forces an immediate restore of whatever is currently applied, without
     * changing the enabled/disabled state. Used by the in-app
     * "Restore Everything Now" button and the notification's "Restore Now"
     * action — an escape hatch independent of the automatic flow.
     */
    fun restoreNow() {
        scope.launch {
            leaveDebounceJob?.cancel()
            leaveDebounceJob = null
            applyMutex.withLock {
                if (activeOptimizedPackage != null || savedState != null) {
                    restoreInternal()
                } else {
                    _statusMessage.value = "Nothing to restore"
                }
            }
        }
    }

    /**
     * Escalated version of [restoreNow] for when a normal restore didn't take
     * (e.g. Shizuku was killed mid-session, or the phone was rebooted).
     * Retries a few times with a short delay to give Shizuku a moment to
     * reconnect, and if it still can't reach the device, clears local state
     * anyway so the UI/notification don't stay stuck forever — the person is
     * told plainly that settings may still be modified and should be checked
     * by hand. This never leaves the app *thinking* it's still optimizing
     * when it can no longer act on that.
     */
    fun forceRestore() {
        scope.launch {
            leaveDebounceJob?.cancel()
            leaveDebounceJob = null
            applyMutex.withLock {
                if (activeOptimizedPackage == null && savedState == null) {
                    _statusMessage.value = "Nothing to restore"
                    return@withLock
                }
                _statusMessage.value = "Force restoring…"
                var attempt = 0
                while (attempt < FORCE_RESTORE_ATTEMPTS && savedState != null) {
                    attempt++
                    ShizukuManager.refreshAll()
                    if (ShizukuManager.isReady()) {
                        restoreInternal()
                    } else if (attempt < FORCE_RESTORE_ATTEMPTS) {
                        delay(FORCE_RESTORE_RETRY_DELAY_MS)
                    }
                }
                if (savedState != null) {
                    Log.e(TAG, "Force restore: Shizuku unreachable after $attempt attempts — clearing local state")
                    clearSessionState()
                    _statusMessage.value =
                        "Couldn't confirm restore — Shizuku unreachable. Please check display, " +
                            "animation and battery-saver settings manually."
                }
            }
        }
    }

    /** Starts or stops [GameBrainForegroundService] to match [_isEnabled]. */
    private fun syncServiceState() {
        val ctx = appContext ?: return
        val intent = Intent(ctx, GameBrainForegroundService::class.java)
        try {
            if (_isEnabled.value) {
                ContextCompat.startForegroundService(ctx, intent)
            } else {
                ctx.stopService(intent)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to sync foreground service state: ${e.message}")
        }
    }

    private suspend fun retryPendingWork() {
        applyMutex.withLock {
            if (pendingRestoreDueToOffline) {
                restoreInternal()
            }
            pendingApply?.let { (pkg, profile) ->
                // Only re-apply if that package is still the active marked game;
                // otherwise the situation has moved on and this is stale.
                val stillRelevant = AppDetectionManager.isForegroundGame.value &&
                    AppDetectionManager.activeGameEntry.value?.packageName == pkg
                if (stillRelevant) {
                    applyInternal(pkg, profile)
                } else {
                    pendingApply = null
                }
            }
        }
    }

    private suspend fun onDetectionChanged(isGame: Boolean, entry: GameEntry?) {
        if (!_isEnabled.value) return // paused — nothing to do until re-enabled

        if (isGame && entry != null) {
            // Back in a (possibly different) marked game — cancel any pending
            // debounced restore from a brief earlier absence.
            leaveDebounceJob?.cancel()
            leaveDebounceJob = null

            applyMutex.withLock {
                val profile = entry.profile
                val pkg = entry.packageName
                // Re-apply if package or profile changed while still in a game.
                if (activeOptimizedPackage != pkg || _lastAppliedProfile.value != profile) {
                    // If we were optimizing a different package, restore first.
                    if (activeOptimizedPackage != null && activeOptimizedPackage != pkg) {
                        restoreInternal()
                    }
                    applyInternal(pkg, profile)
                }
            }
        } else {
            // Left the marked game (backgrounded or closed), or foreground is
            // no longer a marked game. Debounce briefly to absorb transient
            // overlays (system dialogs, notification shade, quick app
            // switcher) so we don't thrash apply/restore.
            if (activeOptimizedPackage != null) {
                val restoringPackage = activeOptimizedPackage
                leaveDebounceJob?.cancel()
                leaveDebounceJob = scope.launch {
                    delay(LEAVE_DEBOUNCE_MS)
                    applyMutex.withLock {
                        val backInSameGame = AppDetectionManager.isForegroundGame.value &&
                            AppDetectionManager.activeGameEntry.value?.packageName == restoringPackage
                        if (!backInSameGame && activeOptimizedPackage != null) {
                            restoreInternal()
                        }
                    }
                }
            }
        }
    }

    // -------------------------------------------------------------------------
    // Apply
    // -------------------------------------------------------------------------

    private suspend fun applyInternal(packageName: String, profile: Profile) {
        if (!ShizukuManager.isReady()) {
            Log.w(TAG, "Shizuku not ready — will apply for $packageName / $profile once connected")
            pendingApply = packageName to profile
            _statusMessage.value = "Waiting for Shizuku to apply ${profile.displayName}…"
            return
        }
        pendingApply = null

        // Guard against double-applying the same profile to the same package.
        if (activeOptimizedPackage == packageName && _lastAppliedProfile.value == profile) {
            return
        }

        Log.i(TAG, "Applying profile ${profile.displayName} for $packageName")
        _statusMessage.value = "Applying ${profile.displayName}…"

        try {
            // 1. Snapshot current values (only once per optimization session).
            if (savedState == null) {
                savedState = snapshotCurrentSettings()
            }
            // Mark the session active — and persist it — *before* mutating
            // anything, so if a tweak below throws partway through, we still
            // know there is something to restore instead of losing track of
            // a half-applied state.
            activeOptimizedPackage = packageName
            persistSession(packageName, profile, savedState!!)

            // 2. Refresh rate
            applyRefreshRate(profile)

            // 3. Animation scales
            applyAnimationScales(profile)

            // 4. Battery: exempt game + turn off battery saver
            applyBatteryTweaks(packageName)

            // 5. Touch latency
            applyTouchLatency(profile)

            // 5b. Per-app preferred display mode — best-effort, undocumented
            // OEM-dependent API (Android 13+). No-ops silently where unsupported.
            applyPerAppRefreshOverride(packageName, profile)

            // 5c. Background sync — pause it for the duration of the session
            // so cloud backups / mail / app-update checks don't spike CPU or
            // network mid-game. Uses ContentResolver directly (normal-level
            // WRITE_SYNC_SETTINGS permission), not a shell command — there is
            // no real "settings put global auto_sync" key; master sync isn't
            // stored in the Settings provider at all.
            setAutoSyncEnabled(false)

            // 6. Android Game Mode API — asks the system GameManagerService to
            // favor this package (raised thermal headroom / GPU clocks on
            // devices whose OEM backs the mode). No-op/harmless on devices
            // that ignore it.
            applyGameMode(packageName, profile)

            // 7. Process priority — best-effort. Shizuku runs as the "shell"
            // UID, which on most stock Android builds is NOT allowed to
            // renice a *different* app's process into negative (higher
            // priority) territory — only root can. This is attempted but
            // expected to silently no-op on non-rooted devices; it is never
            // treated as a failure.
            applyProcessPriority(packageName)

            // 8. Fixed performance mode — pins CPU/GPU clocks high, at the
            // cost of heat/battery. Reserved for the top profiles only, and
            // always paired with a restore below.
            if (profile == Profile.EXTREME || profile == Profile.COMPETITIVE) {
                applyFixedPerformanceMode(true)
            }

            // 9. Light background cleaning (force-stop common apps)
            if (profile == Profile.EXTREME || profile == Profile.COMPETITIVE) {
                forceStopBackgroundApps(packageName)
            }

            _lastAppliedProfile.value = profile
            _isOptimizing.value = true
            _statusMessage.value = "Active: ${profile.displayName}"
            Log.i(TAG, "Profile applied successfully")
        } catch (e: Exception) {
            // Partial apply. Keep activeOptimizedPackage/savedState so the
            // person can still hit Restore Now / Force Restore — silently
            // dropping this here is how a device gets stuck half-modified.
            Log.e(TAG, "Apply failed partway for $packageName", e)
            _lastAppliedProfile.value = profile
            _isOptimizing.value = true
            _statusMessage.value = "Apply had an error — tap Restore Everything Now to be safe"
        }
    }

    // -------------------------------------------------------------------------
    // Restore
    // -------------------------------------------------------------------------

    private suspend fun restoreInternal() {
        val state = savedState
        if (state == null) {
            Log.d(TAG, "Nothing to restore")
            clearSessionState()
            return
        }

        if (!ShizukuManager.isReady()) {
            Log.w(TAG, "Shizuku not ready — restore pending, will retry once connected")
            // Keep savedState / activeOptimizedPackage intact so nothing is lost;
            // retryPendingWork() will finish the job once Shizuku reconnects.
            pendingRestoreDueToOffline = true
            _statusMessage.value = "Restore pending (Shizuku offline)"
            return
        }

        Log.i(TAG, "Restoring system settings")
        _statusMessage.value = "Restoring…"

        try {
            // Refresh rate
            putSetting("system", "peak_refresh_rate", state.peakRefreshRate)
            putSetting("system", "min_refresh_rate", state.minRefreshRate)
            if (state.userRefreshRate != null) {
                putSetting("system", "user_refresh_rate", state.userRefreshRate)
            }

            // Animation scales
            putSetting("global", "window_animation_scale", state.windowAnimationScale)
            putSetting("global", "transition_animation_scale", state.transitionAnimationScale)
            putSetting("global", "animator_duration_scale", state.animatorDurationScale)

            // Battery saver
            putSetting("global", "low_power", state.lowPower)
            if (state.lowPowerSticky != null) {
                putSetting("global", "low_power_sticky", state.lowPowerSticky)
            }

            // Touch
            putSetting("secure", "long_press_timeout", state.longPressTimeout)
            if (state.multiPressTimeout != null) {
                putSetting("secure", "multi_press_timeout", state.multiPressTimeout)
            }
            if (state.pointerSpeed != null) {
                putSetting("system", "pointer_speed", state.pointerSpeed)
            }

            // Game Mode — always return the package to STANDARD.
            activeOptimizedPackage?.let { pkg ->
                ShizukuManager.execCommand("cmd game set --mode 1 $pkg")
            }

            // Fixed performance mode — always turn back off, regardless of
            // which profile applied it, so it never gets stuck on.
            applyFixedPerformanceMode(false)

            // Per-app refresh override — clear it so the game doesn't keep a
            // stale forced mode after it's no longer foreground.
            activeOptimizedPackage?.let { pkg ->
                ShizukuManager.execCommand("cmd display set-user-preferred-app-mode $pkg -1")
            }

            // Background sync — always restore to whatever it was before,
            // not just "on". If the person had already disabled it
            // themselves, we don't want to silently flip it on for them.
            setAutoSyncEnabled(state.autoSync == "1")

            // DND — courtesy auto-off on leaving the game, regardless of how
            // it was toggled (overlay or otherwise), so it never lingers on
            // after a session. Screen pin is intentionally NOT auto-released
            // here — see ScreenPinController's docs for why that one stays
            // manual, plus the universal hold-Back+Recents escape hatch.
            appContext?.let { DndController.setEnabled(it, false) }

            // Note: deviceidle whitelist is additive; we leave the exemption in place
            // (harmless). Removing would require knowing if it was pre-existing.

            _statusMessage.value = "Restored"
            Log.i(TAG, "System settings restored")
        } catch (e: Exception) {
            // Best-effort commands already swallow their own failures inside
            // ShizukuManager; this catches anything unexpected (e.g. Shizuku
            // dying mid-sequence) so we don't crash the caller. We still
            // clear local state below — repeating a half-failed restore
            // forever isn't safer than reporting it and letting Force
            // Restore (or a manual settings check) take over.
            Log.e(TAG, "Restore hit an error partway through", e)
            _statusMessage.value = "Restore had an error — some settings may still be modified"
        }

        clearSessionState()
    }

    /** Clears in-memory + persisted session bookkeeping and resets UI state. */
    private fun clearSessionState() {
        pendingRestoreDueToOffline = false
        savedState = null
        activeOptimizedPackage = null
        _lastAppliedProfile.value = null
        _isOptimizing.value = false
        if (_statusMessage.value == "Restoring…") _statusMessage.value = null
        prefs?.edit()?.apply {
            remove(KEY_SESSION_PACKAGE)
            remove(KEY_SESSION_PROFILE)
            remove(KEY_S_PEAK_REFRESH)
            remove(KEY_S_MIN_REFRESH)
            remove(KEY_S_USER_REFRESH)
            remove(KEY_S_WINDOW_ANIM)
            remove(KEY_S_TRANSITION_ANIM)
            remove(KEY_S_ANIMATOR_DUR)
            remove(KEY_S_LOW_POWER)
            remove(KEY_S_LOW_POWER_STICKY)
            remove(KEY_S_LONG_PRESS)
            remove(KEY_S_MULTI_PRESS)
            remove(KEY_S_POINTER_SPEED)
            remove(KEY_S_AUTO_SYNC)
        }?.apply()
    }

    /** Persists the active session so it survives the process being killed. */
    private fun persistSession(packageName: String, profile: Profile, state: SavedSystemState) {
        prefs?.edit()?.apply {
            putString(KEY_SESSION_PACKAGE, packageName)
            putString(KEY_SESSION_PROFILE, profile.id)
            putString(KEY_S_PEAK_REFRESH, state.peakRefreshRate)
            putString(KEY_S_MIN_REFRESH, state.minRefreshRate)
            state.userRefreshRate?.let { putString(KEY_S_USER_REFRESH, it) } ?: remove(KEY_S_USER_REFRESH)
            putString(KEY_S_WINDOW_ANIM, state.windowAnimationScale)
            putString(KEY_S_TRANSITION_ANIM, state.transitionAnimationScale)
            putString(KEY_S_ANIMATOR_DUR, state.animatorDurationScale)
            putString(KEY_S_LOW_POWER, state.lowPower)
            state.lowPowerSticky?.let { putString(KEY_S_LOW_POWER_STICKY, it) } ?: remove(KEY_S_LOW_POWER_STICKY)
            putString(KEY_S_LONG_PRESS, state.longPressTimeout)
            state.multiPressTimeout?.let { putString(KEY_S_MULTI_PRESS, it) } ?: remove(KEY_S_MULTI_PRESS)
            state.pointerSpeed?.let { putString(KEY_S_POINTER_SPEED, it) } ?: remove(KEY_S_POINTER_SPEED)
            putString(KEY_S_AUTO_SYNC, state.autoSync)
        }?.apply()
    }

    /** Loads a previously persisted session, if any. Does not touch the device. */
    private fun loadSession(p: SharedPreferences): Triple<String, Profile, SavedSystemState>? {
        val pkg = p.getString(KEY_SESSION_PACKAGE, null) ?: return null
        val profileId = p.getString(KEY_SESSION_PROFILE, null)
        val peak = p.getString(KEY_S_PEAK_REFRESH, null) ?: return null
        val min = p.getString(KEY_S_MIN_REFRESH, null) ?: return null
        val longPress = p.getString(KEY_S_LONG_PRESS, null) ?: return null
        val lowPower = p.getString(KEY_S_LOW_POWER, null) ?: return null
        val state = SavedSystemState(
            peakRefreshRate = peak,
            minRefreshRate = min,
            userRefreshRate = p.getString(KEY_S_USER_REFRESH, null),
            windowAnimationScale = p.getString(KEY_S_WINDOW_ANIM, null) ?: "1.0",
            transitionAnimationScale = p.getString(KEY_S_TRANSITION_ANIM, null) ?: "1.0",
            animatorDurationScale = p.getString(KEY_S_ANIMATOR_DUR, null) ?: "1.0",
            lowPower = lowPower,
            lowPowerSticky = p.getString(KEY_S_LOW_POWER_STICKY, null),
            longPressTimeout = longPress,
            multiPressTimeout = p.getString(KEY_S_MULTI_PRESS, null),
            pointerSpeed = p.getString(KEY_S_POINTER_SPEED, null),
            autoSync = p.getString(KEY_S_AUTO_SYNC, null) ?: "1"
        )
        return Triple(pkg, Profile.fromId(profileId), state)
    }

    // -------------------------------------------------------------------------
    // Individual tweaks
    // -------------------------------------------------------------------------

    private suspend fun applyRefreshRate(profile: Profile) {
        when (profile) {
            Profile.EXTREME, Profile.COMPETITIVE -> {
                // Force highest available: set peak high and min equal so it locks.
                // Using 120 as a common high target; devices that support only 90/60
                // will clamp. Setting both min and peak forces the peak mode.
                putSetting("system", "peak_refresh_rate", "120.0")
                putSetting("system", "min_refresh_rate", "120.0")
                // Some OEMs also respect user_refresh_rate
                putSetting("system", "user_refresh_rate", "120")
            }
            Profile.BALANCED -> {
                putSetting("system", "peak_refresh_rate", "90.0")
                putSetting("system", "min_refresh_rate", "90.0")
                putSetting("system", "user_refresh_rate", "90")
            }
            Profile.BATTERY -> {
                putSetting("system", "peak_refresh_rate", "60.0")
                putSetting("system", "min_refresh_rate", "60.0")
                putSetting("system", "user_refresh_rate", "60")
            }
        }
    }

    private suspend fun applyAnimationScales(profile: Profile) {
        val scale = when (profile) {
            Profile.EXTREME, Profile.COMPETITIVE -> "0.0"
            Profile.BALANCED -> "0.5"
            Profile.BATTERY -> "1.0"
        }
        putSetting("global", "window_animation_scale", scale)
        putSetting("global", "transition_animation_scale", scale)
        putSetting("global", "animator_duration_scale", scale)
    }

    private suspend fun applyBatteryTweaks(packageName: String) {
        // Turn off Battery Saver while gaming
        putSetting("global", "low_power", "0")
        putSetting("global", "low_power_sticky", "0")

        // Exempt the game from battery optimization / device-idle
        // dumpsys deviceidle whitelist +pkg adds to the system whitelist
        ShizukuManager.execCommand("dumpsys deviceidle whitelist +$packageName")
        // Also allow unrestricted background via appops where supported
        ShizukuManager.execCommand("cmd appops set $packageName RUN_ANY_IN_BACKGROUND allow")
        ShizukuManager.execCommand("cmd appops set $packageName RUN_IN_BACKGROUND allow")
    }

    private suspend fun applyTouchLatency(profile: Profile) {
        // Lower long-press / multi-press timeouts for more responsive feel.
        // Defaults are typically 400–500 ms (short). We push them lower for
        // competitive profiles without going so low that accidental long-presses fire.
        val longPress = when (profile) {
            Profile.EXTREME, Profile.COMPETITIVE -> "250"
            Profile.BALANCED -> "350"
            Profile.BATTERY -> "400" // leave near default
        }
        val multiPress = when (profile) {
            Profile.EXTREME, Profile.COMPETITIVE -> "150"
            Profile.BALANCED -> "200"
            Profile.BATTERY -> "300"
        }
        putSetting("secure", "long_press_timeout", longPress)
        putSetting("secure", "multi_press_timeout", multiPress)

        // Pointer speed: system range is typically -7..7, default 0.
        // Slightly increase for competitive feel.
        if (profile == Profile.EXTREME || profile == Profile.COMPETITIVE) {
            putSetting("system", "pointer_speed", "1")
        }
    }

    /**
     * Android Game Mode API (Android 12+). Asks GameManagerService to treat
     * this package as the active foreground game and request the OEM's
     * "performance" governor profile for it. Mode ints match
     * android.app.GameManager: STANDARD=1, PERFORMANCE=2, BATTERY=3.
     * Silently does nothing on devices/OEMs that don't back this — it's a
     * request, not a guarantee.
     */
    private suspend fun applyGameMode(packageName: String, profile: Profile) {
        val mode = when (profile) {
            Profile.EXTREME, Profile.COMPETITIVE -> 2 // PERFORMANCE
            Profile.BALANCED -> 1 // STANDARD
            Profile.BATTERY -> 3 // BATTERY
        }
        ShizukuManager.execCommand("cmd game set --mode $mode $packageName")
    }

    /**
     * Best-effort scheduling priority bump for the game's current process.
     * Shizuku executes as the "shell" UID, which on most non-rooted stock
     * builds cannot lower niceness (raise priority) for a process it doesn't
     * own — only root can go below 0. This is attempted anyway since some
     * OEMs/rooted setups do allow it, but a failure here is expected and
     * never surfaced as an error; nothing is left in a bad state either way,
     * since niceness dies with the process when the game closes.
     */
    private suspend fun applyProcessPriority(packageName: String) {
        val pidResult = ShizukuManager.execCommandWithOutput("pidof $packageName")
        val pid = pidResult.stdout.trim().split(Regex("\\s+")).firstOrNull { it.isNotBlank() }
            ?: return
        ShizukuManager.execCommand("renice -n -10 -p $pid")
    }

    /**
     * Best-effort per-app preferred display mode. `cmd display
     * set-user-preferred-app-mode` is an undocumented, OEM-dependent hidden
     * command (not a stable public API) — some Android 13+ builds honor it to
     * keep the panel at peak refresh during scenes their own heuristic would
     * otherwise judge as "static", others ignore or reject it entirely. Kept
     * strictly best-effort: any failure is swallowed, never surfaced as an
     * apply error, and the restore path always clears it (-1) regardless of
     * whether the set actually took effect.
     */
    private suspend fun applyPerAppRefreshOverride(packageName: String, profile: Profile) {
        val mode = when (profile) {
            Profile.EXTREME, Profile.COMPETITIVE -> 120
            Profile.BALANCED -> 90
            Profile.BATTERY -> 60
        }
        ShizukuManager.execCommand("cmd display set-user-preferred-app-mode $packageName $mode")
    }

    /**
     * Master auto-sync (cloud backup / mail / app-update sync) toggle.
     *
     * Deliberately NOT a shell command: master sync is stored by
     * SyncStorageEngine, not the Settings provider, so there is no
     * `settings put global auto_sync` key backing it — writing one just
     * creates an inert, unread key. The real accessor is
     * [ContentResolver.setMasterSyncAutomatically], gated by
     * WRITE_SYNC_SETTINGS, which is a *normal*-protection permission (see
     * the manifest) — granted automatically at install, so this needs
     * neither Shizuku nor a runtime permission prompt.
     */
    /** Public read of the currently-optimized game's package, for the overlay/UI. */
    fun getActiveGamePackage(): String? = activeOptimizedPackage

    /**
     * One-shot "clean up background again, right now" — same force-stop list
     * as the automatic pass at game launch, exposed for the overlay's
     * quick-action button so a mid-session RAM creep can be reclaimed
     * without leaving the game.
     */
    suspend fun killBackgroundNow() {
        val pkg = activeOptimizedPackage ?: return
        forceStopBackgroundApps(pkg)
    }

    /** Public read/write for the overlay's manual sync toggle. */
    fun isAutoSyncEnabled(): Boolean = getAutoSyncEnabled()
    fun setAutoSync(enabled: Boolean) = setAutoSyncEnabled(enabled)

    private fun getAutoSyncEnabled(): Boolean =
        appContext?.let { ContentResolver.getMasterSyncAutomatically() } ?: true

    private fun setAutoSyncEnabled(enabled: Boolean) {
        try {
            ContentResolver.setMasterSyncAutomatically(enabled)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to set master sync to $enabled: ${e.message}")
        }
    }

    /**
     * Pins the device's power/perf governor to maximum via the hidden
     * "fixed performance mode" shell command. Always paired with turning it
     * back off in [restoreInternal] — never left on. Significantly increases
     * heat and battery drain, so it's gated to the top profiles only.
     */
    private suspend fun applyFixedPerformanceMode(enabled: Boolean) {
        ShizukuManager.execCommand("cmd power set-fixed-performance-mode-enabled $enabled")
    }

    /**
     * AOT-compiles the game's DEX/OAT into native machine code ahead of time,
     * to cut down on JIT-related micro-stutter during play.
     *
     * Deliberately NOT part of [applyInternal] / the automatic per-session
     * flow: `cmd package compile -m speed` typically takes anywhere from
     * ~15 seconds to a couple of minutes depending on the app's size, and
     * running it every time a marked game is foregrounded would itself
     * cause a large stutter/delay right as the person starts playing, and
     * would also fight the OS's own background JIT compilation.
     *
     * There's also nothing to "restore" — it doesn't change any setting the
     * game or system depends on, it's a one-way optimization. Call this
     * explicitly (e.g. a "Pre-compile" button per game in [GamesScreen]),
     * ideally the first time a game is added or after it updates.
     *
     * Returns true if compilation completed successfully.
     */
    suspend fun precompileGame(packageName: String): Boolean {
        if (!ShizukuManager.isReady()) {
            _statusMessage.value = "Shizuku not ready — can't pre-compile"
            return false
        }
        _statusMessage.value = "Pre-compiling $packageName… this can take a minute"
        val result = ShizukuManager.execCommandWithOutput("cmd package compile -m speed -f $packageName")
        val ok = result.exitCode == 0
        _statusMessage.value = if (ok) "Pre-compiled $packageName" else "Pre-compile failed: ${result.stderr}"
        return ok
    }

    private suspend fun forceStopBackgroundApps(excludePackage: String) {
        for (pkg in BACKGROUND_CLEAN_PACKAGES) {
            if (pkg == excludePackage) continue
            // Best-effort; package may not be installed
            ShizukuManager.execCommand("am force-stop $pkg")
        }
    }

    // -------------------------------------------------------------------------
    // Snapshot helpers
    // -------------------------------------------------------------------------

    private suspend fun snapshotCurrentSettings(): SavedSystemState {
        return SavedSystemState(
            peakRefreshRate = getSetting("system", "peak_refresh_rate") ?: "60.0",
            minRefreshRate = getSetting("system", "min_refresh_rate") ?: "60.0",
            userRefreshRate = getSetting("system", "user_refresh_rate"),
            windowAnimationScale = getSetting("global", "window_animation_scale") ?: "1.0",
            transitionAnimationScale = getSetting("global", "transition_animation_scale") ?: "1.0",
            animatorDurationScale = getSetting("global", "animator_duration_scale") ?: "1.0",
            lowPower = getSetting("global", "low_power") ?: "0",
            lowPowerSticky = getSetting("global", "low_power_sticky"),
            longPressTimeout = getSetting("secure", "long_press_timeout") ?: "400",
            multiPressTimeout = getSetting("secure", "multi_press_timeout"),
            pointerSpeed = getSetting("system", "pointer_speed"),
            // auto_sync has no dedicated "get" via settings (it's a
            // ContentResolver master-sync flag, not a Settings key), so we
            // read it through its actual accessor.
            autoSync = if (getAutoSyncEnabled()) "1" else "0"
        )
    }

    private suspend fun getSetting(namespace: String, key: String): String? {
        val result = ShizukuManager.execCommandWithOutput("settings get $namespace $key")
        if (result.exitCode != 0) return null
        val value = result.stdout.trim()
        // settings get returns "null" (literal) when unset
        return if (value.isEmpty() || value == "null") null else value
    }

    private suspend fun putSetting(namespace: String, key: String, value: String) {
        ShizukuManager.execCommand("settings put $namespace $key $value")
    }

    // -------------------------------------------------------------------------
    // Data
    // -------------------------------------------------------------------------

    /**
     * Captured system values so we can restore exactly what was there.
     */
    private data class SavedSystemState(
        val peakRefreshRate: String,
        val minRefreshRate: String,
        val userRefreshRate: String?,
        val windowAnimationScale: String,
        val transitionAnimationScale: String,
        val animatorDurationScale: String,
        val lowPower: String,
        val lowPowerSticky: String?,
        val longPressTimeout: String,
        val multiPressTimeout: String?,
        val pointerSpeed: String?,
        val autoSync: String
    )
}
