package com.gamebrain.optimizer.shizuku

import android.content.pm.PackageManager
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.lang.reflect.Method

/**
 * Thin wrapper around the official Shizuku API.
 *
 * Exposes two simple, observable booleans that the UI layer collects from:
 *  - [isBinderAlive]: whether the Shizuku service is currently reachable.
 *  - [isPermissionGranted]: whether this app has been granted Shizuku access.
 *
 * Also provides [execCommand] / [execCommandWithOutput] for privileged shell
 * execution used by the optimization layer (Part 3).
 */
object ShizukuManager {

    private const val TAG = "ShizukuManager"
    private const val SHIZUKU_PERMISSION_REQUEST_CODE = 1001

    private val _isBinderAlive = MutableStateFlow(false)
    val isBinderAlive: StateFlow<Boolean> = _isBinderAlive

    private val _isPermissionGranted = MutableStateFlow(false)
    val isPermissionGranted: StateFlow<Boolean> = _isPermissionGranted

    private var initialized = false

    /** Cached reflection handle for Shizuku.newProcess (hidden API). */
    @Volatile
    private var newProcessMethod: Method? = null

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        _isBinderAlive.value = true
        refreshPermissionState()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        _isBinderAlive.value = false
        _isPermissionGranted.value = false
    }

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == SHIZUKU_PERMISSION_REQUEST_CODE) {
                _isPermissionGranted.value = grantResult == PackageManager.PERMISSION_GRANTED
            }
        }

    /** Call once (from [com.gamebrain.optimizer.GameBrainApplication]) to start listening. */
    fun init() {
        if (initialized) return
        initialized = true

        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Shizuku.addRequestPermissionResultListener(permissionResultListener)

        refreshAll()
    }

    /** Re-checks both the binder connection and the permission state. Safe to call anytime. */
    fun refreshAll() {
        _isBinderAlive.value = pingBinderSafely()
        refreshPermissionState()
    }

    /** Re-checks whether the Shizuku permission is currently granted. */
    fun refreshPermissionState() {
        _isPermissionGranted.value = try {
            if (!pingBinderSafely()) {
                false
            } else {
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            }
        } catch (e: Throwable) {
            false
        }
    }

    /** Triggers the system Shizuku permission request dialog, if the service is running. */
    fun requestPermission() {
        try {
            if (!pingBinderSafely()) return

            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                _isPermissionGranted.value = true
                return
            }

            if (Shizuku.shouldShowRequestPermissionRationale()) {
                // The user previously denied the request. We still attempt the
                // request again here; a richer rationale UI can be added later.
            }

            Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
        } catch (e: Throwable) {
            // Shizuku is not installed or not running
        }
    }

    /**
     * Whether Shizuku is ready for privileged command execution
     * (binder alive + permission granted).
     */
    fun isReady(): Boolean {
        return try {
            pingBinderSafely() &&
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Throwable) {
            false
        }
    }

    /**
     * Execute a shell command via Shizuku.
     * Returns true if the process exited with code 0.
     */
    suspend fun execCommand(command: String): Boolean = withContext(Dispatchers.IO) {
        val result = execCommandWithOutput(command)
        result.exitCode == 0
    }

    /**
     * Execute a shell command via Shizuku and return exit code + stdout/stderr.
     */
    suspend fun execCommandWithOutput(command: String): ShellResult =
        withContext(Dispatchers.IO) {
            if (!isReady()) {
                Log.w(TAG, "Shizuku not ready; cannot run: $command")
                return@withContext ShellResult(-1, "", "Shizuku not ready")
            }
            try {
                val process = newRemoteProcess(arrayOf("sh", "-c", command))
                    ?: return@withContext ShellResult(-1, "", "newProcess returned null")

                val stdout = process.inputStream.bufferedReader().use(BufferedReader::readText)
                val stderr = process.errorStream.bufferedReader().use(BufferedReader::readText)
                val exitCode = try {
                    process.waitFor()
                } catch (e: InterruptedException) {
                    process.destroy()
                    -1
                }
                Log.d(TAG, "cmd[$exitCode]: $command")
                if (stderr.isNotBlank()) {
                    Log.d(TAG, "stderr: $stderr")
                }
                ShellResult(exitCode, stdout.trim(), stderr.trim())
            } catch (e: Exception) {
                Log.e(TAG, "Failed to exec: $command", e)
                ShellResult(-1, "", e.message ?: "exception")
            }
        }

    private fun newRemoteProcess(cmd: Array<String>): Process? {
        val method = resolveNewProcessMethod() ?: return null
        // Signature: newProcess(String[] cmd, String[] env, String dir)
        val result = method.invoke(null, cmd, null, null)
        return result as? Process
    }

    private fun resolveNewProcessMethod(): Method? {
        newProcessMethod?.let { return it }
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            newProcessMethod = m
            m
        } catch (e: Exception) {
            Log.e(TAG, "Shizuku.newProcess not available", e)
            null
        }
    }

    private fun pingBinderSafely(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    data class ShellResult(
        val exitCode: Int,
        val stdout: String,
        val stderr: String
    )
}
