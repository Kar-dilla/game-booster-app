package com.gamebrain.optimizer.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.gamebrain.optimizer.detection.AppDetectionManager
import com.gamebrain.optimizer.optimization.OptimizationManager
import com.gamebrain.optimizer.overlay.GameBrainOverlayService
import com.gamebrain.optimizer.overlay.OverlaySettings
import com.gamebrain.optimizer.service.GameBrainAccessibilityService
import com.gamebrain.optimizer.shizuku.ShizukuManager
import com.gamebrain.optimizer.util.PermissionUtils

/**
 * Home screen — setup / status hub + live foreground-app detection display.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen() {
    val context = LocalContext.current

    val isBinderAlive by ShizukuManager.isBinderAlive.collectAsState()
    val isShizukuGranted by ShizukuManager.isPermissionGranted.collectAsState()

    val foregroundPackage by AppDetectionManager.foregroundPackage.collectAsState()
    val foregroundLabel by AppDetectionManager.foregroundAppLabel.collectAsState()
    val isForegroundGame by AppDetectionManager.isForegroundGame.collectAsState()
    val activeGame by AppDetectionManager.activeGameEntry.collectAsState()

    val isOptimizing by OptimizationManager.isOptimizing.collectAsState()
    val optStatus by OptimizationManager.statusMessage.collectAsState()
    val appliedProfile by OptimizationManager.lastAppliedProfile.collectAsState()
    val isAutoOptimizeEnabled by OptimizationManager.isEnabled.collectAsState()

    val isOverlayEnabled by OverlaySettings.isEnabled.collectAsState()

    var hasUsageAccess by remember { mutableStateOf(PermissionUtils.hasUsageAccess(context)) }
    var hasOverlay by remember { mutableStateOf(PermissionUtils.hasOverlayPermission(context)) }
    var hasAccessibility by remember {
        mutableStateOf(
            PermissionUtils.isAccessibilityServiceEnabled(
                context,
                GameBrainAccessibilityService::class.java
            )
        )
    }

    fun refreshAllStatuses() {
        ShizukuManager.refreshAll()
        hasUsageAccess = PermissionUtils.hasUsageAccess(context)
        hasOverlay = PermissionUtils.hasOverlayPermission(context)
        hasAccessibility = PermissionUtils.isAccessibilityServiceEnabled(
            context,
            GameBrainAccessibilityService::class.java
        )
        if (hasUsageAccess) {
            AppDetectionManager.startUsageStatsBackup()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("GameBrain") },
                actions = {
                    TextButton(onClick = { refreshAllStatuses() }) {
                        Text("Refresh")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "GameBrain",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Game performance optimizer — detection & live optimization",
                style = MaterialTheme.typography.bodyMedium
            )

            ForegroundDetectionCard(
                packageName = foregroundPackage,
                label = foregroundLabel,
                isGame = isForegroundGame,
                profileName = activeGame?.profile?.displayName,
                isOptimizing = isOptimizing,
                optStatus = optStatus,
                appliedProfileName = appliedProfile?.displayName
            )

            AutomationControlCard(
                isEnabled = isAutoOptimizeEnabled,
                isOptimizing = isOptimizing,
                onEnabledChange = { OptimizationManager.setEnabled(it) },
                onRestoreNow = { OptimizationManager.restoreNow() },
                onForceRestore = { OptimizationManager.forceRestore() }
            )

            ShizukuCard(
                isBinderAlive = isBinderAlive,
                isGranted = isShizukuGranted,
                onRequestPermission = { ShizukuManager.requestPermission() }
            )

            PermissionCard(
                title = "Usage Access",
                description = "Backup method to detect which app is running in the foreground.",
                granted = hasUsageAccess,
                onRequest = { context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
            )

            PermissionCard(
                title = "Display Over Other Apps",
                description = "Needed to show the optional FPS/RAM overlay.",
                granted = hasOverlay,
                onRequest = {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${context.packageName}")
                    )
                    context.startActivity(intent)
                }
            )

            OverlayControlCard(
                enabled = isOverlayEnabled,
                permissionGranted = hasOverlay,
                onEnabledChange = { turnOn ->
                    OverlaySettings.setEnabled(turnOn)
                    val serviceIntent = Intent(context, GameBrainOverlayService::class.java)
                    if (turnOn && hasOverlay) {
                        context.startService(serviceIntent)
                    } else {
                        context.stopService(serviceIntent)
                    }
                }
            )

            PermissionCard(
                title = "Accessibility Service",
                description = "Primary method to detect when apps (especially games) enter or leave the foreground.",
                granted = hasAccessibility,
                onRequest = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            )

            Divider()

            val statusText = when {
                !isBinderAlive -> "Status: Shizuku service not running."
                !isShizukuGranted -> "Status: Shizuku running, permission not granted yet."
                else -> "Status: All set — Shizuku is connected and authorized."
            }
            Text(text = statusText, style = MaterialTheme.typography.bodyLarge)
        }
    }
}

@Composable
private fun ForegroundDetectionCard(
    packageName: String?,
    label: String?,
    isGame: Boolean,
    profileName: String?,
    isOptimizing: Boolean = false,
    optStatus: String? = null,
    appliedProfileName: String? = null
) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "Foreground App",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            if (packageName == null) {
                Text(
                    text = "No app detected yet. Enable Accessibility Service (and optionally Usage Access) then switch to another app.",
                    style = MaterialTheme.typography.bodySmall
                )
            } else {
                Text(
                    text = label ?: packageName,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = packageName,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatusDot(ok = isGame)
                    Text(
                        text = if (isGame) {
                            "Marked as Game" + (profileName?.let { " · $it" } ?: "")
                        } else {
                            "Not in game list"
                        },
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                if (isGame) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StatusDot(ok = isOptimizing)
                        Text(
                            text = when {
                                isOptimizing -> "Optimizing" + (appliedProfileName?.let { " · $it" } ?: "")
                                optStatus != null -> optStatus
                                else -> "Waiting for Shizuku / profile apply"
                            },
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AutomationControlCard(
    isEnabled: Boolean,
    isOptimizing: Boolean,
    onEnabledChange: (Boolean) -> Unit,
    onRestoreNow: () -> Unit,
    onForceRestore: () -> Unit
) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "Automatic Optimization",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (isEnabled) "Armed — apply on game launch, restore on exit" else "Paused",
                    style = MaterialTheme.typography.bodyMedium
                )
                Switch(checked = isEnabled, onCheckedChange = onEnabledChange)
            }
            Text(
                text = "Also controlled from the Quick Settings tile and the persistent notification.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedButton(
                onClick = onRestoreNow,
                enabled = isOptimizing,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Restore Everything Now")
            }
            TextButton(
                onClick = onForceRestore,
                enabled = isOptimizing,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Force Restore (if the button above didn't work)")
            }
        }
    }
}

@Composable
private fun OverlayControlCard(
    enabled: Boolean,
    permissionGranted: Boolean,
    onEnabledChange: (Boolean) -> Unit
) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "Performance Overlay",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Small floating FPS / RAM indicator",
                    style = MaterialTheme.typography.bodyMedium
                )
                Switch(
                    checked = enabled,
                    onCheckedChange = onEnabledChange,
                    enabled = permissionGranted
                )
            }
            if (!permissionGranted) {
                Text(
                    text = "Grant \"Display Over Other Apps\" above to use this.",
                    style = MaterialTheme.typography.bodySmall
                )
            } else {
                Text(
                    text = "The FPS reading is an approximation of device frame timing, " +
                        "not a frame-accurate in-game counter.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun ShizukuCard(
    isBinderAlive: Boolean,
    isGranted: Boolean,
    onRequestPermission: () -> Unit
) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "Shizuku",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )

            val statusLabel = when {
                !isBinderAlive -> "Not Connected"
                !isGranted -> "Running (permission needed)"
                else -> "Connected"
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatusDot(ok = isBinderAlive && isGranted)
                Text(text = statusLabel)
            }

            Button(onClick = onRequestPermission, enabled = isBinderAlive) {
                Text("Request Shizuku Permission")
            }

            if (!isBinderAlive) {
                Text(
                    text = "Install and start the Shizuku app first (via ADB or root), " +
                        "then return here.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun PermissionCard(
    title: String,
    description: String,
    granted: Boolean,
    onRequest: () -> Unit
) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatusDot(ok = granted)
                Text(text = if (granted) "Granted" else "Not granted")
            }
            Text(text = description, style = MaterialTheme.typography.bodySmall)
            if (!granted) {
                OutlinedButton(onClick = onRequest) {
                    Text("Grant $title")
                }
            }
        }
    }
}

@Composable
private fun StatusDot(ok: Boolean) {
    Box(
        modifier = Modifier
            .size(10.dp)
            .background(
                color = if (ok) Color(0xFF2E7D32) else Color(0xFFC62828),
                shape = CircleShape
            )
    )
}
