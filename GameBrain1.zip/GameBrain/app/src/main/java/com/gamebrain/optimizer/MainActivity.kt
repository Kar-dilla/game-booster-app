package com.gamebrain.optimizer

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.gamebrain.optimizer.ui.GamesScreen
import com.gamebrain.optimizer.ui.HomeScreen
import com.gamebrain.optimizer.ui.ProfilesScreen
import com.gamebrain.optimizer.ui.navigation.NavRoutes
import com.gamebrain.optimizer.ui.theme.GameBrainTheme

/**
 * Single-activity host for the Compose UI with bottom navigation.
 */
class MainActivity : ComponentActivity() {

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* no-op */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermissionIfNeeded()
        setContent {
            GameBrainTheme {
                GameBrainApp()
            }
        }
    }

    /**
     * On API 33+, posting a notification (including the persistent
     * optimization-status notification) requires runtime permission.
     * Without it the foreground service still runs, it just won't show a
     * visible notification — so we ask for it up front.
     */
    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}

@Composable
private fun GameBrainApp() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = currentDestination?.hierarchy?.any { it.route == NavRoutes.HOME } == true,
                    onClick = {
                        navController.navigate(NavRoutes.HOME) {
                            popUpTo(NavRoutes.HOME) { inclusive = true }
                            launchSingleTop = true
                        }
                    },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home") }
                )
                NavigationBarItem(
                    selected = currentDestination?.hierarchy?.any { it.route == NavRoutes.GAMES } == true,
                    onClick = {
                        navController.navigate(NavRoutes.GAMES) {
                            popUpTo(NavRoutes.HOME)
                            launchSingleTop = true
                        }
                    },
                    icon = { Icon(Icons.Default.List, contentDescription = "Games") },
                    label = { Text("Games") }
                )
                NavigationBarItem(
                    selected = currentDestination?.hierarchy?.any { it.route == NavRoutes.PROFILES } == true,
                    onClick = {
                        navController.navigate(NavRoutes.PROFILES) {
                            popUpTo(NavRoutes.HOME)
                            launchSingleTop = true
                        }
                    },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Profiles") },
                    label = { Text("Profiles") }
                )
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = NavRoutes.HOME,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(NavRoutes.HOME) { HomeScreen() }
            composable(NavRoutes.GAMES) { GamesScreen() }
            composable(NavRoutes.PROFILES) { ProfilesScreen() }
        }
    }
}
