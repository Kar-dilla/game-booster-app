package com.gamebrain.optimizer.service

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.gamebrain.optimizer.detection.AppDetectionManager
import com.gamebrain.optimizer.optimization.OptimizationManager

/**
 * Accessibility Service used for reliable foreground-app detection.
 *
 * Listens for window-state and window-content changes and reports the
 * package that just became active to [AppDetectionManager].
 * Reports foreground changes to AppDetectionManager; OptimizationManager applies profiles.
 */
class GameBrainAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        try {
            Log.i(TAG, "Accessibility service connected")
            // Both calls are idempotent no-ops if the Application already
            // initialised them; this just guards against edge cases where the
            // system restarts this service independently of the process start.
            AppDetectionManager.init(applicationContext)
            OptimizationManager.init(applicationContext)
            // Start UsageStats backup as a secondary signal
            AppDetectionManager.startUsageStatsBackup()
        } catch (e: Exception) {
            // Never let a wiring problem here crash the whole accessibility
            // pipeline — the app should keep working with detection simply
            // degraded (usage-stats backup only) rather than not at all.
            Log.e(TAG, "onServiceConnected failed", e)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        try {
            when (event.eventType) {
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
                AccessibilityEvent.TYPE_WINDOWS_CHANGED -> {
                    val packageName = event.packageName?.toString()
                    if (!packageName.isNullOrBlank()) {
                        AppDetectionManager.onForegroundAppChanged(packageName)
                    }
                }
                else -> { /* ignore other event types */ }
            }
        } catch (e: Exception) {
            // A malformed/edge-case event should never crash the service —
            // that would silently kill foreground detection until the user
            // manually re-enables Accessibility in Settings.
            Log.e(TAG, "onAccessibilityEvent failed", e)
        }
    }

    override fun onInterrupt() {
        Log.w(TAG, "Accessibility service interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        AppDetectionManager.stopUsageStatsBackup()
        Log.i(TAG, "Accessibility service destroyed")
    }

    companion object {
        private const val TAG = "GameBrainA11y"
    }
}
