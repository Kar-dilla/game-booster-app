package com.gamebrain.optimizer.overlay

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.util.Log
import com.gamebrain.optimizer.detection.AppDetectionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch

/**
 * Decides when [GameBrainOverlayService] should actually be showing.
 *
 * The overlay's on/off switch in [OverlaySettings] only expresses "I want
 * this feature", not "show it right now" — the previous wiring conflated the
 * two and started the service the instant the switch was flipped, so it sat
 * on screen the whole time GameBrain was installed, not just during a
 * marked game. This mirrors [com.gamebrain.optimizer.optimization.OptimizationManager]'s
 * pattern: it's the only place that starts/stops the overlay service, driven
 * by the same [AppDetectionManager.isForegroundGame] signal, so the overlay
 * and the performance tweaks always agree on "am I in a game right now".
 */
object OverlayController {

    private const val TAG = "OverlayController"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private var appContext: Context? = null

    /** Tracks whether we believe the service is currently running, to avoid redundant start/stop calls. */
    private var serviceRunning = false

    fun init(context: Context) {
        if (job != null) return
        appContext = context.applicationContext

        job = scope.launch {
            combine(
                OverlaySettings.isEnabled,
                AppDetectionManager.isForegroundGame
            ) { wantsOverlay, inGame -> wantsOverlay && inGame }
                .distinctUntilChanged()
                .collect { shouldShow -> applyState(shouldShow) }
        }
    }

    /** Re-evaluates immediately — call after the permission is granted/revoked from Settings. */
    fun refresh() {
        val wantsOverlay = OverlaySettings.isEnabled.value
        val inGame = AppDetectionManager.isForegroundGame.value
        applyState(wantsOverlay && inGame)
    }

    private fun applyState(shouldShow: Boolean) {
        val ctx = appContext ?: return
        if (shouldShow) {
            if (serviceRunning) return
            if (!Settings.canDrawOverlays(ctx)) {
                Log.w(TAG, "Overlay wanted but 'Display over other apps' isn't granted — skipping")
                return
            }
            try {
                ctx.startService(Intent(ctx, GameBrainOverlayService::class.java))
                serviceRunning = true
            } catch (e: Exception) {
                Log.w(TAG, "Failed to start overlay: ${e.message}")
            }
        } else {
            if (!serviceRunning) return
            try {
                ctx.stopService(Intent(ctx, GameBrainOverlayService::class.java))
            } catch (e: Exception) {
                Log.w(TAG, "Failed to stop overlay: ${e.message}")
            } finally {
                serviceRunning = false
            }
        }
    }
}
