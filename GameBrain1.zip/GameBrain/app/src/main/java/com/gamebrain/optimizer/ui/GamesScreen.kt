package com.gamebrain.optimizer.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.gamebrain.optimizer.data.GamePreferencesRepository
import com.gamebrain.optimizer.data.Profile
import com.gamebrain.optimizer.detection.AppDetectionManager
import com.gamebrain.optimizer.detection.InstalledApp
import kotlinx.coroutines.launch

/**
 * Games management screen.
 *
 * - Lists installed launchable apps
 * - Lets the user mark / unmark apps as games
 * - Assigns a profile to each marked game
 * - Persists everything via [GamePreferencesRepository]
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GamesScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repository = remember { GamePreferencesRepository(context) }

    val games by repository.games.collectAsState(initial = emptyList())
    val gamePackages = remember(games) { games.associateBy { it.packageName } }

    var installedApps by remember { mutableStateOf<List<InstalledApp>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var showOnlyGames by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        loading = true
        installedApps = AppDetectionManager.getInstalledLaunchableApps(context)
        loading = false
    }

    val filtered = remember(installedApps, showOnlyGames, searchQuery, gamePackages) {
        installedApps
            .filter { app ->
                val matchesSearch = searchQuery.isBlank() ||
                    app.label.contains(searchQuery, ignoreCase = true) ||
                    app.packageName.contains(searchQuery, ignoreCase = true)
                val matchesFilter = !showOnlyGames || gamePackages.containsKey(app.packageName)
                matchesSearch && matchesFilter
            }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Games") })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            // Toolbar row
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Mark apps as games and assign a profile. " +
                        "When a marked game comes to the foreground, GameBrain will detect it.",
                    style = MaterialTheme.typography.bodySmall
                )
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Search apps") },
                    singleLine = true
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = showOnlyGames,
                        onClick = { showOnlyGames = !showOnlyGames },
                        label = { Text("Games only (${games.size})") }
                    )
                    if (loading) {
                        Text("Loading apps…", style = MaterialTheme.typography.bodySmall)
                    } else {
                        Text(
                            "${filtered.size} apps",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filtered, key = { it.packageName }) { app ->
                    val entry = gamePackages[app.packageName]
                    val isGame = entry != null
                    GameAppRow(
                        app = app,
                        isGame = isGame,
                        profile = entry?.profile ?: Profile.BALANCED,
                        onToggleGame = { checked ->
                            scope.launch {
                                if (checked) {
                                    repository.addGame(app.packageName, Profile.BALANCED)
                                } else {
                                    repository.removeGame(app.packageName)
                                }
                            }
                        },
                        onProfileChange = { profile ->
                            scope.launch {
                                repository.setProfile(app.packageName, profile)
                            }
                        }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GameAppRow(
    app: InstalledApp,
    isGame: Boolean,
    profile: Profile,
    onToggleGame: (Boolean) -> Unit,
    onProfileChange: (Profile) -> Unit
) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Checkbox(
                    checked = isGame,
                    onCheckedChange = onToggleGame
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = app.label,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = app.packageName,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (isGame) {
                ProfileDropdown(
                    selected = profile,
                    onSelected = onProfileChange
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProfileDropdown(
    selected: Profile,
    onSelected: (Profile) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = it }
    ) {
        OutlinedTextField(
            value = selected.displayName,
            onValueChange = {},
            readOnly = true,
            label = { Text("Profile") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            Profile.entries.forEach { profile ->
                DropdownMenuItem(
                    text = { Text(profile.displayName) },
                    onClick = {
                        onSelected(profile)
                        expanded = false
                    }
                )
            }
        }
    }
}
