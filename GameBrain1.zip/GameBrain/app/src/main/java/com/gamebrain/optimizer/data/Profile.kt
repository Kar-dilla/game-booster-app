package com.gamebrain.optimizer.data

/**
 * Built-in performance profiles with concrete optimization actions (Part 3).
 */
enum class Profile(
    val id: String,
    val displayName: String,
    val description: String
) {
    EXTREME(
        id = "extreme",
        displayName = "Extreme",
        description = "Maximum performance. Highest refresh rate, animations off, aggressive background cleanup, lowest touch latency."
    ),
    COMPETITIVE(
        id = "competitive",
        displayName = "Competitive",
        description = "High performance with balanced system load. Highest refresh rate, animations off, background cleanup. Suitable for ranked play."
    ),
    BALANCED(
        id = "balanced",
        displayName = "Balanced",
        description = "Good performance while keeping battery and thermals reasonable. 90 Hz target, half-speed animations. Default for most games."
    ),
    BATTERY(
        id = "battery",
        displayName = "Battery",
        description = "Prioritise battery life. 60 Hz target, normal animations, lighter system tweaks."
    );

    companion object {
        fun fromId(id: String?): Profile =
            entries.firstOrNull { it.id == id } ?: BALANCED
    }
}
