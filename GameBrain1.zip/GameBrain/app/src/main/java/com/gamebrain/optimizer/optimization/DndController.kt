package com.gamebrain.optimizer.optimization

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Do Not Disturb toggle for the overlay.
 *
 * Deliberately implemented via [NotificationManager] directly rather than a
 * Shizuku shell command (`cmd notification set_dnd` does exist, but going
 * through the real API means this keeps working even if Shizuku's
 * connection drops mid-session — same reasoning as the auto-sync toggle).
 * It needs one-time "Notification access" (Do Not Disturb access) granted
 * from Settings — a normal special-access permission, same category as the
 * Overlay and Accessibility permissions this app already asks for.
 */
object DndController {

    private const val TAG = "DndController"

    private val _isDndOn = MutableStateFlow(false)
    val isDndOn: StateFlow<Boolean> = _isDndOn.asStateFlow()

    fun hasPermission(context: Context): Boolean {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return nm.isNotificationPolicyAccessGranted
    }

    /** Opens the system screen to grant DND access. Safe to call from a Service context. */
    fun requestPermission(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.w(TAG, "Could not open DND access settings: ${e.message}")
        }
    }

    fun setEnabled(context: Context, enabled: Boolean) {
        if (!hasPermission(context)) {
            // Only chase the permission when actively turning DND on from a
            // user tap. A courtesy "turn it off" call (e.g. on game exit)
            // should never pop a settings screen if we never had permission
            // to begin with — there'd be nothing to turn off anyway.
            if (enabled) requestPermission(context)
            return
        }
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.setInterruptionFilter(
                if (enabled) NotificationManager.INTERRUPTION_FILTER_PRIORITY
                else NotificationManager.INTERRUPTION_FILTER_ALL
            )
            _isDndOn.value = enabled
        } catch (e: Exception) {
            Log.w(TAG, "Failed to set DND to $enabled: ${e.message}")
        }
    }

    /** Refreshes [isDndOn] from the actual system state (call on overlay show/resume). */
    fun refresh(context: Context) {
        if (!hasPermission(context)) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        _isDndOn.value = nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
    }
}
