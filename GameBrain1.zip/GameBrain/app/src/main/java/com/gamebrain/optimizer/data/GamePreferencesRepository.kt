package com.gamebrain.optimizer.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.gameDataStore: DataStore<Preferences> by preferencesDataStore(name = "gamebrain_prefs")

/**
 * Local persistence for the user's game list and per-game profile assignments.
 * Uses DataStore Preferences — no remote or database dependency.
 */
class GamePreferencesRepository(private val context: Context) {

    private val gamesKey = stringSetPreferencesKey("game_packages")
    private fun profileKey(packageName: String) =
        stringPreferencesKey("profile_$packageName")

    /** Emits the full list of marked games with their assigned profiles. */
    val games: Flow<List<GameEntry>> = context.gameDataStore.data.map { prefs ->
        val packages = prefs[gamesKey] ?: emptySet()
        packages.map { pkg ->
            val profileId = prefs[profileKey(pkg)] ?: Profile.BALANCED.id
            GameEntry(packageName = pkg, profileId = profileId)
        }.sortedBy { it.packageName }
    }

    /** Emits only the set of package names marked as games. */
    val gamePackages: Flow<Set<String>> = context.gameDataStore.data.map { prefs ->
        prefs[gamesKey] ?: emptySet()
    }

    suspend fun addGame(packageName: String, profile: Profile = Profile.BALANCED) {
        context.gameDataStore.edit { prefs ->
            val current = prefs[gamesKey]?.toMutableSet() ?: mutableSetOf()
            current.add(packageName)
            prefs[gamesKey] = current
            prefs[profileKey(packageName)] = profile.id
        }
    }

    suspend fun removeGame(packageName: String) {
        context.gameDataStore.edit { prefs ->
            val current = prefs[gamesKey]?.toMutableSet() ?: mutableSetOf()
            current.remove(packageName)
            prefs[gamesKey] = current
            prefs.remove(profileKey(packageName))
        }
    }

    suspend fun setProfile(packageName: String, profile: Profile) {
        context.gameDataStore.edit { prefs ->
            // Ensure the package is in the game list
            val current = prefs[gamesKey]?.toMutableSet() ?: mutableSetOf()
            current.add(packageName)
            prefs[gamesKey] = current
            prefs[profileKey(packageName)] = profile.id
        }
    }
}
