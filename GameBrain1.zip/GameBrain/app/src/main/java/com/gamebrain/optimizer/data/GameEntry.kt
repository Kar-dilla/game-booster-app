package com.gamebrain.optimizer.data

/**
 * A user-marked game: package name + assigned profile.
 */
data class GameEntry(
    val packageName: String,
    val profileId: String = Profile.BALANCED.id
) {
    val profile: Profile
        get() = Profile.fromId(profileId)
}
