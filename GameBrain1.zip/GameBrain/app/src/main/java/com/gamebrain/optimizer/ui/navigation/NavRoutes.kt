package com.gamebrain.optimizer.ui.navigation

object NavRoutes {
    const val HOME = "home"
    const val GAMES = "games"
    const val PROFILES = "profiles"
}
