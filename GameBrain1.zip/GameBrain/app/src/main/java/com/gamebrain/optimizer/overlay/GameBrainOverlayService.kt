package com.gamebrain.optimizer.overlay

import android.app.ActivityManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.gamebrain.optimizer.optimization.DndController
import com.gamebrain.optimizer.optimization.OptimizationManager
import com.gamebrain.optimizer.optimization.ScreenPinController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Floating in-game control: a small bubble docked to a screen edge that
 * expands, on tap, into a panel showing FPS/RAM plus a few quick toggles.
 *
 * Honesty notes carried over from the original version:
 *  - FPS is Choreographer-derived vsync timing, a system-wide proxy, not the
 *    foreground game's actual internal frame rate (Android doesn't expose
 *    that to third-party apps without root/GPU instrumentation).
 *  - RAM is whole-device memory, not per-app.
 *
 * Touch handling: the bubble/panel must be touchable to be draggable and
 * tappable, unlike the old pure-readout version. FLAG_NOT_TOUCH_MODAL keeps
 * everything *outside* this view's bounds passing through to the game
 * underneath — only the small bubble (or the panel, while expanded) actually
 * intercepts touches, the same tradeoff every floating-control app (chat
 * heads, GFX tools, etc.) makes.
 */
class GameBrainOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var container: FrameLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var expanded = false
    private var fpsText: TextView? = null
    private var ramText: TextView? = null
    private var pinRow: ToggleRow? = null
    private var dndRow: ToggleRow? = null
    private var syncRow: ToggleRow? = null

    private var frameCount = 0
    private var lastFpsSampleAtNs = 0L
    private var lastFps = 0
    private val choreographer = Choreographer.getInstance()
    private var frameCallbackActive = false

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            frameCount++
            if (lastFpsSampleAtNs == 0L) lastFpsSampleAtNs = frameTimeNanos
            val elapsedNs = frameTimeNanos - lastFpsSampleAtNs
            if (elapsedNs >= 1_000_000_000L) {
                lastFps = frameCount
                frameCount = 0
                lastFpsSampleAtNs = frameTimeNanos
            }
            if (frameCallbackActive) choreographer.postFrameCallback(this)
        }
    }

    private val updateRunnable = object : Runnable {
        override fun run() {
            updateReadout()
            mainHandler.postDelayed(this, UPDATE_INTERVAL_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        try {
            addOverlay()
            frameCallbackActive = true
            choreographer.postFrameCallback(frameCallback)
            mainHandler.post(updateRunnable)
        } catch (e: Exception) {
            Log.w(TAG, "Overlay could not be shown, stopping: ${e.message}")
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        frameCallbackActive = false
        try {
            choreographer.removeFrameCallback(frameCallback)
        } catch (_: Exception) { /* best effort */ }
        mainHandler.removeCallbacks(updateRunnable)
        // Defensive reset: never leave the phone silently in DND after the
        // overlay itself goes away. Screen pin is deliberately left alone —
        // see ScreenPinController's docs.
        DndController.setEnabled(this, false)
        serviceScope.cancel()
        removeOverlay()
        super.onDestroy()
    }

    // ---------------------------------------------------------------------
    // View construction
    // ---------------------------------------------------------------------

    private fun addOverlay() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 300
        }
        params = lp

        val root = FrameLayout(this)
        container = root
        showBubble()
        wm.addView(root, lp)
    }

    private fun removeOverlay() {
        val root = container ?: return
        try {
            windowManager?.removeView(root)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to remove overlay view: ${e.message}")
        }
        container = null
        windowManager = null
    }

    /** Collapsed state: a small round tab docked to whichever edge it was last dropped on. */
    private fun showBubble() {
        expanded = false
        val root = container ?: return
        root.removeAllViews()
        fpsText = null; ramText = null; pinRow = null; dndRow = null; syncRow = null

        val bubble = TextView(this).apply {
            text = "GB"
            setTextColor(Color.WHITE)
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = pillDrawable(Color.argb(210, 30, 30, 34))
        }
        root.addView(bubble, FrameLayout.LayoutParams(WRAP, WRAP))
        attachDragAndTap(bubble, onTap = { showPanel() })
        resizeWindowToWrapContent()
    }

    /** Expanded state: FPS/RAM readout plus quick toggles. */
    private fun showPanel() {
        expanded = true
        val root = container ?: return
        root.removeAllViews()

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = cardDrawable()
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "GameBrain"
            setTextColor(Color.WHITE)
            textSize = 13f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val collapseHandle = TextView(this).apply {
            text = "—"
            setTextColor(Color.argb(200, 255, 255, 255))
            textSize = 16f
            setPadding(dp(10), 0, dp(4), 0)
        }
        header.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
        header.addView(collapseHandle, LinearLayout.LayoutParams(WRAP, WRAP))
        collapseHandle.setOnClickListener { showBubble() }
        panel.addView(header)

        fpsText = TextView(this).apply {
            setTextColor(Color.argb(230, 180, 255, 190))
            textSize = 12f
            setPadding(0, dp(4), 0, 0)
        }
        ramText = TextView(this).apply {
            setTextColor(Color.argb(230, 180, 210, 255))
            textSize = 12f
        }
        panel.addView(fpsText)
        panel.addView(ramText)

        val divider = View(this).apply {
            setBackgroundColor(Color.argb(60, 255, 255, 255))
        }
        panel.addView(
            divider,
            LinearLayout.LayoutParams(MATCH, dp(1)).apply { topMargin = dp(8); bottomMargin = dp(8) }
        )

        pinRow = ToggleRow(this, "Screen lock").also { row ->
            row.setChecked(ScreenPinController.isPinned.value)
            row.onToggle = { turnOn ->
                val pkg = OptimizationManager.getActiveGamePackage()
                serviceScope.launch {
                    val ok = if (turnOn && pkg != null) {
                        ScreenPinController.pin(pkg)
                    } else {
                        ScreenPinController.unpin(); true
                    }
                    row.setChecked(if (turnOn) ok && ScreenPinController.isPinned.value else false)
                }
            }
            panel.addView(row.view)
        }

        dndRow = ToggleRow(this, "Do Not Disturb").also { row ->
            row.setChecked(DndController.isDndOn.value)
            row.onToggle = { turnOn ->
                DndController.setEnabled(this@GameBrainOverlayService, turnOn)
                row.setChecked(DndController.isDndOn.value)
            }
            panel.addView(row.view)
        }

        syncRow = ToggleRow(this, "Background sync").also { row ->
            row.setChecked(OptimizationManager.isAutoSyncEnabled())
            row.onToggle = { turnOn ->
                OptimizationManager.setAutoSync(turnOn)
                row.setChecked(turnOn)
            }
            panel.addView(row.view)
        }

        val killBg = TextView(this).apply {
            text = "Clean background now"
            setTextColor(Color.WHITE)
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = pillDrawable(Color.argb(200, 70, 40, 40))
        }
        killBg.setOnClickListener {
            killBg.text = "Cleaning…"
            serviceScope.launch {
                OptimizationManager.killBackgroundNow()
                killBg.text = "Clean background now"
            }
        }
        panel.addView(
            killBg,
            LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
        )

        root.addView(panel, FrameLayout.LayoutParams(WRAP, WRAP))
        attachDragAndTap(header, onTap = null)
        resizeWindowToWrapContent()

        DndController.refresh(this)
        dndRow?.setChecked(DndController.isDndOn.value)
    }

    // ---------------------------------------------------------------------
    // Drag + tap + edge snap
    // ---------------------------------------------------------------------

    private fun attachDragAndTap(handle: View, onTap: (() -> Unit)?) {
        var startRawX = 0f
        var startRawY = 0f
        var startX = 0
        var startY = 0
        var moved = false

        handle.setOnTouchListener { _, event ->
            val wm = windowManager ?: return@setOnTouchListener false
            val lp = params ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startRawX = event.rawX; startRawY = event.rawY
                    startX = lp.x; startY = lp.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - startRawX).toInt()
                    val dy = (event.rawY - startRawY).toInt()
                    if (abs(dx) > TOUCH_SLOP || abs(dy) > TOUCH_SLOP) moved = true
                    if (moved) {
                        lp.x = startX + dx
                        lp.y = (startY + dy).coerceAtLeast(0)
                        try { wm.updateViewLayout(container, lp) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        onTap?.invoke()
                    } else if (!expanded) {
                        snapToNearestEdge()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun snapToNearestEdge() {
        val wm = windowManager ?: return
        val lp = params ?: return
        val screenWidth = screenWidthPx()
        val bubbleWidth = container?.width?.takeIf { it > 0 } ?: dp(44)
        val midpoint = lp.x + bubbleWidth / 2
        lp.x = if (midpoint < screenWidth / 2) 0 else (screenWidth - bubbleWidth)
        try { wm.updateViewLayout(container, lp) } catch (_: Exception) {}
    }

    private fun resizeWindowToWrapContent() {
        val wm = windowManager ?: return
        val lp = params ?: return
        try { wm.updateViewLayout(container, lp) } catch (_: Exception) {}
    }

    private fun screenWidthPx(): Int {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager?.defaultDisplay?.getMetrics(dm)
        return dm.widthPixels.takeIf { it > 0 } ?: 1080
    }

    // ---------------------------------------------------------------------
    // Data readout
    // ---------------------------------------------------------------------

    private fun updateReadout() {
        fpsText?.text = "~$lastFps fps"
        ramText?.text = readRamUsage()
    }

    private fun readRamUsage(): String {
        return try {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val info = ActivityManager.MemoryInfo()
            am.getMemoryInfo(info)
            val totalGb = info.totalMem / 1_073_741_824.0
            val usedGb = (info.totalMem - info.availMem) / 1_073_741_824.0
            String.format("%.1f/%.1f GB RAM", usedGb, totalGb)
        } catch (e: Exception) {
            "RAM n/a"
        }
    }

    // ---------------------------------------------------------------------
    // Small styling helpers
    // ---------------------------------------------------------------------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun pillDrawable(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    private fun cardDrawable() = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(14).toFloat()
        setColor(Color.argb(225, 22, 22, 26))
        setStroke(dp(1), Color.argb(60, 255, 255, 255))
    }

    companion object {
        private const val TAG = "GameBrainOverlay"
        private const val UPDATE_INTERVAL_MS = 1000L
        private const val TOUCH_SLOP = 12
        private const val WRAP = FrameLayout.LayoutParams.WRAP_CONTENT
        private const val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    }
}

/** A single tappable "label — on/off pill" row used for the panel's toggles. */
private class ToggleRow(context: Context, label: String) {
    var onToggle: ((Boolean) -> Unit)? = null
    private var checked = false
    private val pill: TextView
    val view: LinearLayout

    init {
        view = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dpLocal(context, 6), 0, dpLocal(context, 6))
        }
        val text = TextView(context).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 12f
        }
        pill = TextView(context).apply {
            textSize = 10f
            setPadding(dpLocal(context, 10), dpLocal(context, 3), dpLocal(context, 10), dpLocal(context, 3))
        }
        view.addView(text, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        view.addView(pill, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        view.setOnClickListener { onToggle?.invoke(!checked) }
        render()
    }

    fun setChecked(value: Boolean) {
        checked = value
        render()
    }

    private fun render() {
        pill.text = if (checked) "ON" else "OFF"
        pill.setTextColor(Color.WHITE)
        val drawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 999f
            setColor(if (checked) Color.argb(220, 60, 160, 90) else Color.argb(180, 70, 70, 76))
        }
        pill.background = drawable
    }
}

private fun dpLocal(context: Context, v: Int): Int = (v * context.resources.displayMetrics.density).toInt()
