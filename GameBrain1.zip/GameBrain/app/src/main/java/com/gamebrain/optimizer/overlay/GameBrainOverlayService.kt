package com.gamebrain.optimizer.overlay

import android.app.ActivityManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Optional, very light floating indicator: an approximate frame-timing
 * reading plus current RAM usage. Turned on/off from Home screen, gated on
 * the "Display over other apps" permission.
 *
 * Honesty note: Android does not expose the *foreground game's* real FPS to
 * a third-party app without root/GPU instrumentation. What this overlay
 * shows via [Choreographer] is the system's own vsync-driven frame timing —
 * a reasonable proxy for "is the device keeping up", not a frame-accurate
 * in-game counter. That limitation is called out in the README too.
 *
 * Deliberately minimal: one small TextView, updated once per second, no
 * animations, no view hierarchy churn — this must not itself cost the
 * frame budget it's trying to report on.
 */
class GameBrainOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: TextView? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private var frameCount = 0
    private var lastFpsSampleAtNs = 0L
    private var lastFps = 0
    private val choreographer = Choreographer.getInstance()
    private var frameCallbackActive = false

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            frameCount++
            if (lastFpsSampleAtNs == 0L) lastFpsSampleAtNs = frameTimeNanos
            val elapsedNs = frameTimeNanos - lastFpsSampleAtNs
            if (elapsedNs >= 1_000_000_000L) {
                lastFps = frameCount
                frameCount = 0
                lastFpsSampleAtNs = frameTimeNanos
            }
            if (frameCallbackActive) choreographer.postFrameCallback(this)
        }
    }

    private val updateRunnable = object : Runnable {
        override fun run() {
            updateText()
            mainHandler.postDelayed(this, UPDATE_INTERVAL_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        try {
            addOverlay()
            frameCallbackActive = true
            choreographer.postFrameCallback(frameCallback)
            mainHandler.post(updateRunnable)
        } catch (e: Exception) {
            // Most commonly: overlay permission was revoked after the toggle
            // was turned on, or the display token is otherwise unusable.
            // Never crash the app over a cosmetic overlay — just stop.
            Log.w(TAG, "Overlay could not be shown, stopping: ${e.message}")
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Sticky so a process kill while gaming doesn't silently leave the
        // toggle "on" with nothing showing — Android will restart it.
        return START_STICKY
    }

    override fun onDestroy() {
        frameCallbackActive = false
        try {
            choreographer.removeFrameCallback(frameCallback)
        } catch (_: Exception) { /* best effort */ }
        mainHandler.removeCallbacks(updateRunnable)
        removeOverlay()
        super.onDestroy()
    }

    private fun addOverlay() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 120
        }

        val text = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 11f
            setPadding(16, 8, 16, 8)
            setBackgroundColor(Color.argb(150, 0, 0, 0))
            text = "GameBrain\n…"
        }
        // Wrap in a LinearLayout so future indicators can be added without
        // touching the WindowManager params.
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(text)
        }
        overlayView = text
        wm.addView(root, params)
    }

    private fun removeOverlay() {
        val view = overlayView ?: return
        val parent = view.parent
        try {
            (parent as? android.view.ViewGroup)?.let { grp ->
                windowManager?.removeView(grp)
            } ?: windowManager?.removeView(view)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to remove overlay view: ${e.message}")
        }
        overlayView = null
        windowManager = null
    }

    private fun updateText() {
        val view = overlayView ?: return
        val ramLine = readRamUsage()
        view.text = "GameBrain\n~${lastFps} fps · $ramLine"
    }

    /** Returns a short "used / total" RAM string in whole GB, e.g. "5.2/8.0 GB". */
    private fun readRamUsage(): String {
        return try {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val info = ActivityManager.MemoryInfo()
            am.getMemoryInfo(info)
            val totalGb = info.totalMem / 1_073_741_824.0
            val usedGb = (info.totalMem - info.availMem) / 1_073_741_824.0
            String.format("%.1f/%.1f GB", usedGb, totalGb)
        } catch (e: Exception) {
            "RAM n/a"
        }
    }

    companion object {
        private const val TAG = "GameBrainOverlay"
        private const val UPDATE_INTERVAL_MS = 1000L
    }
}
