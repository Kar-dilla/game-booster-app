package com.gamebrain.optimizer.service

import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.gamebrain.optimizer.optimization.OptimizationManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Quick Settings Tile: lets the user arm/disarm GameBrain's automatic
 * optimization without opening the app. Mirrors [OptimizationManager.isEnabled]
 * live while the tile is visible (Quick Settings panel open).
 */
class GameBrainTileService : TileService() {

    private var scope: CoroutineScope? = null
    private var watchJob: Job? = null

    override fun onStartListening() {
        super.onStartListening()
        refreshTile()
        val s = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
        scope = s
        watchJob = s.launch {
            OptimizationManager.isEnabled.collect { refreshTile() }
        }
    }

    override fun onStopListening() {
        watchJob?.cancel()
        watchJob = null
        scope?.cancel()
        scope = null
        super.onStopListening()
    }

    override fun onClick() {
        super.onClick()
        OptimizationManager.setEnabled(!OptimizationManager.isEnabled.value)
        // Optimistic UI update; the live collector above will correct this
        // once the actual state change (and any restore) completes.
        refreshTile()
    }

    private fun refreshTile() {
        val tile = qsTile ?: return
        val enabled = OptimizationManager.isEnabled.value
        tile.label = "GameBrain"
        tile.state = if (enabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            tile.subtitle = if (enabled) "Auto-optimize on" else "Auto-optimize off"
        }
        tile.icon = Icon.createWithResource(this, android.R.drawable.ic_menu_manage)
        tile.updateTile()
    }
}
