package com.gamebrain.optimizer.detection

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.util.Log
import com.gamebrain.optimizer.data.GameEntry
import com.gamebrain.optimizer.data.GamePreferencesRepository
import com.gamebrain.optimizer.data.Profile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Central hub for foreground-app detection.
 *
 * Primary source: Accessibility Service (TYPE_WINDOW_STATE_CHANGED).
 * Backup source: periodic UsageStatsManager poll.
 *
 * Exposes observable state for the UI and for future optimization logic.
 */
object AppDetectionManager {

    private const val TAG = "AppDetectionManager"
    private const val USAGE_POLL_INTERVAL_MS = 2_000L

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _foregroundPackage = MutableStateFlow<String?>(null)
    val foregroundPackage: StateFlow<String?> = _foregroundPackage.asStateFlow()

    private val _foregroundAppLabel = MutableStateFlow<String?>(null)
    val foregroundAppLabel: StateFlow<String?> = _foregroundAppLabel.asStateFlow()

    private val _isForegroundGame = MutableStateFlow(false)
    val isForegroundGame: StateFlow<Boolean> = _isForegroundGame.asStateFlow()

    private val _activeGameEntry = MutableStateFlow<GameEntry?>(null)
    val activeGameEntry: StateFlow<GameEntry?> = _activeGameEntry.asStateFlow()

    private var repository: GamePreferencesRepository? = null
    private var appContext: Context? = null
    private var usagePollJob: Job? = null
    private var gamePackagesCache: Set<String> = emptySet()

    fun init(context: Context) {
        if (appContext != null) return
        appContext = context.applicationContext
        repository = GamePreferencesRepository(context.applicationContext)

        // Keep a local cache of game packages so the accessibility callback stays cheap.
        scope.launch {
            repository!!.gamePackages.collect { packages ->
                gamePackagesCache = packages
                // Re-evaluate current foreground against the updated list.
                val current = _foregroundPackage.value
                if (current != null) {
                    evaluateForeground(current)
                }
            }
        }
    }

    /**
     * Called by the Accessibility Service when a new package comes to the foreground.
     */
    fun onForegroundAppChanged(packageName: String?) {
        if (packageName.isNullOrBlank()) return
        // Ignore our own process
        val ctx = appContext ?: return
        if (packageName == ctx.packageName) return

        scope.launch {
            evaluateForeground(packageName)
        }
    }

    /**
     * Start (or restart) the UsageStats backup poller.
     * Call when Usage Access is granted / service starts.
     */
    fun startUsageStatsBackup() {
        usagePollJob?.cancel()
        usagePollJob = scope.launch {
            while (isActive) {
                try {
                    val pkg = queryForegroundViaUsageStats()
                    if (pkg != null && pkg != _foregroundPackage.value) {
                        evaluateForeground(pkg)
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "UsageStats poll failed: ${e.message}")
                }
                delay(USAGE_POLL_INTERVAL_MS)
            }
        }
    }

    fun stopUsageStatsBackup() {
        usagePollJob?.cancel()
        usagePollJob = null
    }

    private suspend fun evaluateForeground(packageName: String) {
        val ctx = appContext ?: return
        val label = resolveLabel(ctx, packageName)
        val isGame = gamePackagesCache.contains(packageName)

        var entry: GameEntry? = null
        if (isGame) {
            val games = repository?.games?.first() ?: emptyList()
            entry = games.firstOrNull { it.packageName == packageName }
                ?: GameEntry(packageName, Profile.BALANCED.id)
        }

        _foregroundPackage.value = packageName
        _foregroundAppLabel.value = label
        _isForegroundGame.value = isGame
        _activeGameEntry.value = entry

        Log.d(TAG, "Foreground: $packageName ($label) isGame=$isGame profile=${entry?.profileId}")
    }

    private fun resolveLabel(context: Context, packageName: String): String {
        return try {
            val pm = context.packageManager
            val ai = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(ai).toString()
        } catch (e: PackageManager.NameNotFoundException) {
            packageName
        }
    }

    /**
     * Best-effort foreground package via UsageStatsManager (last MOVE_TO_FOREGROUND event).
     */
    private suspend fun queryForegroundViaUsageStats(): String? = withContext(Dispatchers.IO) {
        val ctx = appContext ?: return@withContext null
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
            ?: return@withContext null

        val end = System.currentTimeMillis()
        val begin = end - 60_000L // look back 1 minute
        val events = usm.queryEvents(begin, end) ?: return@withContext null

        var lastFg: String? = null
        val event = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            val type = event.eventType
            if (type == UsageEvents.Event.MOVE_TO_FOREGROUND ||
                (android.os.Build.VERSION.SDK_INT >= 29 && type == UsageEvents.Event.ACTIVITY_RESUMED)
            ) {
                lastFg = event.packageName
            }
        }
        lastFg
    }

    /**
     * Returns installed launchable apps (excluding system UI / our own app) for the Games picker.
     */
    suspend fun getInstalledLaunchableApps(context: Context): List<InstalledApp> =
        withContext(Dispatchers.IO) {
            val pm = context.packageManager
            val intent = android.content.Intent(android.content.Intent.ACTION_MAIN).apply {
                addCategory(android.content.Intent.CATEGORY_LAUNCHER)
            }
            val resolveInfos = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            resolveInfos
                .mapNotNull { ri ->
                    val pkg = ri.activityInfo.packageName
                    if (pkg == context.packageName) return@mapNotNull null
                    val label = ri.loadLabel(pm)?.toString() ?: pkg
                    val isSystem = (ri.activityInfo.applicationInfo.flags and
                        ApplicationInfo.FLAG_SYSTEM) != 0
                    InstalledApp(packageName = pkg, label = label, isSystem = isSystem)
                }
                .distinctBy { it.packageName }
                .sortedBy { it.label.lowercase() }
        }
}

data class InstalledApp(
    val packageName: String,
    val label: String,
    val isSystem: Boolean
)
