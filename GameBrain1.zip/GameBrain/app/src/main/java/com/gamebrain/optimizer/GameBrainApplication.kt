package com.gamebrain.optimizer

import android.app.Application
import com.gamebrain.optimizer.detection.AppDetectionManager
import com.gamebrain.optimizer.optimization.OptimizationManager
import com.gamebrain.optimizer.overlay.OverlayController
import com.gamebrain.optimizer.overlay.OverlaySettings
import com.gamebrain.optimizer.shizuku.ShizukuManager

/**
 * Application entry point. Sets up process-wide singletons.
 */
class GameBrainApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        // Start listening for Shizuku's binder as early as possible so the
        // Home screen can immediately reflect the correct connection state.
        ShizukuManager.init()
        // Initialise detection manager (repository + state). Actual event
        // delivery starts when the Accessibility Service connects.
        AppDetectionManager.init(this)
        // Start observing detection state and applying/restoring profiles.
        // This also loads the persisted enable/disable switch and starts (or
        // leaves stopped) the foreground service to match it. It also
        // recovers any optimization session left mid-flight by a process
        // kill, so restore isn't lost just because the app died.
        OptimizationManager.init(this)

        // Overlay: OverlaySettings is just the persisted "I want this on"
        // switch. OverlayController is what actually decides, moment to
        // moment, whether the floating view should be showing — only when
        // that switch is on AND a marked game is currently in the
        // foreground, same signal OptimizationManager uses. This is what
        // makes the overlay appear on game entry and disappear on exit,
        // instead of running continuously once toggled on.
        OverlaySettings.init(this)
        OverlayController.init(this)
    }
}
