package com.gamebrain.optimizer

import android.app.Application
import android.content.Intent
import android.provider.Settings
import android.util.Log
import com.gamebrain.optimizer.detection.AppDetectionManager
import com.gamebrain.optimizer.optimization.OptimizationManager
import com.gamebrain.optimizer.overlay.GameBrainOverlayService
import com.gamebrain.optimizer.overlay.OverlaySettings
import com.gamebrain.optimizer.shizuku.ShizukuManager

/**
 * Application entry point. Sets up process-wide singletons.
 */
class GameBrainApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        // Start listening for Shizuku's binder as early as possible so the
        // Home screen can immediately reflect the correct connection state.
        ShizukuManager.init()
        // Initialise detection manager (repository + state). Actual event
        // delivery starts when the Accessibility Service connects.
        AppDetectionManager.init(this)
        // Start observing detection state and applying/restoring profiles.
        // This also loads the persisted enable/disable switch and starts (or
        // leaves stopped) the foreground service to match it. It also
        // recovers any optimization session left mid-flight by a process
        // kill, so restore isn't lost just because the app died.
        OptimizationManager.init(this)

        // Overlay: only auto-resume if the user had it on AND the overlay
        // permission is still granted (it can be revoked from Settings at
        // any time, and we must not crash trying to draw without it).
        OverlaySettings.init(this)
        if (OverlaySettings.isEnabled.value && Settings.canDrawOverlays(this)) {
            try {
                startService(Intent(this, GameBrainOverlayService::class.java))
            } catch (e: Exception) {
                Log.w("GameBrainApplication", "Could not resume overlay: ${e.message}")
            }
        }
    }
}
