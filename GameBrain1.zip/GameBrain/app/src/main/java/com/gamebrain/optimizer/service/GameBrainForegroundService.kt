package com.gamebrain.optimizer.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.gamebrain.optimizer.MainActivity
import com.gamebrain.optimizer.detection.AppDetectionManager
import com.gamebrain.optimizer.optimization.OptimizationManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/**
 * Foreground service that keeps GameBrain's monitoring alive and shows a
 * persistent, live-updating notification while automatic optimization is
 * armed.
 *
 * This service is started/stopped by [OptimizationManager] to mirror
 * [OptimizationManager.isEnabled] — it is NOT responsible for deciding what
 * to apply; it only reflects state and forwards two user actions:
 *  - "Restore Now": force an immediate restore without disarming automation.
 *  - "Stop": disarm automation (restores if needed) and remove the notification.
 *
 * Ownership boundary: this service (via OptimizationManager) only ever
 * touches refresh rate, animations, battery optimization exemptions, touch
 * latency and light background cleanup. It never touches resolution or FPS
 * caps (that's TMPAD's job), and never triggers strong freezing (Hail's job).
 */
class GameBrainForegroundService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannelIfNeeded()
        // startForeground must be called promptly after the service starts.
        startForeground(NOTIFICATION_ID, buildNotification())

        // Keep the notification live: reflect enabled/disabled, active
        // optimization, applied profile and the current foreground app label.
        scope.launch {
            combine(
                OptimizationManager.isEnabled,
                OptimizationManager.isOptimizing,
                OptimizationManager.lastAppliedProfile,
                OptimizationManager.statusMessage,
                AppDetectionManager.foregroundAppLabel
            ) { _, _, _, _, _ -> Unit }
                .collect { updateNotification() }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                OptimizationManager.setEnabled(false)
                stopSelfSafely()
                return START_NOT_STICKY
            }
            ACTION_RESTORE_NOW -> {
                OptimizationManager.restoreNow()
            }
        }
        updateNotification()
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun stopSelfSafely() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    private fun updateNotification() {
        val manager = getSystemService(NotificationManager::class.java) ?: return
        manager.notify(NOTIFICATION_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val enabled = OptimizationManager.isEnabled.value
        val isOptimizing = OptimizationManager.isOptimizing.value
        val profile = OptimizationManager.lastAppliedProfile.value
        val gameLabel = AppDetectionManager.foregroundAppLabel.value

        val title: String
        val text: String
        when {
            !enabled -> {
                title = "GameBrain — Paused"
                text = "Automatic optimization is off."
            }
            isOptimizing -> {
                title = "GameBrain — Optimizing"
                text = buildString {
                    append(gameLabel ?: "Game")
                    profile?.let { append(" · ${it.displayName}") }
                }
            }
            else -> {
                title = "GameBrain — Watching"
                text = "Waiting for a marked game to start."
            }
        }

        val contentIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            pendingIntentFlags()
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, GameBrainForegroundService::class.java).setAction(ACTION_STOP),
            pendingIntentFlags()
        )
        val restoreIntent = PendingIntent.getService(
            this, 2,
            Intent(this, GameBrainForegroundService::class.java).setAction(ACTION_RESTORE_NOW),
            pendingIntentFlags()
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(contentIntent)
            .addAction(android.R.drawable.ic_menu_revert, "Restore Now", restoreIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopIntent)
            .build()
    }

    private fun pendingIntentFlags(): Int {
        var flags = PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags = flags or PendingIntent.FLAG_IMMUTABLE
        }
        return flags
    }

    private fun createNotificationChannelIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                "GameBrain Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows GameBrain's automatic optimization status"
                setShowBadge(false)
            }
            manager?.createNotificationChannel(channel)
        }
    }

    companion object {
        private const val CHANNEL_ID = "gamebrain_service_channel"
        private const val NOTIFICATION_ID = 1
        const val ACTION_STOP = "com.gamebrain.optimizer.action.STOP"
        const val ACTION_RESTORE_NOW = "com.gamebrain.optimizer.action.RESTORE_NOW"
    }
}
