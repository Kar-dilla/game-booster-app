package com.trendulon.gameturbo.shizuku;

import com.trendulon.gameturbo.shizuku.ShellResult;

interface IShellService {
    // Reserved transaction id used by Shizuku to destroy the user service.
    void destroy() = 16777114;

    // Runs `sh -c <command>` with the privileges of the Shizuku server (shell or root).
    ShellResult exec(String command, long timeoutMillis) = 1;
}
