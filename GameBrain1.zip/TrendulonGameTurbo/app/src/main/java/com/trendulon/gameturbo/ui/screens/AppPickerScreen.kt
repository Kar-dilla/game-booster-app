package com.trendulon.gameturbo.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.trendulon.gameturbo.apps.AppFilter
import com.trendulon.gameturbo.apps.InstalledApp
import com.trendulon.gameturbo.automation.TurboGraph
import com.trendulon.gameturbo.ui.components.AppIcon
import com.trendulon.gameturbo.ui.components.EmptyState
import com.trendulon.gameturbo.ui.theme.TurboColors

/** Searchable list of installed apps. Used to pick a game and to add whitelist entries. */
@Composable
fun AppPickerScreen(
    turbo: TurboGraph,
    title: String,
    onPick: (InstalledApp) -> Unit,
    onBack: () -> Unit,
    alreadyAdded: Set<String> = emptySet(),
    startWithGames: Boolean = true
) {
    BackHandler(onBack = onBack)
    var filter by remember { mutableStateOf(if (startWithGames) AppFilter.GAMES else AppFilter.ALL) }
    var query by remember { mutableStateOf("") }

    val apps by produceState<List<InstalledApp>?>(null, filter) {
        value = null
        value = runCatching { turbo.core.installedApps.list(filter) }.getOrDefault(emptyList())
    }
    val visible = apps?.filter {
        query.isBlank() || it.label.contains(query, ignoreCase = true) || it.packageName.contains(query, ignoreCase = true)
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, "Back") }
            Text(title, style = MaterialTheme.typography.titleLarge)
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
            placeholder = { Text("Search apps") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) }
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(AppFilter.GAMES to "Games", AppFilter.ALL to "All apps").forEach { (f, label) ->
                FilterChip(
                    selected = filter == f, onClick = { filter = f }, label = { Text(label) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = TurboColors.Orange.copy(alpha = 0.18f),
                        selectedLabelColor = TurboColors.Orange
                    )
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        when {
            visible == null -> Text("Loading apps…", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(16.dp))
            visible.isEmpty() -> EmptyState(
                "Nothing found",
                if (filter == AppFilter.GAMES) "Your game may not be tagged as a game. Try \"All apps\"." else "Try a different search."
            )
            else -> LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
                items(visible, key = { it.packageName }) { app ->
                    val added = app.packageName in alreadyAdded
                    Row(
                        Modifier.fillMaxWidth().clickable(enabled = !added) { onPick(app) }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AppIcon(app.packageName, size = 44.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(app.label, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text(
                                app.packageName, style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1
                            )
                        }
                        if (added) Text("ADDED", style = MaterialTheme.typography.labelSmall, color = TurboColors.Green)
                    }
                }
            }
        }
    }
}
