package com.trendulon.gameturbo.ui.screens

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.trendulon.gameturbo.automation.FriendlyErrors
import com.trendulon.gameturbo.automation.Phase
import com.trendulon.gameturbo.automation.Trigger
import com.trendulon.gameturbo.automation.TurboGraph
import com.trendulon.gameturbo.profiles.BoostMode
import com.trendulon.gameturbo.shizuku.ShizukuStatus
import com.trendulon.gameturbo.ui.components.AppIcon
import com.trendulon.gameturbo.ui.components.BannerKind
import com.trendulon.gameturbo.ui.components.Banner
import com.trendulon.gameturbo.ui.components.BrandHeader
import com.trendulon.gameturbo.ui.components.ButtonStyle
import com.trendulon.gameturbo.ui.components.MaximumWarningDialog
import com.trendulon.gameturbo.ui.components.MetricBar
import com.trendulon.gameturbo.ui.components.ModeSelector
import com.trendulon.gameturbo.ui.components.Pill
import com.trendulon.gameturbo.ui.components.PipelineRow
import com.trendulon.gameturbo.ui.components.SectionLabel
import com.trendulon.gameturbo.ui.components.StepState
import com.trendulon.gameturbo.ui.components.TCard
import com.trendulon.gameturbo.ui.components.TurboButton
import com.trendulon.gameturbo.ui.components.color
import com.trendulon.gameturbo.ui.components.label
import com.trendulon.gameturbo.ui.theme.TurboColors
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun HomeScreen(turbo: TurboGraph, onOpenGames: () -> Unit) {
    val context = LocalContext.current
    val coordinator = turbo.coordinator
    val shizuku = turbo.core.shizukuManager
    val profileStore = turbo.core.profileStore

    val ui by coordinator.ui.collectAsState()
    val shizukuStatus by shizuku.status.collectAsState()
    val profiles by profileStore.profiles.collectAsState()
    val selectedSet by profileStore.selectedPackages.collectAsState()
    val settings by turbo.settings.state.collectAsState()

    val selected = profiles.firstOrNull { it.packageName in selectedSet } ?: profiles.firstOrNull()
    val shown = ui.session?.profile ?: selected
    val connected = shizukuStatus == ShizukuStatus.Connected

    var showMaxForBoost by remember { mutableStateOf(false) }
    var showMaxForSelect by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }

    val startedAt = ui.session?.startedAt
    val elapsedSeconds by produceState(0L, ui.active, startedAt) {
        while (true) {
            value = if (ui.active && startedAt != null) (System.currentTimeMillis() - startedAt) / 1000 else 0L
            delay(1000)
        }
    }

    fun startBoost() {
        val p = selected ?: return
        if (coordinator.requiresMaxConfirmation(p, Trigger.MANUAL)) showMaxForBoost = true
        else coordinator.boost(p, Trigger.MANUAL)
    }

    if (showMaxForBoost && selected != null) {
        MaximumWarningDialog(
            confirmLabel = "Start Maximum",
            onConfirm = { showMaxForBoost = false; coordinator.boost(selected, Trigger.MANUAL, maxConfirmed = true) },
            onDismiss = { showMaxForBoost = false }
        )
    }
    if (showMaxForSelect && selected != null) {
        MaximumWarningDialog(
            confirmLabel = "Use Maximum",
            onConfirm = { showMaxForSelect = false; profileStore.save(selected.copy(mode = BoostMode.MAXIMUM)) },
            onDismiss = { showMaxForSelect = false }
        )
    }

    LazyColumn(
        Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            BrandHeader(trailing = {
                val (text, color) = when (shizukuStatus) {
                    ShizukuStatus.Connected -> "Shizuku" to TurboColors.Green
                    ShizukuStatus.NotAuthorized -> "Allow" to TurboColors.Yellow
                    ShizukuStatus.Disconnected -> "Offline" to TurboColors.Red
                }
                Pill(text, color)
            })
        }

        item {
            Column {
                Text(
                    LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE d MMMM", Locale.getDefault())).uppercase(),
                    color = TurboColors.Orange, style = MaterialTheme.typography.labelMedium, letterSpacing = 2.sp
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    when {
                        ui.active -> "Boost is on."
                        ui.working || ui.starting -> "Working on it."
                        else -> "Ready to play."
                    },
                    style = MaterialTheme.typography.headlineLarge
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Close the noise. Keep the frames. Restore with one tap.",
                    style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // ---- banners ----
        if (!connected) {
            item {
                Banner(
                    kind = if (shizukuStatus == ShizukuStatus.NotAuthorized) BannerKind.Warning else BannerKind.Error,
                    title = if (shizukuStatus == ShizukuStatus.NotAuthorized) "Shizuku needs your OK" else "Shizuku is offline",
                    text = FriendlyErrors.shizukuNotReady(shizukuStatus, shizuku.isShizukuAppInstalled()),
                    actionLabel = if (shizukuStatus == ShizukuStatus.NotAuthorized) "Allow now" else "Connect",
                    onAction = { shizuku.connect() }
                )
            }
        }
        if (ui.pendingRestore && !ui.active && !ui.working) {
            item {
                Banner(
                    kind = BannerKind.Warning,
                    title = "Some settings are still changed",
                    text = "A boost wasn't fully restored. Tap to put everything back.",
                    actionLabel = "Restore now",
                    onAction = { coordinator.restoreEverything() }
                )
            }
        }
        if (ui.active && ui.overheating) {
            item {
                Banner(
                    kind = BannerKind.Error,
                    title = "Your phone is hot",
                    text = (ui.temperatureC?.let { String.format("%.1f°C. ", it) } ?: "") +
                        "Take a break, or restore to let it cool down.",
                    actionLabel = "Restore now",
                    onAction = { coordinator.restore(Trigger.MANUAL) }
                )
            }
        }

        // ---- status panel ----
        item {
            TCard(borderColor = if (ui.active) TurboColors.Green.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    when {
                        ui.active -> Pill("Boost active", TurboColors.Green)
                        ui.working || ui.starting -> Pill(
                            if (ui.phase is Phase.Restoring) "Restoring" else "Applying", TurboColors.Orange
                        )
                        else -> Pill("Idle", MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(Modifier.weight(1f))
                    if (shown != null) Pill(shown.mode.label(), shown.mode.color(), dot = false)
                }
                Spacer(Modifier.height(14.dp))
                Text(
                    when {
                        ui.active -> "Boost active for ${shown?.name ?: "your game"}"
                        ui.phase is Phase.Restoring -> "Restoring your settings"
                        ui.working || ui.starting -> "Applying boost"
                        else -> "No boost running"
                    },
                    style = MaterialTheme.typography.titleLarge
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    when (val phase = ui.phase) {
                        is Phase.Applying -> FriendlyErrors.stepName(phase.step)
                        is Phase.Restoring -> FriendlyErrors.stepName(phase.step)
                        Phase.Active -> "Running ${formatElapsed(elapsedSeconds)}" +
                            if (ui.session?.gameSeen == true) " - game detected" else " - waiting for the game to open"
                        Phase.Idle ->
                            if (ui.starting) "Starting..."
                            else if (shown != null) "Ready for ${shown.name}"
                            else "Add a game to get started."
                    },
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                AnimatedVisibility(ui.working || ui.starting) {
                    Column {
                        Spacer(Modifier.height(14.dp))
                        LinearProgressIndicator(
                            Modifier.fillMaxWidth(), color = TurboColors.Orange,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                        if (shown?.mode == BoostMode.MAXIMUM && ui.phase is Phase.Applying) {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "Maximum can take a few minutes while apps are optimised.",
                                style = MaterialTheme.typography.bodySmall, color = TurboColors.Yellow
                            )
                        }
                    }
                }

                AnimatedVisibility(
                    ui.active,
                    enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()
                ) {
                    val killed by animateIntAsState(ui.killedCount, tween(600), label = "killed")
                    val applied = ui.session?.report?.applied ?: 0
                    Column {
                        Spacer(Modifier.height(18.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                            MetricBar("Apps closed", "$killed", (killed / 20f), Modifier.weight(1f))
                            MetricBar("Tweaks applied", "$applied", (applied / 10f), Modifier.weight(1f), TurboColors.Green)
                        }
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                            MetricBar("Kill passes", "${ui.passes}", (ui.passes / 20f), Modifier.weight(1f))
                            val t = ui.temperatureC
                            MetricBar(
                                "Temperature", t?.let { String.format("%.0f°C", it) } ?: "-",
                                ((t ?: 25f) - 25f) / 25f, Modifier.weight(1f),
                                if (ui.overheating) TurboColors.Red else TurboColors.Yellow
                            )
                        }
                    }
                }
            }
        }

        // ---- game + mode ----
        item {
            TCard {
                SectionLabel("Game")
                Spacer(Modifier.height(10.dp))
                if (selected == null) {
                    Text("You haven't added a game yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(12.dp))
                    TurboButton("Add your first game", onOpenGames, Modifier.fillMaxWidth())
                } else {
                    Box {
                        Row(
                            Modifier.fillMaxWidth().clickable(enabled = !ui.busy && !ui.active) { menuOpen = true },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AppIcon(selected.packageName, size = 48.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(selected.name, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                                Text(
                                    selected.packageName, style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1
                                )
                            }
                            if (profiles.size > 1 && !ui.active) Icon(Icons.Rounded.KeyboardArrowDown, null)
                        }
                        DropdownMenu(menuOpen, { menuOpen = false }) {
                            profiles.forEach { p ->
                                DropdownMenuItem(
                                    text = { Text(p.name) },
                                    onClick = { profileStore.setSelected(setOf(p.packageName)); menuOpen = false },
                                    leadingIcon = { AppIcon(p.packageName, size = 28.dp) }
                                )
                            }
                            DropdownMenuItem(
                                text = { Text("Manage games…", color = TurboColors.Orange) },
                                onClick = { menuOpen = false; onOpenGames() }
                            )
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    SectionLabel("Mode")
                    Spacer(Modifier.height(10.dp))
                    ModeSelector(
                        selected = selected.mode,
                        enabled = !ui.busy && !ui.active,
                        onSelect = { mode ->
                            if (mode == BoostMode.MAXIMUM && selected.mode != BoostMode.MAXIMUM) showMaxForSelect = true
                            else profileStore.save(selected.copy(mode = mode))
                        }
                    )
                    if (ui.active) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Restore first to change the mode.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // ---- main actions ----
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                val pulse = rememberInfiniteTransition(label = "boostPulse")
                val glow by pulse.animateFloat(
                    0.75f, 1f, infiniteRepeatable(tween(1100), RepeatMode.Reverse), label = "glow"
                )
                when {
                    ui.working || ui.starting -> TurboButton(
                        if (ui.phase is Phase.Restoring) "Restoring…" else "Applying…",
                        {}, Modifier.fillMaxWidth(), enabled = false
                    )
                    ui.active -> {
                        TurboButton(
                            "Restore", { coordinator.restore(Trigger.MANUAL) },
                            Modifier.fillMaxWidth().alpha(glow), icon = Icons.Rounded.RestartAlt,
                            style = ButtonStyle.Success
                        )
                        shown?.let { game ->
                            TurboButton(
                                "Launch ${game.name}", {
                                    context.packageManager.getLaunchIntentForPackage(game.packageName)
                                        ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        ?.let(context::startActivity)
                                },
                                Modifier.fillMaxWidth(), icon = Icons.Rounded.PlayArrow, style = ButtonStyle.Ghost
                            )
                        }
                    }
                    !connected -> TurboButton(
                        if (shizukuStatus == ShizukuStatus.NotAuthorized) "Allow Shizuku" else "Connect to Shizuku",
                        { shizuku.connect() }, Modifier.fillMaxWidth(), icon = Icons.Rounded.Bolt
                    )
                    else -> TurboButton(
                        "Boost now", { startBoost() }, Modifier.fillMaxWidth(),
                        icon = Icons.Rounded.Bolt, enabled = selected != null
                    )
                }

                Row(
                    Modifier.fillMaxWidth().padding(top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Keep boost until I turn it off", fontWeight = FontWeight.SemiBold)
                        Text(
                            "Don't auto-restore when the game closes.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = settings.keepBoostUntilManual,
                        onCheckedChange = { v -> turbo.settings.update { it.copy(keepBoostUntilManual = v) } },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF0A0A0A), checkedTrackColor = TurboColors.Orange,
                            uncheckedTrackColor = MaterialTheme.colorScheme.surfaceVariant,
                            uncheckedBorderColor = MaterialTheme.colorScheme.outline
                        )
                    )
                }
            }
        }

        // ---- pipeline ----
        item { SectionLabel("The Turbo pipeline", Modifier.padding(top = 8.dp)) }
        item {
            PipelineRow(
                "01", "Detect",
                if (settings.autoDetect) "Watching for ${selected?.name ?: "your game"}" else "Auto-detect is off. Boost manually.",
                if (settings.autoDetect) StepState.DONE else StepState.WAITING
            )
        }
        item {
            PipelineRow(
                "02", "Boost",
                when (val phase = ui.phase) {
                    is Phase.Applying -> FriendlyErrors.stepName(phase.step)
                    Phase.Active -> "${ui.session?.report?.applied ?: 0} tweaks - ${ui.killedCount} apps closed"
                    else -> "Closes background apps and tunes the system."
                },
                when {
                    ui.phase is Phase.Applying -> StepState.ACTIVE
                    ui.active -> StepState.DONE
                    else -> StepState.WAITING
                }
            )
        }
        item {
            PipelineRow(
                "03", "Play",
                if (ui.active && ui.session?.gameSeen == true) "Game running. Boost is holding."
                else if (ui.active) "Waiting for the game to open."
                else "Open your game and play.",
                if (ui.active && ui.session?.gameSeen == true) StepState.ACTIVE else StepState.WAITING
            )
        }
        item {
            PipelineRow(
                "04", "Restore",
                if (settings.keepBoostUntilManual) "Manual. You decide when."
                else if (settings.autoRestore) "Automatic when the game closes."
                else "Manual. Tap Restore.",
                if (ui.phase is Phase.Restoring) StepState.ACTIVE else StepState.WAITING
            )
        }

        // ---- emergency ----
        item {
            TCard(Modifier.padding(top = 8.dp), borderColor = TurboColors.Red.copy(alpha = 0.35f)) {
                Text("Something feels off?", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Stops everything and puts every setting back to how it was before your first boost.",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(12.dp))
                TurboButton(
                    "Restore Everything", { coordinator.restoreEverything() }, Modifier.fillMaxWidth(),
                    icon = Icons.Rounded.RestartAlt, style = ButtonStyle.Danger
                )
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

private fun formatElapsed(seconds: Long): String =
    String.format("%d:%02d", seconds / 60, seconds % 60)
