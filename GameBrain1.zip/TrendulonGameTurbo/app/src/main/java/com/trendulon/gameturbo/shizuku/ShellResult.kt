package com.trendulon.gameturbo.shizuku

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/** Result of one shell command executed through Shizuku. */
@Parcelize
data class ShellResult(
    val exitCode: Int,
    val stdout: String,
    val stderr: String
) : Parcelable {
    val isSuccess: Boolean get() = exitCode == 0
}
