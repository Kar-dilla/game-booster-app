package com.trendulon.gameturbo.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import com.trendulon.gameturbo.automation.Turbo
import com.trendulon.gameturbo.automation.TurboGraph
import com.trendulon.gameturbo.services.AutomationService
import com.trendulon.gameturbo.ui.screens.HomeScreen
import com.trendulon.gameturbo.ui.screens.LogScreen
import com.trendulon.gameturbo.ui.screens.OnboardingScreen
import com.trendulon.gameturbo.ui.screens.ProfilesScreen
import com.trendulon.gameturbo.ui.screens.SettingsScreen
import com.trendulon.gameturbo.ui.theme.TrendulonTheme
import com.trendulon.gameturbo.ui.theme.TurboColors
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val turbo = Turbo.of(this)
        setContent {
            val settings by turbo.settings.state.collectAsState()
            TrendulonTheme(settings.themeMode) {
                Root(turbo)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        // Make sure the background service matches the saved settings (e.g. after an update).
        runCatching { AutomationService.sync(this) }
    }
}

private enum class Tab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Rounded.Bolt),
    GAMES("Games", Icons.Rounded.SportsEsports),
    LOG("Log", Icons.Rounded.History),
    SETTINGS("Settings", Icons.Rounded.Settings)
}

@Composable
private fun Root(turbo: TurboGraph) {
    val settings by turbo.settings.state.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val toast: (String) -> Unit = { message -> scope.launch { snackbar.showSnackbar(message) } }
    var showGuide by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(Unit) { turbo.coordinator.events.collect { snackbar.showSnackbar(it) } }

    Box(Modifier.background(MaterialTheme.colorScheme.background)) {
        if (!settings.onboardingDone || showGuide) {
            OnboardingScreen(
                turbo,
                onFinish = {
                    showGuide = false
                    turbo.settings.update { it.copy(onboardingDone = true) }
                },
                onMessage = toast
            )
        } else {
            MainScaffold(turbo, snackbar, toast, onShowGuide = { showGuide = true })
        }
    }
}

@Composable
private fun MainScaffold(
    turbo: TurboGraph,
    snackbar: SnackbarHostState,
    toast: (String) -> Unit,
    onShowGuide: () -> Unit
) {
    var tab by rememberSaveable { mutableStateOf(Tab.HOME) }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                Tab.values().forEach { t ->
                    NavigationBarItem(
                        selected = tab == t,
                        onClick = { tab = t },
                        icon = { Icon(t.icon, t.label) },
                        label = { Text(t.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = TurboColors.Orange,
                            selectedTextColor = TurboColors.Orange,
                            indicatorColor = TurboColors.Orange.copy(alpha = 0.16f),
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            }
        }
    ) { padding ->
        Crossfade(tab, Modifier.padding(padding), label = "tabs") { current ->
            when (current) {
                Tab.HOME -> HomeScreen(turbo, onOpenGames = { tab = Tab.GAMES })
                Tab.GAMES -> ProfilesScreen(turbo, toast)
                Tab.LOG -> LogScreen(turbo)
                Tab.SETTINGS -> SettingsScreen(turbo, toast, onShowGuide)
            }
        }
    }
}
