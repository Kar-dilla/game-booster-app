package com.trendulon.gameturbo.shizuku

/** Live connection state, as required by the spec. */
enum class ShizukuStatus {
    /** Shizuku is not running / not installed / binder is dead. */
    Disconnected,

    /** Shizuku is running but this app has not been granted permission. */
    NotAuthorized,

    /** Shizuku is running and permission is granted - privileged commands can run. */
    Connected
}

/** How the running Shizuku server was started. */
enum class ShizukuMode {
    UNKNOWN,

    /** Started through wireless/USB debugging (uid 2000). Preferred for non-root users. */
    ADB,

    /** Started with root (uid 0). */
    ROOT
}

/** Thrown by [ShizukuManager.exec] when Shizuku is not ready. */
class ShizukuNotReadyException(message: String) : IllegalStateException(message)
