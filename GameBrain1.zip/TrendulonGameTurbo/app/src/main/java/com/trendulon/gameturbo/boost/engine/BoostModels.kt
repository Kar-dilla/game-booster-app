package com.trendulon.gameturbo.boost.engine

import com.trendulon.gameturbo.profiles.BoostMode

/** Outcome of a single boost or restore step. */
enum class StepStatus {
    /** Command ran and succeeded. */
    OK,
    /** Not run on purpose (not in this mode, unsupported Android version, value unreadable, ...). */
    SKIPPED,
    /** Command ran and failed (non-zero exit, error output, or verification mismatch). */
    FAILED
}

data class StepResult(
    /** Stable id, e.g. "animations", "game_mode". Same ids are used in the snapshot. */
    val id: String,
    val status: StepStatus,
    val detail: String = ""
)

data class BoostReport(
    val packageName: String,
    val mode: BoostMode,
    val steps: List<StepResult>,
    val durationMs: Long,
    /** Set when nothing was applied at all (e.g. Shizuku not connected). */
    val error: String? = null
) {
    val applied: Int get() = steps.count { it.status == StepStatus.OK }
    val failed: Int get() = steps.count { it.status == StepStatus.FAILED }
    val success: Boolean get() = error == null && failed == 0
}

data class RestoreReport(
    val steps: List<StepResult>,
    /** Steps that could not be put back. They stay saved, so calling restore() again retries them. */
    val stillPending: Int,
    /** Things a restore can never undo (cache wipe, killed processes). Informational. */
    val notRestorable: List<String>,
    val error: String? = null
) {
    val failed: Int get() = steps.count { it.status == StepStatus.FAILED }
    val success: Boolean get() = error == null && failed == 0 && stillPending == 0
}

/** Observable state for the (future) UI. Not wired to any UI here. */
sealed interface BoostEngineState {
    object Idle : BoostEngineState
    data class Applying(val packageName: String, val mode: BoostMode, val step: String) : BoostEngineState
    data class Active(val packageName: String, val mode: BoostMode, val report: BoostReport) : BoostEngineState
    data class Restoring(val step: String) : BoostEngineState
}
