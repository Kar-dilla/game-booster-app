package com.trendulon.gameturbo.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.trendulon.gameturbo.automation.TurboGraph
import com.trendulon.gameturbo.profiles.BoostMode
import com.trendulon.gameturbo.profiles.TargetProfile
import com.trendulon.gameturbo.ui.components.AppIcon
import com.trendulon.gameturbo.ui.components.ButtonStyle
import com.trendulon.gameturbo.ui.components.ConfirmDialog
import com.trendulon.gameturbo.ui.components.EmptyState
import com.trendulon.gameturbo.ui.components.MaximumWarningDialog
import com.trendulon.gameturbo.ui.components.ModeSelector
import com.trendulon.gameturbo.ui.components.Pill
import com.trendulon.gameturbo.ui.components.ScreenTitle
import com.trendulon.gameturbo.ui.components.SectionLabel
import com.trendulon.gameturbo.ui.components.TCard
import com.trendulon.gameturbo.ui.components.TurboButton
import com.trendulon.gameturbo.ui.components.color
import com.trendulon.gameturbo.ui.components.label
import com.trendulon.gameturbo.ui.theme.TurboColors

private sealed interface ProfilesPage {
    object List : ProfilesPage
    object Picker : ProfilesPage
    data class Editor(val editing: TargetProfile?, val draftPackage: String?, val draftName: String, val draftMode: BoostMode) : ProfilesPage
}

@Composable
fun ProfilesScreen(turbo: TurboGraph, onMessage: (String) -> Unit) {
    var page by remember { mutableStateOf<ProfilesPage>(ProfilesPage.List) }
    when (val p = page) {
        ProfilesPage.List -> ProfileList(
            turbo, onMessage,
            onAdd = { page = ProfilesPage.Picker },
            onEdit = { profile -> page = ProfilesPage.Editor(profile, profile.packageName, profile.name, profile.mode) }
        )
        ProfilesPage.Picker -> AppPickerScreen(
            turbo, "Choose a game",
            alreadyAdded = turbo.core.profileStore.profiles.collectAsState().value.map { it.packageName }.toSet(),
            onBack = { page = ProfilesPage.List },
            onPick = { app ->
                page = ProfilesPage.Editor(null, app.packageName, app.label, BoostMode.PERFORMANCE)
            }
        )
        is ProfilesPage.Editor -> ProfileEditor(
            turbo, p, onMessage,
            onChangeApp = { page = ProfilesPage.Picker },
            onDone = { page = ProfilesPage.List }
        )
    }
}

@Composable
private fun ProfileList(
    turbo: TurboGraph,
    onMessage: (String) -> Unit,
    onAdd: () -> Unit,
    onEdit: (TargetProfile) -> Unit
) {
    val store = turbo.core.profileStore
    val profiles by store.profiles.collectAsState()
    val selectedSet by store.selectedPackages.collectAsState()
    val ui by turbo.coordinator.ui.collectAsState()
    var deleting by remember { mutableStateOf<TargetProfile?>(null) }

    val selected = profiles.firstOrNull { it.packageName in selectedSet } ?: profiles.firstOrNull()

    deleting?.let { profile ->
        ConfirmDialog(
            title = "Delete ${profile.name}?",
            text = "This only removes the profile from Game Turbo. The game itself isn't touched.",
            confirmLabel = "Delete", destructive = true,
            onConfirm = { store.delete(profile.packageName); deleting = null; onMessage("${profile.name} removed") },
            onDismiss = { deleting = null }
        )
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenTitle("Games", "Each game has its own boost mode. Tap one to switch to it.") }
        item { TurboButton("Add a game", onAdd, Modifier.fillMaxWidth(), icon = Icons.Rounded.Add) }

        if (profiles.isEmpty()) {
            item { EmptyState("No games yet", "Add Call of Duty Mobile or any game you want to boost.") }
        }

        items(profiles, key = { it.packageName }) { profile ->
            val isSelected = profile.packageName == selected?.packageName
            val inUse = ui.session?.profile?.packageName == profile.packageName
            TCard(
                onClick = { store.setSelected(setOf(profile.packageName)) },
                borderColor = if (isSelected) TurboColors.Orange.copy(alpha = 0.7f) else MaterialTheme.colorScheme.outline
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(profile.packageName, size = 48.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(profile.name, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                        Text(
                            profile.packageName, fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Pill(profile.mode.label(), profile.mode.color(), dot = false)
                    if (isSelected) {
                        Spacer(Modifier.width(8.dp))
                        Pill("Selected", TurboColors.Orange)
                    }
                    if (inUse) {
                        Spacer(Modifier.width(8.dp))
                        Pill("Boosting", TurboColors.Green)
                    }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { onEdit(profile) }) { Icon(Icons.Rounded.Edit, "Edit") }
                    IconButton(onClick = {
                        if (inUse) onMessage("Restore first, then delete ${profile.name}.") else deleting = profile
                    }) { Icon(Icons.Rounded.DeleteOutline, "Delete", tint = TurboColors.Red) }
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
private fun ProfileEditor(
    turbo: TurboGraph,
    page: ProfilesPage.Editor,
    onMessage: (String) -> Unit,
    onChangeApp: () -> Unit,
    onDone: () -> Unit
) {
    BackHandler(onBack = onDone)
    val store = turbo.core.profileStore
    var name by rememberSaveable(page.draftPackage) { mutableStateOf(page.draftName) }
    var mode by rememberSaveable(page.draftPackage) { mutableStateOf(page.draftMode) }
    var showMax by remember { mutableStateOf(false) }
    val packageName = page.draftPackage
    val isEdit = page.editing != null

    if (showMax) {
        MaximumWarningDialog(
            confirmLabel = "Use Maximum",
            onConfirm = { mode = BoostMode.MAXIMUM; showMax = false },
            onDismiss = { showMax = false }
        )
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onDone) { Icon(Icons.Rounded.ArrowBack, "Back") }
            Text(if (isEdit) "Edit game" else "New game", style = MaterialTheme.typography.titleLarge)
        }
        Spacer(Modifier.height(12.dp))

        TCard {
            SectionLabel("App")
            Spacer(Modifier.height(10.dp))
            if (packageName != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(packageName, size = 48.dp)
                    Spacer(Modifier.width(12.dp))
                    Text(
                        packageName, fontFamily = FontFamily.Monospace,
                        style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f)
                    )
                }
            }
            if (!isEdit) {
                Spacer(Modifier.height(10.dp))
                TurboButton("Change app", onChangeApp, Modifier.fillMaxWidth(), style = ButtonStyle.Ghost)
            }
        }
        Spacer(Modifier.height(12.dp))
        TCard {
            SectionLabel("Name")
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = name, onValueChange = { name = it.take(40) }, singleLine = true,
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
                placeholder = { Text("e.g. CODM") }
            )
        }
        Spacer(Modifier.height(12.dp))
        TCard {
            SectionLabel("Mode")
            Spacer(Modifier.height(10.dp))
            ModeSelector(mode, onSelect = { m ->
                if (m == BoostMode.MAXIMUM && mode != BoostMode.MAXIMUM) showMax = true else mode = m
            })
        }
        Spacer(Modifier.height(20.dp))
        TurboButton(
            if (isEdit) "Save changes" else "Add game",
            onClick = {
                val pkg = packageName
                when {
                    pkg == null -> onMessage("Pick an app first.")
                    name.isBlank() -> onMessage("Give the game a name.")
                    else -> {
                        val ok = store.save(TargetProfile(name.trim(), pkg, mode))
                        if (ok) {
                            if (!isEdit && store.selectedPackages.value.isEmpty()) store.setSelected(setOf(pkg))
                            onMessage(if (isEdit) "Saved" else "${name.trim()} added")
                            onDone()
                        } else onMessage("That app can't be used (invalid package name).")
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(24.dp))
    }
}
