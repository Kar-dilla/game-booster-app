package com.trendulon.gameturbo.profiles

/** Boost modes from the spec. Stored with the profile; Dev 2 decides what each mode applies. */
enum class BoostMode { BALANCED, PERFORMANCE, MAXIMUM }

/** A saved target game: display name + package name + preferred mode. */
data class TargetProfile(
    val name: String,
    val packageName: String,
    val mode: BoostMode = BoostMode.BALANCED
)
