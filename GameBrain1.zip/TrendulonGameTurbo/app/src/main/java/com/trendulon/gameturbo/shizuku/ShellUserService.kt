package com.trendulon.gameturbo.shizuku

import android.content.Context
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlin.system.exitProcess

/**
 * Runs INSIDE the Shizuku server's process (shell uid for ADB mode, root uid for root mode).
 * Instantiated by Shizuku via reflection, so keep the constructors as they are.
 * Never use this class directly - go through [ShizukuManager.exec].
 */
class ShellUserService() : IShellService.Stub() {

    @Suppress("UNUSED_PARAMETER")
    constructor(context: Context) : this()

    override fun destroy() {
        exitProcess(0)
    }

    override fun exec(command: String, timeoutMillis: Long): ShellResult {
        return try {
            val process = ProcessBuilder("sh", "-c", command).start()
            runCatching { process.outputStream.close() }

            val out = StringBuilder()
            val err = StringBuilder()
            // Drain both streams concurrently, otherwise a full pipe can deadlock the process.
            val outReader = thread(isDaemon = true) {
                runCatching { process.inputStream.bufferedReader().forEachLine { out.appendLine(it) } }
            }
            val errReader = thread(isDaemon = true) {
                runCatching { process.errorStream.bufferedReader().forEachLine { err.appendLine(it) } }
            }

            val finished = process.waitFor(timeoutMillis, TimeUnit.MILLISECONDS)
            if (!finished) {
                process.destroyForcibly()
                outReader.join(500)
                errReader.join(500)
                return ShellResult(EXIT_TIMEOUT, out.toString(), "timeout after ${timeoutMillis}ms\n$err")
            }
            outReader.join(2_000)
            errReader.join(2_000)
            ShellResult(process.exitValue(), out.toString(), err.toString())
        } catch (t: Throwable) {
            ShellResult(EXIT_ERROR, "", t.toString())
        }
    }

    private companion object {
        const val EXIT_TIMEOUT = -2
        const val EXIT_ERROR = -1
    }
}
