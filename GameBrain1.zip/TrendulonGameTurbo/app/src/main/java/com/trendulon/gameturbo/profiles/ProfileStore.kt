package com.trendulon.gameturbo.profiles

import android.content.Context
import com.trendulon.gameturbo.killer.PackageNames
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/**
 * Basic persistence for:
 *  - saved [TargetProfile]s (one per package name)
 *  - the current target selection (one or several packages)
 * Backed by SharedPreferences (JSON). Observable through [profiles] and [selectedPackages].
 */
class ProfileStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("trendulon_profiles", Context.MODE_PRIVATE)

    private val _profiles = MutableStateFlow(loadProfiles())
    val profiles: StateFlow<List<TargetProfile>> = _profiles.asStateFlow()

    private val _selected = MutableStateFlow(
        prefs.getStringSet(KEY_SELECTED, emptySet()).orEmpty().filter(PackageNames::isValid).toSet()
    )
    val selectedPackages: StateFlow<Set<String>> = _selected.asStateFlow()

    /** Adds a profile or replaces the existing one with the same package name. */
    @Synchronized
    fun save(profile: TargetProfile): Boolean {
        if (!PackageNames.isValid(profile.packageName)) return false
        val list = _profiles.value.filterNot { it.packageName == profile.packageName } + profile
        persistProfiles(list)
        return true
    }

    @Synchronized
    fun delete(packageName: String) {
        persistProfiles(_profiles.value.filterNot { it.packageName == packageName })
        setSelected(_selected.value - packageName)
    }

    fun get(packageName: String): TargetProfile? = _profiles.value.firstOrNull { it.packageName == packageName }

    // ---- selection ----

    @Synchronized
    fun setSelected(packages: Set<String>) {
        val clean = packages.filter(PackageNames::isValid).toSet()
        _selected.value = clean
        prefs.edit().putStringSet(KEY_SELECTED, clean).apply()
    }

    @Synchronized
    fun toggleSelected(packageName: String) {
        val current = _selected.value
        setSelected(if (packageName in current) current - packageName else current + packageName)
    }

    // ---- persistence ----

    private fun persistProfiles(list: List<TargetProfile>) {
        _profiles.value = list
        val array = JSONArray()
        list.forEach {
            array.put(
                JSONObject()
                    .put("name", it.name)
                    .put("package", it.packageName)
                    .put("mode", it.mode.name)
            )
        }
        prefs.edit().putString(KEY_PROFILES, array.toString()).apply()
    }

    private fun loadProfiles(): List<TargetProfile> {
        val json = prefs.getString(KEY_PROFILES, null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(json)
            (0 until array.length()).mapNotNull { i ->
                val o = array.getJSONObject(i)
                val pkg = o.optString("package")
                if (!PackageNames.isValid(pkg)) return@mapNotNull null
                TargetProfile(
                    name = o.optString("name", pkg),
                    packageName = pkg,
                    mode = runCatching { BoostMode.valueOf(o.optString("mode")) }
                        .getOrDefault(BoostMode.BALANCED)
                )
            }
        }.getOrDefault(emptyList())
    }

    private companion object {
        const val KEY_PROFILES = "profiles_json"
        const val KEY_SELECTED = "selected_packages"
    }
}
