package com.trendulon.gameturbo.boost

import com.trendulon.gameturbo.killer.KillReport
import com.trendulon.gameturbo.killer.KillerConfigStore
import com.trendulon.gameturbo.killer.ProcessKiller
import com.trendulon.gameturbo.profiles.TargetProfile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Observable state for a status panel ("Boost Active for X - N apps killed"). */
data class BoostState(
    val active: Boolean = false,
    val targets: Set<String> = emptySet(),
    /** Number of kill passes executed since the boost started. */
    val passes: Int = 0,
    /** Distinct packages killed since the boost started. */
    val killedPackages: Set<String> = emptySet(),
    val lastReport: KillReport? = null,
    val lastError: String? = null
) {
    val killedCount: Int get() = killedPackages.size
}

/**
 * Boost Now / Stop Boost - KILLING ONLY.
 *  - [boostNow]  : one kill pass; if continuous mode is enabled in [KillerConfigStore], keeps
 *                  re-killing every 10-30 s until [stopBoost]. The toggle / interval are re-read
 *                  on every iteration, so changes apply live.
 *  - [stopBoost] : stops the loop. It does NOT restore anything (no settings are changed by this
 *                  module, so there is nothing to restore here).
 *
 * The loop lives in the app process. If it must survive the app being backgrounded, Dev 2 / the UI
 * developer should call [boostNow] from a foreground service.
 */
class BoostController(
    private val killer: ProcessKiller,
    private val configStore: KillerConfigStore,
    private val scope: CoroutineScope
) {
    private val _state = MutableStateFlow(BoostState())
    val state: StateFlow<BoostState> = _state.asStateFlow()

    private var job: Job? = null

    fun boostNow(profile: TargetProfile) = boostNow(setOf(profile.packageName))

    /** @param targets packages that must be kept alive (the game(s) being boosted). */
    @Synchronized
    fun boostNow(targets: Set<String>) {
        job?.cancel()
        _state.value = BoostState(active = true, targets = targets)
        job = scope.launch {
            while (isActive) {
                val config = configStore.config.value
                val report = killer.killNow(targets, config.onlyKillRunning)
                _state.update {
                    it.copy(
                        passes = it.passes + 1,
                        killedPackages = it.killedPackages + report.killed,
                        lastReport = report,
                        lastError = report.error
                    )
                }
                val continuous = configStore.config.value.continuousEnabled
                if (!continuous) {
                    // One-shot boost: finished. A failed one-shot stays visible through lastError.
                    _state.update { it.copy(active = false) }
                    break
                }
                // Continuous: keep going even after errors (e.g. Shizuku died) - it auto-reconnects.
                delay(configStore.config.value.safeIntervalSeconds * 1000L)
            }
        }
    }

    @Synchronized
    fun stopBoost() {
        job?.cancel()
        job = null
        _state.update { it.copy(active = false) }
    }

    val isBoostActive: Boolean get() = _state.value.active
}
