package com.trendulon.gameturbo.killer

/**
 * HARD exclusion list: these packages are never killed, no matter what the user whitelists
 * or which kill mode is used. Dynamic protections (launcher, keyboard, dialer, ...) live in
 * [ProtectedPackagesResolver].
 */
object ExclusionList {

    private val exactPackages = setOf(
        "android",
        "com.android.systemui",
        "com.android.phone",
        "com.android.settings",
        "com.android.shell",
        "com.android.server.telecom",
        "com.android.bluetooth",
        "com.android.nfc",
        "com.android.stk",
        "com.android.mms.service",
        "com.android.carrierconfig",
        "com.android.permissioncontroller",
        "com.google.android.permissioncontroller",
        "com.android.packageinstaller",
        "com.google.android.packageinstaller",
        "com.android.inputmethod.latin",
        "com.google.android.inputmethod.latin",
        "com.android.webview",
        "com.google.android.webview",
        "com.google.android.gms",
        "com.google.android.gsf",
        // Shizuku itself - killing it drops the connection this app depends on.
        "moe.shizuku.privileged.api"
    )

    /** A trailing '.' means "this package prefix", e.g. com.android.providers.* */
    private val prefixes = listOf(
        "com.android.providers.",
        "com.android.systemui.",
        "com.android.settings.",
        "com.android.phone.",
        "com.android.networkstack",
        "com.android.cellbroadcast",
        "com.android.internal.",
        "com.google.android.gms.",
        "com.google.android.ext."
    )

    fun isHardExcluded(packageName: String): Boolean =
        packageName in exactPackages || prefixes.any { packageName.startsWith(it) }
}
