package com.trendulon.gameturbo.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.trendulon.gameturbo.automation.Trigger
import com.trendulon.gameturbo.automation.Turbo
import com.trendulon.gameturbo.ui.components.MaximumWarningDialog
import com.trendulon.gameturbo.ui.theme.TrendulonTheme

/**
 * Transparent activity that shows the Maximum-mode warning on top of whatever is open (a game, the shade).
 * Used by the Quick Settings tile and the floating button so they can never start Maximum silently.
 */
class ConfirmBoostActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val turbo = Turbo.of(this)
        val packageName = intent.getStringExtra(EXTRA_PACKAGE)
        val trigger = runCatching { Trigger.valueOf(intent.getStringExtra(EXTRA_TRIGGER) ?: "") }
            .getOrDefault(Trigger.MANUAL)
        val profile = turbo.core.profileStore.get(packageName ?: "")
        if (profile == null) {
            finish()
            return
        }
        setContent {
            val settings by turbo.settings.state.collectAsState()
            TrendulonTheme(settings.themeMode) {
                MaximumWarningDialog(
                    confirmLabel = "Start Maximum",
                    onConfirm = {
                        turbo.coordinator.boost(profile, trigger, maxConfirmed = true)
                        finish()
                    },
                    onDismiss = { finish() }
                )
            }
        }
    }

    companion object {
        private const val EXTRA_PACKAGE = "package"
        private const val EXTRA_TRIGGER = "trigger"

        fun intent(context: Context, packageName: String, trigger: Trigger): Intent =
            Intent(context, ConfirmBoostActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra(EXTRA_PACKAGE, packageName)
                .putExtra(EXTRA_TRIGGER, trigger.name)
    }
}
