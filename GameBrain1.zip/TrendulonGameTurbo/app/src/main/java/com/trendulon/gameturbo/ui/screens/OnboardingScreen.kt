package com.trendulon.gameturbo.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.trendulon.gameturbo.automation.TurboGraph
import com.trendulon.gameturbo.shizuku.ShizukuStatus
import com.trendulon.gameturbo.ui.components.Pill
import com.trendulon.gameturbo.ui.components.SectionLabel
import com.trendulon.gameturbo.ui.components.TCard
import com.trendulon.gameturbo.ui.components.TrendulonMark
import com.trendulon.gameturbo.ui.components.TurboButton
import com.trendulon.gameturbo.ui.components.ButtonStyle
import com.trendulon.gameturbo.ui.theme.TurboColors
import kotlinx.coroutines.launch
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.PaddingValues

private const val PAGES = 5

@Composable
fun OnboardingScreen(turbo: TurboGraph, onFinish: () -> Unit, onMessage: (String) -> Unit) {
    val pager = rememberPagerState(pageCount = { PAGES })
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
            Spacer(Modifier.weight(1f))
            if (pager.currentPage < PAGES - 1) {
                TextButton(onClick = onFinish) { Text("Skip", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
        }
        HorizontalPager(pager, Modifier.weight(1f)) { page ->
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
                verticalArrangement = Arrangement.Center
            ) {
                when (page) {
                    0 -> WelcomePage()
                    1 -> HowItWorksPage()
                    2 -> ShizukuPage(turbo)
                    3 -> PermissionsPage(turbo, onMessage)
                    else -> SafetyPage()
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
        ) {
            repeat(PAGES) { i ->
                val color by animateColorAsState(
                    if (i == pager.currentPage) TurboColors.Orange else MaterialTheme.colorScheme.outline, label = "dot"
                )
                Box(Modifier.padding(horizontal = 4.dp).size(if (i == pager.currentPage) 22.dp else 8.dp, 8.dp).clip(CircleShape).background(color))
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (pager.currentPage > 0) {
                TurboButton("Back", { scope.launch { pager.animateScrollToPage(pager.currentPage - 1) } }, Modifier.weight(1f), style = ButtonStyle.Ghost)
            }
            TurboButton(
                if (pager.currentPage == PAGES - 1) "Start" else "Next",
                {
                    if (pager.currentPage == PAGES - 1) onFinish()
                    else scope.launch { pager.animateScrollToPage(pager.currentPage + 1) }
                },
                Modifier.weight(if (pager.currentPage > 0) 2f else 1f)
            )
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun PageTitle(label: String, title: String, text: String) {
    SectionLabel(label)
    Spacer(Modifier.height(8.dp))
    Text(title, style = MaterialTheme.typography.headlineMedium)
    Spacer(Modifier.height(10.dp))
    Text(text, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Spacer(Modifier.height(20.dp))
}

@Composable
private fun WelcomePage() {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.clip(RoundedCornerShape(20.dp)).background(androidx.compose.ui.graphics.Color.Black).padding(16.dp)) {
            TrendulonMark(size = 96.dp)
        }
        Spacer(Modifier.height(24.dp))
        Text(
            androidx.compose.ui.text.buildAnnotatedString {
                append("TRENDUL")
                pushStyle(androidx.compose.ui.text.SpanStyle(color = TurboColors.Orange)); append("ON"); pop()
            },
            fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 6.sp
        )
        Text("GAME TURBO", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(28.dp))
        Text("More frames. Fewer distractions.", style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        Text(
            "Boost your game with one tap, or let Game Turbo do it when the game opens. Everything goes back to normal afterwards.",
            style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun HowItWorksPage() {
    PageTitle("How it works", "Three things happen when you boost", "No root, no tricks. Just the settings Android already has.")
    listOf(
        "01" to ("Background apps are closed" to "Frees memory and CPU for your game. Your whitelist and system apps are never touched."),
        "02" to ("The system is tuned" to "Animations off, highest refresh rate, Do Not Disturb, game mode. Maximum adds app optimisation and graphics overrides."),
        "03" to ("Everything is restored" to "Every setting is saved before it changes. One tap, or automatic when the game closes, puts it all back.")
    ).forEach { (n, pair) ->
        TCard(Modifier.padding(bottom = 10.dp)) {
            Text(n, color = TurboColors.Orange, fontWeight = FontWeight.Bold, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
            Spacer(Modifier.height(4.dp))
            Text(pair.first, style = MaterialTheme.typography.titleMedium)
            Text(pair.second, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ShizukuPage(turbo: TurboGraph) {
    val shizuku = turbo.core.shizukuManager
    val status by shizuku.status.collectAsState()
    PageTitle(
        "Step 1", "Meet Shizuku",
        "Shizuku is a free app that lets Game Turbo change system settings safely, without root. You start it once after each reboot."
    )
    Row(verticalAlignment = Alignment.CenterVertically) {
        when (status) {
            ShizukuStatus.Connected -> Pill("Connected", TurboColors.Green)
            ShizukuStatus.NotAuthorized -> Pill("Needs your OK", TurboColors.Yellow)
            ShizukuStatus.Disconnected -> Pill("Not running", TurboColors.Red)
        }
    }
    Spacer(Modifier.height(16.dp))
    listOf(
        "Install Shizuku from Google Play (or shizuku.rikka.app).",
        "Open Shizuku and choose \"Start via Wireless debugging\". Turn on Developer options and Wireless debugging first, and pair the phone when it asks.",
        "Come back here and tap Connect, then allow Game Turbo."
    ).forEachIndexed { i, step ->
        Row(Modifier.padding(bottom = 10.dp)) {
            Text("${i + 1}", color = TurboColors.Orange, fontWeight = FontWeight.Bold, modifier = Modifier.width(24.dp))
            Text(step, style = MaterialTheme.typography.bodyMedium)
        }
    }
    Spacer(Modifier.height(8.dp))
    PermissionsPanelShizukuOnly(turbo)
}

@Composable
private fun PermissionsPanelShizukuOnly(turbo: TurboGraph) {
    val shizuku = turbo.core.shizukuManager
    val status by shizuku.status.collectAsState()
    TurboButton(
        when (status) {
            ShizukuStatus.Connected -> "Connected"
            ShizukuStatus.NotAuthorized -> "Allow Game Turbo"
            ShizukuStatus.Disconnected -> "Connect to Shizuku"
        },
        { shizuku.connect() }, Modifier.fillMaxWidth(), enabled = status != ShizukuStatus.Connected
    )
}

@Composable
private fun PermissionsPage(turbo: TurboGraph, onMessage: (String) -> Unit) {
    PageTitle(
        "Step 2", "A few permissions",
        "Only what's needed. Usage access and notifications power auto-detect. The overlay is for the optional floating button."
    )
    TCard { PermissionsPanel(turbo, onMessage, showShizuku = false) }
}

@Composable
private fun SafetyPage() {
    PageTitle("Before you start", "You're always in control", "A few promises.")
    listOf(
        "Your phone's essentials are never closed: launcher, keyboard, phone, messages, accessibility.",
        "Maximum mode always shows a warning first. It can run hot and drain the battery faster.",
        "\"Restore Everything\" is on the home screen and in Settings. It puts every changed setting back.",
        "If the app is closed mid-boost, Game Turbo restores your settings automatically next time Shizuku is running."
    ).forEach { line ->
        Row(Modifier.padding(bottom = 12.dp)) {
            Text("•", color = TurboColors.Orange, fontWeight = FontWeight.Bold, modifier = Modifier.width(20.dp))
            Text(line, style = MaterialTheme.typography.bodyLarge)
        }
    }
}
