package com.trendulon.gameturbo.killer

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * User-configurable whitelist (WhatsApp, Telegram, banking apps, ...). Apps in here are never
 * killed. Persisted in SharedPreferences, observable through [whitelist].
 */
class WhitelistStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("trendulon_whitelist", Context.MODE_PRIVATE)

    private val _whitelist = MutableStateFlow(load())
    val whitelist: StateFlow<Set<String>> = _whitelist.asStateFlow()

    @Synchronized
    fun add(packageName: String): Boolean {
        if (!PackageNames.isValid(packageName)) return false
        update(_whitelist.value + packageName)
        return true
    }

    @Synchronized
    fun remove(packageName: String) = update(_whitelist.value - packageName)

    @Synchronized
    fun replaceAll(packages: Set<String>) = update(packages.filter(PackageNames::isValid).toSet())

    fun contains(packageName: String): Boolean = packageName in _whitelist.value

    private fun update(new: Set<String>) {
        _whitelist.value = new
        prefs.edit().putStringSet(KEY, new).apply()
    }

    private fun load(): Set<String> =
        prefs.getStringSet(KEY, emptySet()).orEmpty().filter(PackageNames::isValid).toSet()

    private companion object {
        const val KEY = "packages"
    }
}
