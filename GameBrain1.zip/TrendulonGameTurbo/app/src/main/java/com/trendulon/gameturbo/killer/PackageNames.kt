package com.trendulon.gameturbo.killer

/** Package-name validation. Every name is validated before it is placed into a shell command. */
internal object PackageNames {
    private val REGEX = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")

    fun isValid(name: String): Boolean = name.length <= 255 && REGEX.matches(name)
}
