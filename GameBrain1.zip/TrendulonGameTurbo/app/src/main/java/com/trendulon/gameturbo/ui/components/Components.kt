package com.trendulon.gameturbo.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.trendulon.gameturbo.profiles.BoostMode
import com.trendulon.gameturbo.ui.theme.TurboColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ---- brand -------------------------------------------------------------------------------------

/** The Trendulon "T" mark: open arc, bold T, orange dot. */
@Composable
fun TrendulonMark(modifier: Modifier = Modifier, size: Dp = 40.dp) {
    Canvas(modifier.size(size)) {
        val w = this.size.width
        val ink = Color.White
        // arc
        drawArc(
            color = ink, startAngle = 135f, sweepAngle = 155f, useCenter = false,
            topLeft = Offset(w * 0.12f, w * 0.12f), size = Size(w * 0.76f, w * 0.76f),
            style = Stroke(width = w * 0.06f, cap = StrokeCap.Round)
        )
        // T: bar + stem
        drawRect(ink, Offset(w * 0.30f, w * 0.38f), Size(w * 0.40f, w * 0.10f))
        drawRect(ink, Offset(w * 0.45f, w * 0.48f), Size(w * 0.10f, w * 0.34f))
        // dot
        drawCircle(TurboColors.Orange, radius = w * 0.055f, center = Offset(w * 0.72f, w * 0.27f))
    }
}

@Composable
fun BrandHeader(modifier: Modifier = Modifier, trailing: @Composable (() -> Unit)? = null) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.clip(RoundedCornerShape(10.dp)).background(Color.Black).padding(4.dp)) {
            TrendulonMark(size = 32.dp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(color = MaterialTheme.colorScheme.onBackground)) { append("TRENDUL") }
                    withStyle(SpanStyle(color = TurboColors.Orange)) { append("ON") }
                },
                fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 4.sp
            )
            Text(
                "GAME TURBO", style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        trailing?.invoke()
    }
}

// ---- layout bits -------------------------------------------------------------------------------

@Composable
fun TCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    borderColor: Color = MaterialTheme.colorScheme.outline,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    val base = modifier.fillMaxWidth().animateContentSize()
    val clickable = if (onClick != null) base.clip(shape).clickable(onClick = onClick) else base
    Surface(
        modifier = clickable,
        shape = shape,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, borderColor)
    ) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(), modifier = modifier,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
fun ScreenTitle(title: String, subtitle: String? = null, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(title, style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.onBackground)
        if (subtitle != null) {
            Spacer(Modifier.height(4.dp))
            Text(subtitle, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ---- buttons / pills ---------------------------------------------------------------------------

enum class ButtonStyle { Primary, Ghost, Danger, Success }

@Composable
fun TurboButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    style: ButtonStyle = ButtonStyle.Primary,
    enabled: Boolean = true
) {
    val shape = RoundedCornerShape(12.dp)
    val content: @Composable () -> Unit = {
        if (icon != null) {
            Icon(icon, null, Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
    }
    val sized = modifier.heightIn(min = 54.dp)
    when (style) {
        ButtonStyle.Primary -> Button(
            onClick, sized, enabled, shape = shape,
            colors = ButtonDefaults.buttonColors(
                containerColor = TurboColors.Orange, contentColor = Color(0xFF0A0A0A),
                disabledContainerColor = TurboColors.Orange.copy(alpha = 0.25f),
                disabledContentColor = Color(0xFF0A0A0A).copy(alpha = 0.5f)
            )
        ) { content() }
        ButtonStyle.Success -> Button(
            onClick, sized, enabled, shape = shape,
            colors = ButtonDefaults.buttonColors(
                containerColor = TurboColors.Green.copy(alpha = 0.16f), contentColor = TurboColors.Green
            ),
            border = BorderStroke(1.dp, TurboColors.Green.copy(alpha = 0.5f))
        ) { content() }
        ButtonStyle.Ghost -> Button(
            onClick, sized, enabled, shape = shape,
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                contentColor = MaterialTheme.colorScheme.onSurface
            )
        ) { content() }
        ButtonStyle.Danger -> OutlinedButton(
            onClick, sized, enabled, shape = shape,
            border = BorderStroke(1.dp, TurboColors.Red.copy(alpha = 0.6f)),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = TurboColors.Red)
        ) { content() }
    }
}

/** Outlined pill with a dot, like the "HIGH PRIORITY" tag in the newsroom. */
@Composable
fun Pill(text: String, color: Color, modifier: Modifier = Modifier, dot: Boolean = true) {
    Row(
        modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.10f))
            .border(1.dp, color.copy(alpha = 0.55f), RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (dot) {
            Box(Modifier.size(7.dp).clip(CircleShape).background(color))
            Spacer(Modifier.width(7.dp))
        }
        Text(text.uppercase(), color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.2.sp)
    }
}

@Composable
fun MetricBar(
    label: String,
    value: String,
    fraction: Float,
    modifier: Modifier = Modifier,
    color: Color = TurboColors.Orange
) {
    Column(modifier) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                label, Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 13.sp, maxLines = 1
            )
            Text(value, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        Spacer(Modifier.height(8.dp))
        Box(
            Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Box(Modifier.fillMaxWidth(fraction.coerceIn(0.03f, 1f)).height(4.dp).background(color))
        }
    }
}

// ---- boost modes -------------------------------------------------------------------------------

fun BoostMode.label(): String = when (this) {
    BoostMode.BALANCED -> "Balanced"
    BoostMode.PERFORMANCE -> "Performance"
    BoostMode.MAXIMUM -> "Maximum"
}

fun BoostMode.color(): Color = when (this) {
    BoostMode.BALANCED -> TurboColors.Green
    BoostMode.PERFORMANCE -> TurboColors.Orange
    BoostMode.MAXIMUM -> TurboColors.Red
}

fun BoostMode.description(): String = when (this) {
    BoostMode.BALANCED -> "Light touch. Closes background apps, speeds up animations, keeps a few apps in memory."
    BoostMode.PERFORMANCE -> "Recommended. Closes background apps, locks the highest refresh rate, silences notifications."
    BoostMode.MAXIMUM -> "Everything on, plus app optimisation and graphics overrides. Hotter and hungrier. Read the warning first."
}

@Composable
fun ModeSelector(
    selected: BoostMode,
    onSelect: (BoostMode) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    Column(modifier.animateContentSize()) {
        Row(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(4.dp)
                .alpha(if (enabled) 1f else 0.5f)
        ) {
            BoostMode.values().forEach { mode ->
                val isSelected = mode == selected
                val bg by animateColorAsState(
                    if (isSelected) mode.color().copy(alpha = 0.18f) else Color.Transparent, label = "modeBg"
                )
                val shape = RoundedCornerShape(10.dp)
                Box(
                    Modifier.weight(1f).clip(shape).background(bg)
                        .border(1.dp, if (isSelected) mode.color().copy(alpha = 0.6f) else Color.Transparent, shape)
                        .clickable(enabled = enabled) { onSelect(mode) }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        mode.label(), fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        color = if (isSelected) mode.color() else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(selected.description(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ---- app icons ---------------------------------------------------------------------------------

@Composable
fun AppIcon(packageName: String, modifier: Modifier = Modifier, size: Dp = 44.dp) {
    val context = LocalContext.current
    val bitmap by produceState<ImageBitmap?>(null, packageName) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                context.packageManager.getApplicationIcon(packageName).toBitmap(96, 96).asImageBitmap()
            }.getOrNull()
        }
    }
    Box(
        modifier.size(size).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        val b = bitmap
        if (b != null) {
            Image(b, contentDescription = null, modifier = Modifier.fillMaxSize())
        } else {
            Icon(Icons.Rounded.SportsEsports, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ---- pipeline rows (like "THE TRENDULON PIPELINE") ---------------------------------------------

enum class StepState { DONE, ACTIVE, WAITING }

@Composable
fun PipelineRow(index: String, title: String, subtitle: String, state: StepState, modifier: Modifier = Modifier) {
    val pulse = rememberInfiniteTransition(label = "pulse")
    val alpha by pulse.animateFloat(
        initialValue = 0.35f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "pulseAlpha"
    )
    val dot = when (state) {
        StepState.DONE -> TurboColors.Green
        StepState.ACTIVE -> TurboColors.Orange
        StepState.WAITING -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
    }
    TCard(modifier) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(index, color = TurboColors.Orange, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.size(9.dp).clip(CircleShape).background(dot)
                    .alpha(if (state == StepState.ACTIVE) alpha else 1f)
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(title, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(2.dp))
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ---- banners -----------------------------------------------------------------------------------

enum class BannerKind { Info, Warning, Error, Success }

@Composable
fun Banner(
    kind: BannerKind,
    title: String,
    text: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    val color = when (kind) {
        BannerKind.Info -> TurboColors.Orange
        BannerKind.Warning -> TurboColors.Yellow
        BannerKind.Error -> TurboColors.Red
        BannerKind.Success -> TurboColors.Green
    }
    val shape = RoundedCornerShape(14.dp)
    Row(
        modifier.fillMaxWidth().clip(shape).background(color.copy(alpha = 0.09f))
            .border(1.dp, color.copy(alpha = 0.4f), shape).padding(14.dp)
    ) {
        Icon(
            if (kind == BannerKind.Error) Icons.Rounded.ErrorOutline else Icons.Rounded.Warning,
            null, tint = color, modifier = Modifier.size(22.dp)
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, color = color)
            Spacer(Modifier.height(2.dp))
            Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (actionLabel != null && onAction != null) {
                TextButton(onClick = onAction, contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)) {
                    Text(actionLabel, color = color, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ---- settings rows -----------------------------------------------------------------------------

@Composable
fun SettingSwitchRow(
    title: String,
    subtitle: String?,
    checked: Boolean,
    onChecked: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    Row(
        modifier.fillMaxWidth().alpha(if (enabled) 1f else 0.45f)
            .clickable(enabled = enabled) { onChecked(!checked) }.padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = checked, onCheckedChange = if (enabled) onChecked else null, enabled = enabled,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color(0xFF0A0A0A), checkedTrackColor = TurboColors.Orange,
                uncheckedThumbColor = MaterialTheme.colorScheme.onSurfaceVariant,
                uncheckedTrackColor = MaterialTheme.colorScheme.surfaceVariant,
                uncheckedBorderColor = MaterialTheme.colorScheme.outline
            )
        )
    }
}

@Composable
fun SettingNavRow(title: String, subtitle: String?, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Text("›", fontSize = 24.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ---- dialogs -----------------------------------------------------------------------------------

/** Strong warning shown before Maximum mode (always, for manual starts). The user must tick the box. */
@Composable
fun MaximumWarningDialog(
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    confirmLabel: String = "I understand - continue"
) {
    var understood by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        icon = { Icon(Icons.Rounded.Warning, null, tint = TurboColors.Red, modifier = Modifier.size(32.dp)) },
        title = { Text("Maximum mode - read this first", fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("This is the most aggressive setting. It is safe to undo, but you should know what it does:")
                listOf(
                    "Your phone can get hot and the battery drains faster.",
                    "Apps are re-optimised for speed. This can take several minutes and can't be cancelled halfway.",
                    "Graphics overrides can cause glitches in some games or in the system UI.",
                    "Background apps are closed. Unsaved work in them is lost.",
                    "Everything it changes is saved first. \"Restore Everything\" is always one tap away."
                ).forEach { Text("•  $it", style = MaterialTheme.typography.bodyMedium) }
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                        .clickable { understood = !understood }.padding(top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = understood, onCheckedChange = { understood = it },
                        colors = CheckboxDefaults.colors(checkedColor = TurboColors.Orange, checkmarkColor = Color(0xFF0A0A0A))
                    )
                    Text("I understand the risks", fontWeight = FontWeight.SemiBold)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onConfirm, enabled = understood) {
                Text(confirmLabel, color = if (understood) TurboColors.Red else MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun ConfirmDialog(
    title: String,
    text: String,
    confirmLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    destructive: Boolean = false
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = { Text(text) },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text(confirmLabel, color = if (destructive) TurboColors.Red else TurboColors.Orange, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun EmptyState(title: String, text: String, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxWidth().padding(vertical = 32.dp, horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Rounded.SportsEsports, null, Modifier.size(40.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        Text(title, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(4.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
