package com.trendulon.gameturbo.killer

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import android.provider.Telephony
import android.telecom.TelecomManager

/**
 * Packages that must stay alive on THIS device, resolved at runtime:
 * this app, the default launcher(s), enabled keyboards, default dialer / SMS app and
 * enabled accessibility services. This also covers user-installed launchers and keyboards.
 */
class ProtectedPackagesResolver(context: Context) {
    private val appContext = context.applicationContext

    fun resolve(): Set<String> {
        val result = mutableSetOf(appContext.packageName)
        runCatching { result += launchers() }
        runCatching { result += inputMethods() }
        runCatching { result += accessibilityServices() }
        runCatching {
            appContext.getSystemService(TelecomManager::class.java)?.defaultDialerPackage?.let { result += it }
        }
        runCatching { Telephony.Sms.getDefaultSmsPackage(appContext)?.let { result += it } }
        return result
    }

    private fun launchers(): Set<String> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return appContext.packageManager
            .queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY or PackageManager.MATCH_ALL)
            .mapNotNull { it.activityInfo?.packageName }
            .toSet()
    }

    private fun inputMethods(): Set<String> {
        val resolver = appContext.contentResolver
        val raw = listOfNotNull(
            Settings.Secure.getString(resolver, Settings.Secure.DEFAULT_INPUT_METHOD),
            Settings.Secure.getString(resolver, Settings.Secure.ENABLED_INPUT_METHODS)
        ).joinToString(":")
        return componentPackages(raw)
    }

    private fun accessibilityServices(): Set<String> {
        val raw = Settings.Secure.getString(
            appContext.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ).orEmpty()
        return componentPackages(raw)
    }

    /** Parses "pkg/cls:pkg2/cls2" into package names. */
    private fun componentPackages(raw: String): Set<String> =
        raw.split(':')
            .filter { it.isNotBlank() }
            .mapNotNull { ComponentName.unflattenFromString(it)?.packageName }
            .toSet()
}
