package com.trendulon.gameturbo.killer

import android.util.Log
import com.trendulon.gameturbo.shizuku.ShizukuManager
import com.trendulon.gameturbo.shizuku.ShizukuNotReadyException
import com.trendulon.gameturbo.shizuku.ShizukuStatus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Force-stops every non-protected USER app (`pm list packages -3`) via `am force-stop`.
 *
 * Never killed:
 *  1. [ExclusionList] (hard-coded system packages)
 *  2. [ProtectedPackagesResolver] (this app, launcher, keyboard, dialer, SMS, accessibility)
 *  3. [WhitelistStore] (user whitelist)
 *  4. the `targets` passed in (the game being boosted)
 *  5. the app currently in the foreground (best effort)
 *
 * One pass = [killNow]. Passes never overlap (internal mutex). For repeated killing use
 * [com.trendulon.gameturbo.boost.BoostController].
 */
class ProcessKiller(
    private val shizuku: ShizukuManager,
    private val whitelist: WhitelistStore,
    private val protectedResolver: ProtectedPackagesResolver
) {
    private val passMutex = Mutex()

    /**
     * Runs one kill pass.
     * @param targets    packages that must NOT be killed (the target game(s)).
     * @param onlyRunning see [KillerConfig.onlyKillRunning].
     */
    suspend fun killNow(
        targets: Set<String> = emptySet(),
        onlyRunning: Boolean = true
    ): KillReport = passMutex.withLock {
        val startedAt = System.currentTimeMillis()
        if (shizuku.status.value != ShizukuStatus.Connected) {
            return@withLock KillReport(error = "Shizuku is ${shizuku.status.value}")
        }
        try {
            runPass(targets, onlyRunning, startedAt)
        } catch (e: CancellationException) {
            throw e
        } catch (e: ShizukuNotReadyException) {
            KillReport(error = e.message ?: "Shizuku not ready", durationMs = elapsed(startedAt))
        } catch (t: Throwable) {
            Log.e(TAG, "Kill pass failed", t)
            KillReport(error = t.toString(), durationMs = elapsed(startedAt))
        }
    }

    private suspend fun runPass(targets: Set<String>, onlyRunning: Boolean, startedAt: Long): KillReport {
        val candidates = listUserPackages()
        if (candidates.isEmpty()) {
            return KillReport(error = "Could not list installed user apps", durationMs = elapsed(startedAt))
        }

        val protectedSet = buildProtectedSet(targets)
        val killable = candidates.filter { it !in protectedSet && !ExclusionList.isHardExcluded(it) }
        val skipped = candidates.size - killable.size

        val running = if (onlyRunning) runningPackages() else null // null => unknown, kill all
        val toKill = if (running != null) killable.filter { it in running } else killable
        if (toKill.isEmpty()) {
            return KillReport(skippedProtected = skipped, durationMs = elapsed(startedAt))
        }

        val killed = linkedSetOf<String>()
        val failed = linkedSetOf<String>()
        forceStop(toKill, killed, failed)

        // Verify and retry survivors once.
        var survivors = emptyList<String>()
        if (running != null) {
            delay(VERIFY_DELAY_MS)
            val after = runningPackages()
            if (after != null) {
                val stillRunning = toKill.filter { it in after }
                if (stillRunning.isNotEmpty()) {
                    forceStop(stillRunning, killed, failed)
                    delay(VERIFY_DELAY_MS)
                    val last = runningPackages().orEmpty()
                    survivors = stillRunning.filter { it in last }
                }
            }
        }

        return KillReport(
            killed = killed.toList(),
            failed = failed.toList(),
            survivors = survivors,
            skippedProtected = skipped,
            durationMs = elapsed(startedAt)
        )
    }

    private suspend fun buildProtectedSet(targets: Set<String>): Set<String> {
        val set = HashSet<String>()
        set += protectedResolver.resolve()
        set += whitelist.whitelist.value
        set += targets
        set += foregroundPackages()
        return set
    }

    /** Best effort: package(s) of the resumed activity, so the app the user is using is not killed. */
    private suspend fun foregroundPackages(): Set<String> {
        val result = runCatching { shizuku.exec("dumpsys activity activities | grep -E 'ResumedActivity'") }
            .getOrNull() ?: return emptySet()
        return RESUMED_REGEX.findAll(result.stdout).map { it.groupValues[1] }.toSet()
    }

    /** Third-party (user-installed) packages. */
    private suspend fun listUserPackages(): List<String> {
        val result = shizuku.exec("pm list packages -3")
        if (!result.isSuccess) {
            Log.w(TAG, "pm list packages failed: ${result.stderr}")
            return emptyList()
        }
        return result.stdout.lineSequence()
            .map { it.trim().removePrefix("package:") }
            .filter(PackageNames::isValid)
            .distinct()
            .toList()
    }

    /** Package names that currently own a process, or null if the process list is unreadable. */
    private suspend fun runningPackages(): Set<String>? {
        val result = shizuku.exec("ps -A -o NAME")
        if (!result.isSuccess) return null
        val names = result.stdout.lineSequence()
            .map { it.trim().substringBefore(':') } // "com.app:service" -> "com.app"
            .filter(PackageNames::isValid)
            .toSet()
        // An empty set is suspicious (ps restricted): treat as unknown instead of "nothing running".
        return names.ifEmpty { null }
    }

    /** Force-stops [packages] in small batches; per-package success is read from the output. */
    private suspend fun forceStop(
        packages: List<String>,
        killed: MutableSet<String>,
        failed: MutableSet<String>
    ) {
        for (chunk in packages.chunked(CHUNK_SIZE)) {
            // Names were validated by PackageNames, so they are safe to place in the command.
            val list = chunk.joinToString(" ")
            val script = "for p in $list; do " +
                "am force-stop \"\$p\" >/dev/null 2>&1 && echo \"OK:\$p\" || echo \"FAIL:\$p\"; done"
            val result = shizuku.exec(script, timeoutMs = CHUNK_TIMEOUT_MS)
            val ok = HashSet<String>()
            result.stdout.lineSequence().forEach { line ->
                when {
                    line.startsWith("OK:") -> ok += line.removePrefix("OK:").trim()
                    line.startsWith("FAIL:") -> failed += line.removePrefix("FAIL:").trim()
                }
            }
            chunk.forEach { pkg ->
                if (pkg in ok) {
                    killed += pkg
                    failed -= pkg
                } else if (pkg !in failed) {
                    failed += pkg // no output for it => treat as failed
                }
            }
        }
    }

    private fun elapsed(startedAt: Long) = System.currentTimeMillis() - startedAt

    private companion object {
        const val TAG = "ProcessKiller"
        const val CHUNK_SIZE = 15
        const val CHUNK_TIMEOUT_MS = 30_000L
        const val VERIFY_DELAY_MS = 400L
        // e.g. "mResumedActivity: ActivityRecord{abc u0 com.pkg/.MainActivity t12}"
        val RESUMED_REGEX = Regex("\\bu\\d+\\s+([A-Za-z0-9_.]+)/")
    }
}
