package com.trendulon.gameturbo

import android.app.Application

class TrendulonApp : Application() {

    lateinit var graph: AppGraph
        private set

    override fun onCreate() {
        super.onCreate()
        graph = AppGraph(this)
        graph.shizukuManager.start() // status is checked on launch and continuously afterwards
    }
}
