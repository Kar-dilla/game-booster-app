package com.trendulon.gameturbo.ui.screens

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableIntState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.trendulon.gameturbo.automation.PermissionHelper
import com.trendulon.gameturbo.automation.TurboGraph
import com.trendulon.gameturbo.shizuku.ShizukuStatus
import com.trendulon.gameturbo.ui.theme.TurboColors
import kotlinx.coroutines.launch

/** Bumps every time the user comes back to the app, so permission rows re-check themselves. */
@Composable
fun rememberPermissionTick(): MutableIntState {
    val tick = remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick.intValue++ }
    return tick
}

@Composable
fun PermissionRow(
    title: String,
    description: String,
    granted: Boolean,
    actionLabel: String,
    onAction: () -> Unit,
    secondaryLabel: String? = null,
    onSecondary: (() -> Unit)? = null,
    optional: Boolean = false
) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.Top) {
        Icon(
            if (granted) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
            null, Modifier.size(24.dp),
            tint = if (granted) TurboColors.Green else MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                if (optional) {
                    Spacer(Modifier.width(8.dp))
                    Text("OPTIONAL", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (!granted) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = onAction, contentPadding = androidx.compose.foundation.layout.PaddingValues(end = 12.dp)) {
                        Text(actionLabel, color = TurboColors.Orange, fontWeight = FontWeight.Bold)
                    }
                    if (secondaryLabel != null && onSecondary != null) {
                        TextButton(onClick = onSecondary, contentPadding = androidx.compose.foundation.layout.PaddingValues(end = 12.dp)) {
                            Text(secondaryLabel, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

/** Shizuku + notifications + usage access + overlay. Used by onboarding and Settings. */
@Composable
fun PermissionsPanel(
    turbo: TurboGraph,
    onMessage: (String) -> Unit,
    showShizuku: Boolean = true
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val tick = rememberPermissionTick()
    val shizuku = turbo.core.shizukuManager
    val shizukuStatus by shizuku.status.collectAsState()
    val connected = shizukuStatus == ShizukuStatus.Connected
    val pkg = context.packageName

    @Suppress("UNUSED_VARIABLE") val recheck = tick.intValue // read so the rows below recompose on resume
    val notificationsOk = PermissionHelper.hasNotifications(context)
    val usageOk = PermissionHelper.hasUsageAccess(context)
    val overlayOk = PermissionHelper.hasOverlay(context)

    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        tick.intValue++
    }

    fun open(intent: Intent) {
        try { context.startActivity(intent) } catch (_: ActivityNotFoundException) {
            onMessage("Couldn't open that settings page on this phone.")
        }
    }

    Column {
        if (showShizuku) {
            PermissionRow(
                title = "Shizuku",
                description = when (shizukuStatus) {
                    ShizukuStatus.Connected -> "Connected. Game Turbo can do its job."
                    ShizukuStatus.NotAuthorized -> "Running, but Game Turbo isn't allowed yet."
                    ShizukuStatus.Disconnected ->
                        if (shizuku.isShizukuAppInstalled()) "Installed but not running. Start it with Wireless debugging."
                        else "Not installed. It's the free app that lets Game Turbo work without root."
                },
                granted = connected,
                actionLabel = if (shizukuStatus == ShizukuStatus.NotAuthorized) "Allow" else "Connect",
                onAction = { shizuku.connect() },
                secondaryLabel = if (!shizuku.isShizukuAppInstalled()) "Get Shizuku" else null,
                onSecondary = {
                    val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=moe.shizuku.privileged.api"))
                    val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))
                    try { context.startActivity(market.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    catch (_: Exception) { open(web.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                }
            )
        }
        PermissionRow(
            title = "Notifications",
            description = "Shows the status of a running boost and heat warnings.",
            granted = notificationsOk,
            actionLabel = "Allow",
            onAction = {
                if (Build.VERSION.SDK_INT >= 33) notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                else open(PermissionHelper.notificationSettingsIntent(context))
            },
            secondaryLabel = if (connected && Build.VERSION.SDK_INT >= 33) "Grant with Shizuku" else null,
            onSecondary = {
                scope.launch {
                    val ok = PermissionHelper.grantNotifications(shizuku, pkg)
                    tick.intValue++
                    onMessage(if (ok) "Notifications allowed" else "Couldn't grant it - use Allow instead.")
                }
            }
        )
        PermissionRow(
            title = "Usage access",
            description = "Lets Game Turbo see when your game opens or closes (auto-detect).",
            granted = usageOk,
            actionLabel = if (connected) "Grant with Shizuku" else "Open settings",
            onAction = {
                if (connected) {
                    scope.launch {
                        val ok = PermissionHelper.grantUsageAccess(shizuku, pkg)
                        tick.intValue++
                        onMessage(if (ok) "Usage access granted" else "Couldn't grant it - open settings instead.")
                    }
                } else open(PermissionHelper.usageAccessIntent())
            },
            secondaryLabel = if (connected) "Open settings" else null,
            onSecondary = { open(PermissionHelper.usageAccessIntent()) }
        )
        PermissionRow(
            title = "Display over other apps",
            description = "Only for the floating boost button.",
            granted = overlayOk,
            actionLabel = if (connected) "Grant with Shizuku" else "Open settings",
            onAction = {
                if (connected) {
                    scope.launch {
                        val ok = PermissionHelper.grantOverlay(shizuku, pkg)
                        tick.intValue++
                        onMessage(if (ok) "Overlay allowed" else "Couldn't grant it - open settings instead.")
                    }
                } else open(PermissionHelper.overlayIntent(context))
            },
            secondaryLabel = if (connected) "Open settings" else null,
            onSecondary = { open(PermissionHelper.overlayIntent(context)) },
            optional = true
        )
    }
}
