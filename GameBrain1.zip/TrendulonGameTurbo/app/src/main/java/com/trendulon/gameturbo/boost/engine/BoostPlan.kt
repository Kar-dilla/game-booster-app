package com.trendulon.gameturbo.boost.engine

import com.trendulon.gameturbo.profiles.BoostMode

/** Compiler filter used by the Maximum mode `pm compile -m <filter> -f <pkg>` step. */
enum class CompileFilter(val value: String) { SPEED("speed"), EVERYTHING("everything") }

/**
 * Everything that differs between the three modes lives HERE, in one table.
 * Change a number in this file and nothing else needs to move.
 *
 * Mandatory steps (game mode, process limit, animations, refresh rate, battery/appops, DND,
 * trim-caches + kill-all) run in every mode. Only their intensity differs. Optional steps
 * (compile, HW overlays, GPU rendering) run in MAXIMUM only.
 */
data class BoostPlan(
    /** Background (cached) process cap. 0 = "no background processes". */
    val backgroundProcessLimit: Int,
    /** Set `min_refresh_rate` too (locks the peak rate) instead of only raising `peak_refresh_rate`. */
    val lockRefreshRate: Boolean,
    val compile: CompileFilter?,
    val disableHwOverlays: Boolean,
    val forceGpuRendering: Boolean
) {
    companion object {
        fun forMode(mode: BoostMode, options: BoostOptions = BoostOptions()): BoostPlan = when (mode) {
            BoostMode.BALANCED -> BoostPlan(
                backgroundProcessLimit = 4,
                lockRefreshRate = false,
                compile = null,
                disableHwOverlays = false,
                forceGpuRendering = false
            )
            BoostMode.PERFORMANCE -> BoostPlan(
                backgroundProcessLimit = 0,
                lockRefreshRate = true,
                compile = null,
                disableHwOverlays = false,
                forceGpuRendering = false
            )
            BoostMode.MAXIMUM -> BoostPlan(
                backgroundProcessLimit = 0,
                lockRefreshRate = true,
                compile = options.maximumCompileFilter,
                disableHwOverlays = true,
                forceGpuRendering = true
            )
        }
    }
}

/** Knobs the caller may override without touching the mode table. */
data class BoostOptions(
    /** `speed` (default, faster + smaller) or `everything` (slow, large). */
    val maximumCompileFilter: CompileFilter = CompileFilter.SPEED,
    /**
     * `pm trim-caches` wipes the cache of EVERY app, including the target game's own cache
     * (shader / asset caches), so the first load after a boost can be slower. Mandatory per
     * the spec, so it defaults to true; set false to skip it.
     */
    val trimCaches: Boolean = true
)
