package com.trendulon.gameturbo.automation

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Process
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import com.trendulon.gameturbo.shizuku.ShizukuManager

/** Checks and (where Shizuku can help) grants the extra permissions the UI layer needs. */
object PermissionHelper {

    /** Usage access: lets us see which app is in the foreground (auto-detect). */
    @Suppress("DEPRECATION")
    fun hasUsageAccess(context: Context): Boolean = runCatching {
        val ops = context.getSystemService(AppOpsManager::class.java)
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
        } else {
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
        }
        mode == AppOpsManager.MODE_ALLOWED
    }.getOrDefault(false)

    /** Draw over other apps: needed for the floating button only. */
    fun hasOverlay(context: Context): Boolean = Settings.canDrawOverlays(context)

    fun hasNotifications(context: Context): Boolean =
        NotificationManagerCompat.from(context).areNotificationsEnabled()

    fun usageAccessIntent(): Intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun overlayIntent(context: Context): Intent =
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun notificationSettingsIntent(context: Context): Intent =
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    // ---- one-tap grants through Shizuku (shell uid can set these app-ops) ----

    suspend fun grantUsageAccess(shizuku: ShizukuManager, packageName: String): Boolean =
        shell(shizuku, "appops set $packageName GET_USAGE_STATS allow")

    suspend fun grantOverlay(shizuku: ShizukuManager, packageName: String): Boolean =
        shell(shizuku, "appops set $packageName SYSTEM_ALERT_WINDOW allow")

    suspend fun grantNotifications(shizuku: ShizukuManager, packageName: String): Boolean =
        if (Build.VERSION.SDK_INT >= 33) {
            shell(shizuku, "pm grant $packageName android.permission.POST_NOTIFICATIONS")
        } else true

    private suspend fun shell(shizuku: ShizukuManager, command: String): Boolean =
        runCatching { shizuku.exec(command).isSuccess }.getOrDefault(false)
}
