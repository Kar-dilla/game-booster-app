package com.trendulon.gameturbo.shizuku

import android.util.Log
import rikka.shizuku.Shizuku
import java.lang.reflect.Method
import kotlin.concurrent.thread

/**
 * Runs a shell command straight through the Shizuku server (`Shizuku.newProcess`), WITHOUT binding
 * the user service. Binding is the step that was timing out (2 x 20 s = the 40 s "took too long").
 *
 * `newProcess` is private since Shizuku API 13.1, so it is called by reflection (widely used, works
 * with the same permission the app already has). If it is not available, [run] returns null and
 * [ShizukuManager.exec] falls back to the user-service path exactly as before.
 */
internal object DirectShell {
    private const val TAG = "DirectShell"
    private const val EXIT_TIMEOUT = -2
    private const val EXIT_ERROR = -1

    private val newProcessMethod: Method? by lazy {
        runCatching {
            Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            ).apply { isAccessible = true }
        }.onFailure { Log.w(TAG, "newProcess not available: $it") }.getOrNull()
    }

    /** Blocking. Returns null when this path cannot be used (caller must fall back). */
    fun run(command: String, timeoutMs: Long): ShellResult? {
        val method = newProcessMethod ?: return null
        val process: Process = try {
            method.invoke(null, arrayOf("sh", "-c", command), null, null) as? Process ?: return null
        } catch (t: Throwable) {
            Log.w(TAG, "newProcess failed: ${t.cause ?: t}")
            return null
        }

        return try {
            runCatching { process.outputStream.close() }
            val out = StringBuilder()
            val err = StringBuilder()
            // Drain both streams concurrently, otherwise a full pipe can deadlock the process.
            val outReader = thread(isDaemon = true) {
                runCatching { process.inputStream.bufferedReader().forEachLine { out.appendLine(it) } }
            }
            val errReader = thread(isDaemon = true) {
                runCatching { process.errorStream.bufferedReader().forEachLine { err.appendLine(it) } }
            }
            val exit = IntArray(1) { EXIT_ERROR }
            val waiter = thread(isDaemon = true) {
                exit[0] = try { process.waitFor() } catch (e: Throwable) { EXIT_ERROR }
            }
            waiter.join(timeoutMs)
            if (waiter.isAlive) {
                runCatching { process.destroy() }
                waiter.interrupt()
                outReader.join(500)
                errReader.join(500)
                return ShellResult(EXIT_TIMEOUT, out.toString(), "timeout after ${timeoutMs}ms\n$err")
            }
            outReader.join(2_000)
            errReader.join(2_000)
            ShellResult(exit[0], out.toString(), err.toString())
        } catch (t: Throwable) {
            Log.w(TAG, "direct exec failed: $t")
            ShellResult(EXIT_ERROR, "", t.toString())
        }
    }
}
