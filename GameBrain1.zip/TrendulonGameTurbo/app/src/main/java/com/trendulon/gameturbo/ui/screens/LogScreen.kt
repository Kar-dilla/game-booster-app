package com.trendulon.gameturbo.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.trendulon.gameturbo.automation.LogEntry
import com.trendulon.gameturbo.automation.LogLevel
import com.trendulon.gameturbo.automation.TurboGraph
import com.trendulon.gameturbo.ui.components.ButtonStyle
import com.trendulon.gameturbo.ui.components.ConfirmDialog
import com.trendulon.gameturbo.ui.components.EmptyState
import com.trendulon.gameturbo.ui.components.ScreenTitle
import com.trendulon.gameturbo.ui.components.TurboButton
import com.trendulon.gameturbo.ui.theme.TurboColors
import java.text.DateFormat
import java.util.Date

@Composable
fun LogScreen(turbo: TurboGraph) {
    val entries by turbo.log.entries.collectAsState()
    var confirmClear by remember { mutableStateOf(false) }

    if (confirmClear) {
        ConfirmDialog(
            "Clear the log?", "This only removes the history list. It doesn't change any settings.",
            "Clear", onConfirm = { turbo.log.clear(); confirmClear = false },
            onDismiss = { confirmClear = false }, destructive = true
        )
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { ScreenTitle("Log", "Everything Game Turbo did, newest first.") }
        if (entries.isNotEmpty()) {
            item { TurboButton("Clear log", { confirmClear = true }, Modifier.fillMaxWidth(), style = ButtonStyle.Ghost) }
        } else {
            item { EmptyState("Nothing yet", "Boosts, restores and warnings will show up here.") }
        }
        items(entries) { LogRow(it) }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
private fun LogRow(entry: LogEntry) {
    val color = when (entry.level) {
        LogLevel.INFO -> MaterialTheme.colorScheme.onSurfaceVariant
        LogLevel.SUCCESS -> TurboColors.Green
        LogLevel.WARNING -> TurboColors.Yellow
        LogLevel.ERROR -> TurboColors.Red
    }
    val time = remember(entry.time) {
        val d = Date(entry.time)
        DateFormat.getDateInstance(DateFormat.MEDIUM).format(d) + "  " + DateFormat.getTimeInstance(DateFormat.MEDIUM).format(d)
    }
    Row(
        Modifier.fillMaxWidth().height(IntrinsicSize.Min).clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surface)
    ) {
        Box(Modifier.width(4.dp).fillMaxHeight().background(color))
        Column(Modifier.padding(14.dp)) {
            Text(entry.title, fontWeight = FontWeight.Bold)
            if (entry.detail.isNotBlank()) {
                Spacer(Modifier.height(2.dp))
                Text(entry.detail, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(6.dp))
            Text(time, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = color)
        }
    }
}
