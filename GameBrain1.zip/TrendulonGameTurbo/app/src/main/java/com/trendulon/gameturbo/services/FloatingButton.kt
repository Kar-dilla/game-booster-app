package com.trendulon.gameturbo.services

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import com.trendulon.gameturbo.R
import com.trendulon.gameturbo.automation.Trigger
import com.trendulon.gameturbo.automation.TurboGraph
import com.trendulon.gameturbo.automation.TurboUiState
import com.trendulon.gameturbo.ui.ConfirmBoostActivity
import com.trendulon.gameturbo.ui.MainActivity
import kotlin.math.abs

/**
 * Optional draggable bolt button drawn over games (needs "Display over other apps").
 * Tap: boost the selected game / restore. Drag: move it; it snaps to the nearest screen edge.
 * Plain Views on purpose: a Compose overlay needs lifecycle owners that a service does not have.
 */
class FloatingButton(
    private val context: Context,
    private val turbo: TurboGraph
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val density = context.resources.displayMetrics.density
    private val size = (56 * density).toInt()

    private var root: FrameLayout? = null
    private var background: GradientDrawable? = null
    private var icon: ImageView? = null
    private var params: WindowManager.LayoutParams? = null

    fun show() {
        if (root != null || !Settings.canDrawOverlays(context)) return
        val s = turbo.settings.value

        val bg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#E6111111"))
            setStroke((2 * density).toInt(), Color.parseColor("#FF6A00"))
        }
        val bolt = ImageView(context).apply {
            setImageResource(R.drawable.ic_bolt)
            setColorFilter(Color.parseColor("#FF6A00"))
            val pad = (14 * density).toInt()
            setPadding(pad, pad, pad, pad)
        }
        val frame = FrameLayout(context).apply {
            background = bg
            addView(bolt, FrameLayout.LayoutParams(size, size))
            elevation = 8 * density
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, // minSdk is 26
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = s.floatingX
            y = s.floatingY
        }

        frame.setOnTouchListener(DragListener(lp, frame))
        runCatching { windowManager.addView(frame, lp) }.onSuccess {
            root = frame; background = bg; icon = bolt; params = lp
        }
    }

    fun hide() {
        root?.let { runCatching { windowManager.removeView(it) } }
        root = null; background = null; icon = null; params = null
    }

    fun render(ui: TurboUiState) {
        val bg = background ?: return
        val bolt = icon ?: return
        val orange = Color.parseColor("#FF6A00")
        when {
            ui.active -> {
                bg.setColor(orange)
                bg.setStroke((2 * density).toInt(), orange)
                bolt.setColorFilter(Color.parseColor("#0A0A0A"))
                root?.alpha = 1f
            }
            ui.busy -> {
                bg.setColor(Color.parseColor("#E6111111"))
                bolt.setColorFilter(orange)
                root?.alpha = 0.5f
            }
            else -> {
                bg.setColor(Color.parseColor("#E6111111"))
                bg.setStroke((2 * density).toInt(), orange)
                bolt.setColorFilter(orange)
                root?.alpha = 0.92f
            }
        }
    }

    private fun onTap() {
        val coordinator = turbo.coordinator
        val ui = coordinator.ui.value
        when {
            ui.busy -> Unit
            ui.active -> coordinator.restore(Trigger.FLOATING)
            else -> {
                val profile = coordinator.defaultProfile()
                if (profile == null) {
                    context.startActivity(
                        Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } else if (coordinator.requiresMaxConfirmation(profile, Trigger.FLOATING)) {
                    context.startActivity(ConfirmBoostActivity.intent(context, profile.packageName, Trigger.FLOATING))
                } else {
                    coordinator.boost(profile, Trigger.FLOATING)
                }
            }
        }
    }

    private inner class DragListener(
        private val lp: WindowManager.LayoutParams,
        private val view: View
    ) : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f
        private var moved = false

        override fun onTouch(v: View, event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = event.rawX; touchY = event.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - touchX
                    val dy = event.rawY - touchY
                    if (abs(dx) > 8 * density || abs(dy) > 8 * density) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        runCatching { windowManager.updateViewLayout(view, lp) }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                        onTap()
                    } else {
                        val screenW = context.resources.displayMetrics.widthPixels
                        val margin = (8 * density).toInt()
                        lp.x = if (lp.x + size / 2 < screenW / 2) margin else screenW - size - margin
                        runCatching { windowManager.updateViewLayout(view, lp) }
                        turbo.settings.update { it.copy(floatingX = lp.x, floatingY = lp.y) }
                    }
                }
            }
            return true
        }
    }
}
