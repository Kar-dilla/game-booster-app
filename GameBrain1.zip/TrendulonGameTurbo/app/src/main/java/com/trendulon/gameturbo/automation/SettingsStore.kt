package com.trendulon.gameturbo.automation

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ThemeMode { SYSTEM, DARK, LIGHT }

/** Everything the UI layer (Dev 3) stores. Core settings (whitelist, continuous kill) stay in Dev 1's stores. */
data class TurboSettings(
    val themeMode: ThemeMode = ThemeMode.DARK,
    val onboardingDone: Boolean = false,
    /** Watch for the selected game(s) and boost automatically. */
    val autoDetect: Boolean = false,
    /** Restore when the game goes to background / closes. */
    val autoRestore: Boolean = true,
    /** Never auto-restore: boost stays until the user turns it off. */
    val keepBoostUntilManual: Boolean = false,
    /** Grace period before auto-restore, so a notification shade or quick app switch does not undo the boost. */
    val restoreDelaySeconds: Int = 8,
    /** Maximum mode may start without a prompt when a game is auto-detected. Off by default (safety). */
    val allowAutoMaximum: Boolean = false,
    val floatingButton: Boolean = false,
    val floatingX: Int = 16,
    val floatingY: Int = 400,
    val temperatureWarning: Boolean = true,
    val temperatureLimitC: Int = 42,
    val lastProfilePackage: String? = null
)

class SettingsStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("trendulon_ui_settings", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(load())
    val state: StateFlow<TurboSettings> = _state.asStateFlow()
    val value: TurboSettings get() = _state.value

    @Synchronized
    fun update(transform: (TurboSettings) -> TurboSettings) {
        val new = transform(_state.value)
        _state.value = new
        save(new)
    }

    private fun load(): TurboSettings {
        val d = TurboSettings()
        return TurboSettings(
            themeMode = runCatching { ThemeMode.valueOf(prefs.getString("theme", d.themeMode.name)!!) }
                .getOrDefault(d.themeMode),
            onboardingDone = prefs.getBoolean("onboarding_done", d.onboardingDone),
            autoDetect = prefs.getBoolean("auto_detect", d.autoDetect),
            autoRestore = prefs.getBoolean("auto_restore", d.autoRestore),
            keepBoostUntilManual = prefs.getBoolean("keep_until_manual", d.keepBoostUntilManual),
            restoreDelaySeconds = prefs.getInt("restore_delay", d.restoreDelaySeconds),
            allowAutoMaximum = prefs.getBoolean("allow_auto_max", d.allowAutoMaximum),
            floatingButton = prefs.getBoolean("floating", d.floatingButton),
            floatingX = prefs.getInt("floating_x", d.floatingX),
            floatingY = prefs.getInt("floating_y", d.floatingY),
            temperatureWarning = prefs.getBoolean("temp_warning", d.temperatureWarning),
            temperatureLimitC = prefs.getInt("temp_limit", d.temperatureLimitC),
            lastProfilePackage = prefs.getString("last_profile", null)
        )
    }

    private fun save(s: TurboSettings) {
        prefs.edit()
            .putString("theme", s.themeMode.name)
            .putBoolean("onboarding_done", s.onboardingDone)
            .putBoolean("auto_detect", s.autoDetect)
            .putBoolean("auto_restore", s.autoRestore)
            .putBoolean("keep_until_manual", s.keepBoostUntilManual)
            .putInt("restore_delay", s.restoreDelaySeconds)
            .putBoolean("allow_auto_max", s.allowAutoMaximum)
            .putBoolean("floating", s.floatingButton)
            .putInt("floating_x", s.floatingX)
            .putInt("floating_y", s.floatingY)
            .putBoolean("temp_warning", s.temperatureWarning)
            .putInt("temp_limit", s.temperatureLimitC)
            .putString("last_profile", s.lastProfilePackage)
            .apply()
    }
}
