package com.trendulon.gameturbo.services

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.trendulon.gameturbo.automation.Trigger
import com.trendulon.gameturbo.automation.Turbo

/** Handles the "Restore" button on the status notification. */
class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_RESTORE) {
            Turbo.of(context).coordinator.restore(Trigger.MANUAL)
        }
    }

    companion object {
        const val ACTION_RESTORE = "com.trendulon.gameturbo.action.RESTORE"
    }
}
