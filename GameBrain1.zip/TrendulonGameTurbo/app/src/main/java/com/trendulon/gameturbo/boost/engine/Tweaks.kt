package com.trendulon.gameturbo.boost.engine

/** One entry in the ordered boost sequence. */
internal sealed interface Step { val id: String }

/**
 * A reversible change: read the original -> apply -> restore.
 * [verifiable] = the value can be read back after a restore to prove it matches the original.
 */
internal class Tweak(
    override val id: String,
    val verifiable: Boolean,
    val read: suspend (Sh) -> Original?,
    val apply: suspend (Sh) -> Outcome,
    val restore: suspend (Sh, Original) -> Outcome
) : Step

/** A one-way command (cache wipe, kill-all). Nothing to restore. */
internal class Action(
    override val id: String,
    /** Recorded in the snapshot so the restore report can say it cannot be undone. */
    val irreversibleTag: String,
    val run: suspend (Sh) -> Outcome
) : Step

internal class TweakContext(
    val pkg: String,
    val plan: BoostPlan,
    val options: BoostOptions,
    val sdkInt: Int,
    /** Peak refresh rate of the panel in Hz, or null when it could not be detected. */
    val refreshHz: Int?
)

internal class BuiltSteps(val steps: List<Step>, val skipped: List<StepResult>)

internal object Tweaks {

    /**
     * The ordered sequence. THE ORDER BELOW IS THE EXECUTION ORDER from the spec:
     *  1 game mode, 2 background process limit, 3 animations, 4 refresh rate,
     *  5 battery unrestricted + appops, 6 Do Not Disturb, 7 trim-caches then kill-all,
     *  then (Maximum only) 8 compile, 9 HW overlays, 10 GPU rendering.
     */
    fun build(c: TweakContext): BuiltSteps {
        val steps = ArrayList<Step>()
        val skipped = ArrayList<StepResult>()

        if (c.sdkInt >= 31) steps += gameMode(c.pkg)
        else skipped += StepResult("game_mode:${c.pkg}", StepStatus.SKIPPED, "needs Android 12+")

        steps += backgroundLimit(c.plan.backgroundProcessLimit, c.sdkInt)

        steps += setting("global", "window_animation_scale", "0")
        steps += setting("global", "transition_animation_scale", "0")
        steps += setting("global", "animator_duration_scale", "0")

        val hz = c.refreshHz
        if (c.sdkInt >= 29 && hz != null) {
            steps += setting("system", "peak_refresh_rate", hz.toString())
            if (c.plan.lockRefreshRate) steps += setting("system", "min_refresh_rate", hz.toString())
        } else {
            skipped += StepResult("refresh_rate", StepStatus.SKIPPED, "peak refresh rate could not be detected")
        }

        steps += deviceIdle(c.pkg)
        steps += appOp(c.pkg, "RUN_IN_BACKGROUND")
        steps += appOp(c.pkg, "RUN_ANY_IN_BACKGROUND")

        steps += doNotDisturb()

        if (c.options.trimCaches) steps += trimCaches()
        steps += killAll()

        c.plan.compile?.let { steps += compile(c.pkg, it) }
        if (c.plan.disableHwOverlays) steps += hwOverlays()
        if (c.plan.forceGpuRendering) steps += gpuRendering()

        return BuiltSteps(steps, skipped)
    }

    /** id -> Tweak for every package in the snapshot. Used by restore (values are irrelevant there). */
    fun catalogue(packages: Collection<String>, sdkInt: Int): Map<String, Tweak> {
        val map = LinkedHashMap<String, Tweak>()
        for (pkg in packages) {
            val ctx = TweakContext(pkg, BoostPlan.forMode(com.trendulon.gameturbo.profiles.BoostMode.MAXIMUM),
                BoostOptions(), sdkInt, refreshHz = 1)
            build(ctx).steps.filterIsInstance<Tweak>().forEach { map.putIfAbsent(it.id, it) }
        }
        return map
    }

    /** Package a per-package id belongs to, or null for a global id. Ids look like "kind:pkg[:x]". */
    fun packageOf(id: String): String? = id.split(':').getOrNull(1)

    // ---- individual steps ------------------------------------------------------------------

    private fun setting(ns: String, key: String, value: String): Tweak = Tweak(
        id = "setting.$ns.$key",
        verifiable = true,
        read = { sh ->
            val r = sh.run("settings get $ns $key")
            if (!r.isSuccess) null else {
                val v = BoostParsers.settingValue(r.stdout)
                if (v != null && !Safe.isToken(v)) null else Original(v)
            }
        },
        apply = { sh -> sh.change("settings put $ns $key ${Safe.q(value)}") },
        restore = { sh, o ->
            if (o.value == null) sh.change("settings delete $ns $key")
            else sh.change("settings put $ns $key ${Safe.q(o.value)}")
        }
    )

    /** `cmd game mode performance <pkg>` (Android 12+). */
    private fun gameMode(pkg: String): Tweak = Tweak(
        id = "game_mode:$pkg",
        verifiable = true,
        read = { sh ->
            val r = sh.run("cmd game list-modes $pkg")
            if (!r.isSuccess) null else {
                val m = BoostParsers.currentGameMode(r.stdout)
                if (m != null && m in GAME_MODES) Original(m) else Original("standard", assumed = true)
            }
        },
        apply = { sh -> sh.change("cmd game mode performance $pkg") },
        restore = { sh, o -> sh.change("cmd game mode ${o.value ?: "standard"} $pkg") }
    )

    /**
     * Background process limit. Same cap the "Background process limit" developer option sets,
     * written the way a shell can write it:
     *  - Android 12+ : device_config activity_manager max_cached_processes
     *  - Android 8-11: max_cached_processes inside Settings.Global activity_manager_constants
     */
    private fun backgroundLimit(limit: Int, sdkInt: Int): Tweak {
        if (sdkInt >= 31) {
            return Tweak(
                id = "bg_limit.device_config",
                verifiable = true,
                read = { sh ->
                    val r = sh.run("device_config get activity_manager max_cached_processes")
                    if (!r.isSuccess) null else {
                        val v = BoostParsers.settingValue(r.stdout)
                        if (v != null && !Safe.isToken(v)) null else Original(v)
                    }
                },
                apply = { sh -> sh.change("device_config put activity_manager max_cached_processes $limit") },
                restore = { sh, o ->
                    if (o.value == null) sh.change("device_config delete activity_manager max_cached_processes")
                    else sh.change("device_config put activity_manager max_cached_processes ${Safe.q(o.value)}")
                }
            )
        }
        return Tweak(
            id = "bg_limit.settings",
            verifiable = true,
            read = { sh ->
                val r = sh.run("settings get global activity_manager_constants")
                if (!r.isSuccess) null else {
                    val v = BoostParsers.settingValue(r.stdout)
                    if (v != null && !Safe.isToken(v)) null else Original(v)
                }
            },
            apply = { sh ->
                val current = BoostParsers.settingValue(sh.read("settings get global activity_manager_constants"))
                val merged = BoostParsers.mergeConstant(current, "max_cached_processes", limit)
                if (!Safe.isToken(merged)) Outcome(false, "existing constants contain unsafe characters")
                else sh.change("settings put global activity_manager_constants ${Safe.q(merged)}")
            },
            restore = { sh, o ->
                if (o.value == null) sh.change("settings delete global activity_manager_constants")
                else sh.change("settings put global activity_manager_constants ${Safe.q(o.value)}")
            }
        )
    }

    /** Battery "Unrestricted", part 1: Doze / battery-optimisation allowlist. */
    private fun deviceIdle(pkg: String): Tweak = Tweak(
        id = "idle_whitelist:$pkg",
        verifiable = true,
        read = { sh ->
            val r = sh.run("cmd deviceidle whitelist")
            if (!r.isSuccess) null
            else Original(BoostParsers.isDeviceIdleWhitelisted(r.stdout, pkg).toString())
        },
        apply = { sh -> sh.change("cmd deviceidle whitelist +$pkg") },
        restore = { sh, o ->
            if (o.value == "true") Outcome(true, "was already allowlisted, left as is")
            else sh.change("cmd deviceidle whitelist -$pkg")
        }
    )

    /** Battery "Unrestricted", part 2: appops for the target game. */
    private fun appOp(pkg: String, op: String): Tweak = Tweak(
        id = "appop:$pkg:$op",
        verifiable = true,
        read = { sh ->
            val r = sh.run("cmd appops get $pkg $op")
            if (!r.isSuccess || r.stdout.contains("Unknown", ignoreCase = true)) null else {
                val m = BoostParsers.appOpMode(r.stdout, op)
                when {
                    m == null -> Original("default", assumed = true)
                    m in APPOP_MODES -> Original(m)
                    else -> Original("default", assumed = true)
                }
            }
        },
        apply = { sh -> sh.change("cmd appops set $pkg $op allow") },
        restore = { sh, o -> sh.change("cmd appops set $pkg $op ${o.value ?: "default"}") }
    )

    /** Do Not Disturb = "priority only", so alarms and starred contacts still get through. */
    private fun doNotDisturb(): Tweak = Tweak(
        id = "dnd",
        verifiable = true,
        read = { sh ->
            val r = sh.run("settings get global zen_mode")
            if (!r.isSuccess) null else {
                val v = BoostParsers.settingValue(r.stdout) ?: "0"
                if (v in ZEN_TO_CMD) Original(v) else null
            }
        },
        apply = { sh ->
            val viaCmd = sh.change("cmd notification set_dnd priority")
            if (viaCmd.ok) viaCmd else sh.change("settings put global zen_mode 1")
        },
        restore = { sh, o ->
            val zen = o.value ?: "0"
            val viaCmd = sh.change("cmd notification set_dnd ${ZEN_TO_CMD[zen] ?: "off"}")
            if (viaCmd.ok) viaCmd else sh.change("settings put global zen_mode $zen")
        }
    )

    private fun trimCaches(): Action = Action("trim_caches", "trim_caches") { sh ->
        // Asks the system to free "1024G": it deletes the caches of every app.
        sh.change("pm trim-caches 1024G", timeoutMs = 120_000L)
    }

    private fun killAll(): Action = Action("kill_all", "kill_all") { sh ->
        sh.change("am kill-all")
    }

    /** `pm compile -m <speed|everything> -f <pkg>`. Slow (up to minutes). Restored to the old filter. */
    private fun compile(pkg: String, filter: CompileFilter): Tweak = Tweak(
        id = "compile:$pkg",
        verifiable = false, // re-compiling to the same filter is not guaranteed to be byte-identical
        read = { sh ->
            val r = sh.run("dumpsys package $pkg", 30_000L)
            if (!r.isSuccess) null else {
                val s = BoostParsers.compileStatus(r.stdout)
                if (s != null && s in COMPILE_FILTERS) Original(s) else Original("reset", assumed = true)
            }
        },
        apply = { sh -> sh.change("pm compile -m ${filter.value} -f $pkg", timeoutMs = COMPILE_TIMEOUT_MS) },
        restore = { sh, o ->
            val v = o.value ?: "reset"
            if (v == "reset") sh.change("pm compile --reset $pkg", timeoutMs = COMPILE_TIMEOUT_MS)
            else {
                val r = sh.change("pm compile -m $v -f $pkg", timeoutMs = COMPILE_TIMEOUT_MS)
                if (r.ok) r else sh.change("pm compile --reset $pkg", timeoutMs = COMPILE_TIMEOUT_MS)
            }
        }
    )

    /** Developer option "Disable HW overlays" (SurfaceFlinger transaction 1008). Not reboot-persistent. */
    private fun hwOverlays(): Tweak = Tweak(
        id = "hw_overlays",
        verifiable = false, // no read-back for the live state
        read = { sh ->
            val v = sh.read("getprop debug.sf.hw").orEmpty()
            if (v == "1") Original("1") else Original("0", assumed = v.isEmpty())
        },
        apply = { sh -> sh.change("service call SurfaceFlinger 1008 i32 1") },
        restore = { sh, o -> sh.change("service call SurfaceFlinger 1008 i32 ${if (o.value == "1") 1 else 0}") }
    )

    /** Developer option "Force GPU rendering" (persist.sys.ui.hw). Read back, because the OS may refuse. */
    private fun gpuRendering(): Tweak = Tweak(
        id = "gpu_rendering",
        verifiable = true,
        read = { sh ->
            val v = sh.read("getprop persist.sys.ui.hw")
            if (v == null) null
            else if (v.isNotEmpty() && !Safe.isToken(v)) null
            else Original(v.ifEmpty { null })
        },
        apply = { sh ->
            val set = sh.change("setprop persist.sys.ui.hw true")
            if (!set.ok) set
            else if (sh.read("getprop persist.sys.ui.hw") == "true") set
            else Outcome(false, "the OS refused to change persist.sys.ui.hw on this device")
        },
        restore = { sh, o -> sh.change("setprop persist.sys.ui.hw ${Safe.q(o.value ?: "")}") }
    )

    private const val COMPILE_TIMEOUT_MS = 20 * 60_000L
    private val GAME_MODES = setOf("standard", "performance", "battery", "custom")
    private val APPOP_MODES = setOf("allow", "ignore", "deny", "default", "foreground")
    private val COMPILE_FILTERS = setOf(
        "verify", "speed-profile", "speed", "everything", "everything-profile", "space", "space-profile", "quicken"
    )
    private val ZEN_TO_CMD = mapOf("0" to "off", "1" to "priority", "2" to "none", "3" to "alarms")
}
