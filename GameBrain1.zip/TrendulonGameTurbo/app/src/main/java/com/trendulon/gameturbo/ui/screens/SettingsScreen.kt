package com.trendulon.gameturbo.ui.screens

import android.content.ComponentName
import android.content.Context
import android.graphics.drawable.Icon
import android.os.Build
import android.app.StatusBarManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon as MaterialIcon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.trendulon.gameturbo.R
import com.trendulon.gameturbo.automation.PermissionHelper
import com.trendulon.gameturbo.automation.ThemeMode
import com.trendulon.gameturbo.automation.TurboGraph
import com.trendulon.gameturbo.killer.KillerConfig
import com.trendulon.gameturbo.services.AutomationService
import com.trendulon.gameturbo.services.BoostTileService
import com.trendulon.gameturbo.ui.components.AppIcon
import com.trendulon.gameturbo.ui.components.BannerKind
import com.trendulon.gameturbo.ui.components.Banner
import com.trendulon.gameturbo.ui.components.ButtonStyle
import com.trendulon.gameturbo.ui.components.EmptyState
import com.trendulon.gameturbo.ui.components.MaximumWarningDialog
import com.trendulon.gameturbo.ui.components.ScreenTitle
import com.trendulon.gameturbo.ui.components.SectionLabel
import com.trendulon.gameturbo.ui.components.SettingNavRow
import com.trendulon.gameturbo.ui.components.SettingSwitchRow
import com.trendulon.gameturbo.ui.components.TCard
import com.trendulon.gameturbo.ui.components.TurboButton
import com.trendulon.gameturbo.ui.theme.TurboColors

private enum class SettingsPage { Main, Whitelist, Picker }

@Composable
fun SettingsScreen(turbo: TurboGraph, onMessage: (String) -> Unit, onShowGuide: () -> Unit) {
    var page by rememberSaveable { mutableStateOf(SettingsPage.Main) }
    when (page) {
        SettingsPage.Main -> SettingsMain(
            turbo, onMessage, onShowGuide, onOpenWhitelist = { page = SettingsPage.Whitelist }
        )
        SettingsPage.Whitelist -> WhitelistScreen(
            turbo, onBack = { page = SettingsPage.Main }, onAdd = { page = SettingsPage.Picker }
        )
        SettingsPage.Picker -> AppPickerScreen(
            turbo, "Protect an app",
            alreadyAdded = turbo.core.whitelistStore.whitelist.collectAsState().value,
            startWithGames = false,
            onBack = { page = SettingsPage.Whitelist },
            onPick = { app ->
                turbo.core.whitelistStore.add(app.packageName)
                onMessage("${app.label} will never be closed")
                page = SettingsPage.Whitelist
            }
        )
    }
}

@Composable
private fun SettingsMain(
    turbo: TurboGraph,
    onMessage: (String) -> Unit,
    onShowGuide: () -> Unit,
    onOpenWhitelist: () -> Unit
) {
    val context = LocalContext.current
    val settings by turbo.settings.state.collectAsState()
    val killer by turbo.core.killerConfigStore.config.collectAsState()
    val whitelist by turbo.core.whitelistStore.whitelist.collectAsState()
    val tick = rememberPermissionTick()
    var showMaxAuto by remember { mutableStateOf(false) }

    @Suppress("UNUSED_VARIABLE") val recheck = tick.intValue
    val usageOk = PermissionHelper.hasUsageAccess(context)
    val overlayOk = PermissionHelper.hasOverlay(context)
    val shizukuOk = turbo.core.shizukuManager.isConnected

    if (showMaxAuto) {
        MaximumWarningDialog(
            confirmLabel = "Allow automatically",
            onConfirm = {
                turbo.settings.update { it.copy(allowAutoMaximum = true) }
                showMaxAuto = false
            },
            onDismiss = { showMaxAuto = false }
        )
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { ScreenTitle("Settings") }

        // ---- automation ----
        item {
            TCard {
                SectionLabel("Automation")
                SettingSwitchRow(
                    "Auto-detect games",
                    "Boost automatically when a game on your list opens.",
                    settings.autoDetect,
                    { on ->
                        turbo.settings.update { it.copy(autoDetect = on) }
                        AutomationService.sync(context)
                        if (on && !usageOk && !shizukuOk) {
                            onMessage("Grant Usage access below so Game Turbo can see your game.")
                        }
                    }
                )
                if (settings.autoDetect && !usageOk) {
                    Banner(
                        BannerKind.Warning, "Usage access recommended",
                        if (shizukuOk) "Using Shizuku to look for your game (slower). Grant Usage access below for best results."
                        else "Without it, Game Turbo can't see which app is open."
                    )
                    Spacer(Modifier.height(6.dp))
                }
                SettingSwitchRow(
                    "Auto-restore when the game closes",
                    "Goes back to normal when you leave the game for more than a few seconds.",
                    settings.autoRestore && !settings.keepBoostUntilManual,
                    { on -> turbo.settings.update { it.copy(autoRestore = on) }; AutomationService.sync(context) },
                    enabled = !settings.keepBoostUntilManual
                )
                SettingSwitchRow(
                    "Keep boost until I turn it off",
                    "Never restore automatically.",
                    settings.keepBoostUntilManual,
                    { on -> turbo.settings.update { it.copy(keepBoostUntilManual = on) } }
                )
                if (settings.autoRestore && !settings.keepBoostUntilManual) {
                    Spacer(Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Restore delay", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                        Text("${settings.restoreDelaySeconds}s", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = settings.restoreDelaySeconds.toFloat(),
                        onValueChange = { v -> turbo.settings.update { it.copy(restoreDelaySeconds = v.toInt()) } },
                        valueRange = 3f..30f, steps = 26, colors = orangeSlider()
                    )
                    Text(
                        "A short delay stops a quick app switch or notification from undoing your boost.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                SettingSwitchRow(
                    "Start Maximum automatically",
                    "Off by default. Auto-detected games use Performance instead of Maximum.",
                    settings.allowAutoMaximum,
                    { on -> if (on) showMaxAuto = true else turbo.settings.update { it.copy(allowAutoMaximum = false) } }
                )
            }
        }

        // ---- killer ----
        item {
            TCard {
                SectionLabel("App closing")
                SettingSwitchRow(
                    "Keep closing apps while boosting",
                    "Re-checks and closes apps that restart themselves.",
                    killer.continuousEnabled,
                    { on -> turbo.core.killerConfigStore.setContinuous(on) }
                )
                if (killer.continuousEnabled) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Check every", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                        Text("${killer.safeIntervalSeconds}s", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = killer.safeIntervalSeconds.toFloat(),
                        onValueChange = { turbo.core.killerConfigStore.setIntervalSeconds(it.toInt()) },
                        valueRange = KillerConfig.MIN_INTERVAL_SECONDS.toFloat()..KillerConfig.MAX_INTERVAL_SECONDS.toFloat(),
                        steps = KillerConfig.MAX_INTERVAL_SECONDS - KillerConfig.MIN_INTERVAL_SECONDS - 1,
                        colors = orangeSlider()
                    )
                }
                SettingNavRow(
                    "Whitelist",
                    if (whitelist.isEmpty()) "Apps that are never closed" else "${whitelist.size} app(s) are never closed",
                    onOpenWhitelist
                )
            }
        }

        // ---- safety ----
        item {
            TCard {
                SectionLabel("Safety")
                SettingSwitchRow(
                    "Heat warning",
                    "Warns you while boosting if the phone gets hot.",
                    settings.temperatureWarning,
                    { on -> turbo.settings.update { it.copy(temperatureWarning = on) } }
                )
                if (settings.temperatureWarning) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Warn at", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                        Text("${settings.temperatureLimitC}°C", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = settings.temperatureLimitC.toFloat(),
                        onValueChange = { v -> turbo.settings.update { it.copy(temperatureLimitC = v.toInt()) } },
                        valueRange = 38f..50f, steps = 11, colors = orangeSlider()
                    )
                    Text(
                        "Uses the battery temperature, the one reading every phone shares.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // ---- extras ----
        item {
            TCard {
                SectionLabel("Shortcuts")
                SettingSwitchRow(
                    "Floating boost button",
                    if (overlayOk) "A small bolt over your game. Tap to boost or restore. Drag to move."
                    else "Needs \"Display over other apps\". Grant it below.",
                    settings.floatingButton,
                    { on ->
                        if (on && !overlayOk) {
                            onMessage("Grant \"Display over other apps\" first (Permissions below).")
                        } else {
                            turbo.settings.update { it.copy(floatingButton = on) }
                            AutomationService.sync(context)
                        }
                    }
                )
                Spacer(Modifier.height(6.dp))
                Text("Quick Settings tile", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Text(
                    "Pull down your notification shade, tap the pencil, and drag \"Game Turbo\" into your tiles.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (Build.VERSION.SDK_INT >= 33) {
                    Spacer(Modifier.height(10.dp))
                    TurboButton(
                        "Add tile now", { requestTile(context, onMessage) },
                        Modifier.fillMaxWidth(), style = ButtonStyle.Ghost
                    )
                }
            }
        }

        // ---- permissions ----
        item {
            TCard {
                SectionLabel("Permissions")
                Spacer(Modifier.height(4.dp))
                PermissionsPanel(turbo, onMessage)
            }
        }

        // ---- appearance ----
        item {
            TCard {
                SectionLabel("Appearance")
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(ThemeMode.DARK to "Dark", ThemeMode.LIGHT to "Light", ThemeMode.SYSTEM to "System").forEach { (mode, label) ->
                        FilterChip(
                            selected = settings.themeMode == mode,
                            onClick = { turbo.settings.update { it.copy(themeMode = mode) } },
                            label = { Text(label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = TurboColors.Orange.copy(alpha = 0.18f),
                                selectedLabelColor = TurboColors.Orange
                            )
                        )
                    }
                }
            }
        }

        // ---- help + emergency ----
        item {
            TCard {
                SectionLabel("Help")
                SettingNavRow("Setup guide", "How Shizuku and the permissions work", onShowGuide)
            }
        }
        item {
            TCard(borderColor = TurboColors.Red.copy(alpha = 0.35f)) {
                Text("Emergency", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Stops everything and puts every changed setting back.",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(12.dp))
                TurboButton(
                    "Restore Everything", { turbo.coordinator.restoreEverything() }, Modifier.fillMaxWidth(),
                    icon = Icons.Rounded.RestartAlt, style = ButtonStyle.Danger
                )
            }
        }
        item {
            Text(
                "TRENDULON Game Turbo", Modifier.fillMaxWidth(),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun orangeSlider() = SliderDefaults.colors(
    thumbColor = TurboColors.Orange,
    activeTrackColor = TurboColors.Orange,
    inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant
)

private fun requestTile(context: Context, onMessage: (String) -> Unit) {
    if (Build.VERSION.SDK_INT < 33) return
    runCatching {
        val manager = context.getSystemService(StatusBarManager::class.java)
        manager.requestAddTileService(
            ComponentName(context, BoostTileService::class.java),
            context.getString(R.string.tile_label),
            Icon.createWithResource(context, R.drawable.ic_bolt),
            ContextCompat.getMainExecutor(context)
        ) { result ->
            onMessage(
                if (result == StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ADDED ||
                    result == StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ALREADY_ADDED
                ) "Tile added" else "Tile wasn't added. You can add it from the shade's edit menu."
            )
        }
    }.onFailure { onMessage("Add it from the notification shade's edit menu.") }
}

@Composable
private fun WhitelistScreen(turbo: TurboGraph, onBack: () -> Unit, onAdd: () -> Unit) {
    BackHandler(onBack = onBack)
    val whitelist by turbo.core.whitelistStore.whitelist.collectAsState()
    val context = LocalContext.current
    val sorted = remember(whitelist) { whitelist.sorted() }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { MaterialIcon(Icons.Rounded.ArrowBack, "Back") }
                Text("Whitelist", style = MaterialTheme.typography.titleLarge)
            }
        }
        item {
            Banner(
                BannerKind.Info, "Always protected",
                "System apps, your keyboard, launcher, phone and SMS apps, accessibility services, Shizuku and Game Turbo are never closed. Add anything else you want to keep running (chat, banking, music)."
            )
        }
        item { TurboButton("Protect an app", onAdd, Modifier.fillMaxWidth(), icon = Icons.Rounded.Add) }
        if (sorted.isEmpty()) {
            item { EmptyState("Nothing here yet", "Apps you add will survive every boost.") }
        }
        items(sorted, key = { it }) { pkg ->
            val label = remember(pkg) {
                runCatching {
                    val pm = context.packageManager
                    pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                }.getOrDefault(pkg)
            }
            TCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(pkg, size = 44.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(label, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        Text(
                            pkg, style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1
                        )
                    }
                    IconButton(onClick = { turbo.core.whitelistStore.remove(pkg) }) {
                        MaterialIcon(Icons.Rounded.Close, "Remove")
                    }
                }
            }
        }
    }
}
