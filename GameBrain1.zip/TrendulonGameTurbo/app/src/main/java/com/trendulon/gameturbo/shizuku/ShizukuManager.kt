package com.trendulon.gameturbo.shizuku

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.util.Log
import com.trendulon.gameturbo.BuildConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import rikka.shizuku.Shizuku

/**
 * Single entry point for everything Shizuku:
 *  - live [status] (Connected / Disconnected / NotAuthorized) and [mode] (ADB / ROOT)
 *  - [connect] (what the "Connect to Shizuku" button should call)
 *  - permission request handling
 *  - binder death handling + automatic reconnect watchdog
 *  - [exec] to run privileged shell commands
 *
 * UI-free on purpose. Create it once (see AppGraph) and call [start] early.
 */
class ShizukuManager(
    context: Context,
    private val scope: CoroutineScope
) {
    private val appContext = context.applicationContext

    private val _status = MutableStateFlow(ShizukuStatus.Disconnected)
    /** Observe this from the UI. Updated on binder events and by the watchdog. */
    val status: StateFlow<ShizukuStatus> = _status.asStateFlow()

    private val _mode = MutableStateFlow(ShizukuMode.UNKNOWN)
    /** ADB or ROOT. UNKNOWN while disconnected. */
    val mode: StateFlow<ShizukuMode> = _mode.asStateFlow()

    val isConnected: Boolean get() = _status.value == ShizukuStatus.Connected

    /** When true (default) the watchdog keeps re-checking Shizuku and re-binds after it dies. */
    @Volatile
    var autoReconnect: Boolean = true

    @Volatile private var shellService: IShellService? = null
    @Volatile private var pendingBind: CompletableDeferred<IShellService>? = null
    @Volatile private var bindStartedAt = 0L
    private val serviceMutex = Mutex()
    private var started = false
    private var watchdogJob: Job? = null

    // ---- Shizuku listeners -------------------------------------------------------------------

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        Log.d(TAG, "Shizuku binder received")
        refreshStatus()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        Log.w(TAG, "Shizuku binder died")
        dropService()
        refreshStatus()
    }

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { _, grantResult ->
            Log.d(TAG, "Shizuku permission result: $grantResult")
            refreshStatus()
        }

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            if (!binder.pingBinder()) return
            val service = IShellService.Stub.asInterface(binder)
            shellService = service
            pendingBind?.complete(service)
            Log.d(TAG, "Shell user service connected")
        }

        override fun onServiceDisconnected(name: ComponentName) {
            Log.w(TAG, "Shell user service disconnected")
            shellService = null
        }
    }

    private val userServiceArgs by lazy {
        Shizuku.UserServiceArgs(ComponentName(appContext.packageName, ShellUserService::class.java.name))
            .processNameSuffix("shell")
            .daemon(false)
            .debuggable(BuildConfig.DEBUG)
            .version(BuildConfig.VERSION_CODE)
    }

    // ---- Lifecycle ---------------------------------------------------------------------------

    /** Registers listeners and starts the watchdog. Safe to call more than once. */
    @Synchronized
    fun start() {
        if (started) return
        started = true
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Shizuku.addRequestPermissionResultListener(permissionResultListener)
        refreshStatus()
        watchdogJob = scope.launch {
            while (isActive) {
                delay(if (isConnected) WATCHDOG_CONNECTED_MS else WATCHDOG_DISCONNECTED_MS)
                if (autoReconnect) refreshStatus()
            }
        }
    }

    /** Unregisters everything. Only needed if you want to fully shut Shizuku handling down. */
    @Synchronized
    fun stop() {
        if (!started) return
        started = false
        watchdogJob?.cancel()
        watchdogJob = null
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        Shizuku.removeRequestPermissionResultListener(permissionResultListener)
        dropService()
        _status.value = ShizukuStatus.Disconnected
        _mode.value = ShizukuMode.UNKNOWN
    }

    // ---- Public actions ----------------------------------------------------------------------

    /**
     * Call this from the "Connect to Shizuku" button.
     *  - Shizuku not running  -> opens the Shizuku app (the watchdog connects as soon as it starts)
     *  - Not authorized       -> shows the Shizuku permission prompt
     *  - Connected            -> makes sure the shell service is bound
     */
    fun connect() {
        start()
        scope.launch {
            refreshStatus()
            when (_status.value) {
                ShizukuStatus.Disconnected -> openShizukuApp()
                ShizukuStatus.NotAuthorized -> requestPermission()
                ShizukuStatus.Connected -> runCatching { ensureService() }
            }
        }
    }

    /** Asks Shizuku for permission. If the user permanently denied it, opens the Shizuku app instead. */
    fun requestPermission() {
        try {
            if (!Shizuku.pingBinder()) return
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                // User picked "deny and don't ask again": must be re-enabled inside the Shizuku app.
                Log.w(TAG, "Permission permanently denied; opening Shizuku app")
                openShizukuApp()
                return
            }
            Shizuku.requestPermission(REQUEST_CODE_PERMISSION)
        } catch (t: Throwable) {
            Log.w(TAG, "requestPermission failed", t)
        }
    }

    /** True if the Shizuku app is installed (use to show an "Install Shizuku" hint). */
    fun isShizukuAppInstalled(): Boolean =
        appContext.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE) != null

    /** Re-evaluates the state right now (the watchdog also does this periodically). */
    @Synchronized
    fun refreshStatus() {
        val old = _status.value
        val new = computeStatus()
        _mode.value = if (new == ShizukuStatus.Disconnected) ShizukuMode.UNKNOWN else readMode()
        _status.value = new

        if (new != ShizukuStatus.Connected && old == ShizukuStatus.Connected) dropService()
        if (new == ShizukuStatus.Connected && shellService == null && pendingBind == null) {
            scope.launch { runCatching { ensureService() } }
        }
    }

    /**
     * Runs a shell command with Shizuku privileges (`sh -c <command>`).
     * @throws ShizukuNotReadyException when Shizuku is not Connected or the service cannot be bound.
     */
    suspend fun exec(command: String, timeoutMs: Long = DEFAULT_EXEC_TIMEOUT_MS): ShellResult =
        withContext(Dispatchers.IO) {
            var lastError: Throwable? = null
            repeat(2) {
                try {
                    val service = ensureService()
                    return@withContext service.exec(command, timeoutMs)
                } catch (e: ShizukuNotReadyException) {
                    throw e
                } catch (e: TimeoutCancellationException) {
                    lastError = e
                    shellService = null
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    // e.g. DeadObjectException: drop the stale service and retry once.
                    lastError = e
                    shellService = null
                }
            }
            throw ShizukuNotReadyException("Shell service unavailable: $lastError")
        }

    // ---- Internals ---------------------------------------------------------------------------

    private fun computeStatus(): ShizukuStatus {
        return try {
            when {
                !Shizuku.pingBinder() -> ShizukuStatus.Disconnected
                Shizuku.isPreV11() -> ShizukuStatus.Disconnected // too old to support
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED ->
                    ShizukuStatus.Connected
                else -> ShizukuStatus.NotAuthorized
            }
        } catch (t: Throwable) {
            ShizukuStatus.Disconnected
        }
    }

    private fun readMode(): ShizukuMode = try {
        when (Shizuku.getUid()) {
            0 -> ShizukuMode.ROOT
            2000 -> ShizukuMode.ADB
            else -> ShizukuMode.UNKNOWN
        }
    } catch (t: Throwable) {
        ShizukuMode.UNKNOWN
    }

    private suspend fun ensureService(): IShellService = serviceMutex.withLock {
        shellService?.let { if (it.asBinder().pingBinder()) return@withLock it }

        if (_status.value != ShizukuStatus.Connected) {
            throw ShizukuNotReadyException("Shizuku is ${_status.value}")
        }

        // FIX (Dev 3, requested by project owner): on slow phones the shell service needs longer than the
        // timeout to start. Before, every timeout unbound the half-started service and began again, so it
        // never finished. Now a bind that is still starting is kept and awaited again.
        val inFlight = pendingBind
        val deferred = if (inFlight != null && inFlight.isActive &&
            System.currentTimeMillis() - bindStartedAt < BIND_GIVE_UP_MS
        ) {
            inFlight
        } else {
            runCatching { Shizuku.unbindUserService(userServiceArgs, serviceConnection, true) }
            shellService = null
            CompletableDeferred<IShellService>().also {
                pendingBind = it
                bindStartedAt = System.currentTimeMillis()
                Shizuku.bindUserService(userServiceArgs, serviceConnection)
            }
        }
        val service = withTimeout(BIND_TIMEOUT_MS) { deferred.await() } // on timeout the bind stays in flight
        if (pendingBind === deferred) pendingBind = null
        service
    }

    private fun dropService() {
        shellService = null
        pendingBind?.cancel()
        pendingBind = null
        runCatching { Shizuku.unbindUserService(userServiceArgs, serviceConnection, true) }
    }

    private fun openShizukuApp() {
        val intent = appContext.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE)
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) ?: return
        runCatching { appContext.startActivity(intent) }
    }

    companion object {
        const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
        const val DEFAULT_EXEC_TIMEOUT_MS = 15_000L
        private const val TAG = "ShizukuManager"
        private const val REQUEST_CODE_PERMISSION = 7001
        private const val BIND_TIMEOUT_MS = 20_000L
        private const val BIND_GIVE_UP_MS = 60_000L
        private const val WATCHDOG_CONNECTED_MS = 5_000L
        private const val WATCHDOG_DISCONNECTED_MS = 2_000L
    }
}
