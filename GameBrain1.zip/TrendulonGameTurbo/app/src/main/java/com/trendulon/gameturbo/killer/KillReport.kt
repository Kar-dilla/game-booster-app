package com.trendulon.gameturbo.killer

/** Outcome of one kill pass. */
data class KillReport(
    /** Packages that were force-stopped successfully. */
    val killed: List<String> = emptyList(),
    /** Packages whose force-stop command failed. */
    val failed: List<String> = emptyList(),
    /** Packages that still had a running process after the retry. */
    val survivors: List<String> = emptyList(),
    /** Number of user apps that were skipped because they are protected / whitelisted / targets. */
    val skippedProtected: Int = 0,
    val durationMs: Long = 0,
    /** Non-null if the whole pass could not run (e.g. Shizuku not connected). */
    val error: String? = null
) {
    val ok: Boolean get() = error == null
    val killedCount: Int get() = killed.size
}
