package com.trendulon.gameturbo

import android.content.Context
import com.trendulon.gameturbo.apps.InstalledAppsRepository
import com.trendulon.gameturbo.boost.BoostController
import com.trendulon.gameturbo.boost.engine.BoostEngine
import com.trendulon.gameturbo.boost.engine.GameBoost
import com.trendulon.gameturbo.boost.engine.ShellExecutor
import com.trendulon.gameturbo.killer.KillerConfigStore
import com.trendulon.gameturbo.killer.ProcessKiller
import com.trendulon.gameturbo.killer.ProtectedPackagesResolver
import com.trendulon.gameturbo.killer.WhitelistStore
import com.trendulon.gameturbo.profiles.ProfileStore
import com.trendulon.gameturbo.shizuku.ShellResult
import com.trendulon.gameturbo.shizuku.ShizukuManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/**
 * Tiny manual dependency container (no DI framework). Get it with:
 *   (application as TrendulonApp).graph
 */
class AppGraph(context: Context) {
    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val shizukuManager = ShizukuManager(appContext, scope)
    val whitelistStore = WhitelistStore(appContext)
    val killerConfigStore = KillerConfigStore(appContext)
    val profileStore = ProfileStore(appContext)
    val installedApps = InstalledAppsRepository(appContext)

    val processKiller = ProcessKiller(
        shizuku = shizukuManager,
        whitelist = whitelistStore,
        protectedResolver = ProtectedPackagesResolver(appContext)
    )

    val boostController = BoostController(processKiller, killerConfigStore, scope)

    // ---- Dev 2: Boost Engine (added on top, nothing above was changed) ----
    val boostEngine = BoostEngine(
        appContext,
        object : ShellExecutor {
            override suspend fun exec(command: String, timeoutMs: Long): ShellResult =
                shizukuManager.exec(command, timeoutMs)
        }
    )

    /** Engine + Process Killer behind one start/stop. Optional; use boostEngine directly if you prefer. */
    val gameBoost = GameBoost(boostEngine, boostController)
}
