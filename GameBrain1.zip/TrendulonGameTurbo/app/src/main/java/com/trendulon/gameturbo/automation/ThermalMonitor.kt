package com.trendulon.gameturbo.automation

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * @param batteryC battery temperature in °C (the one temperature every phone exposes without root)
 * @param thermalStatus Android thermal status (0 none ... 3 severe ... 6 shutdown); API 29+, else 0
 */
data class ThermalReading(val batteryC: Float? = null, val thermalStatus: Int = 0)

/** Passive temperature watcher (battery sensor + system thermal status). */
class ThermalMonitor(context: Context) {
    private val appContext = context.applicationContext
    private val _reading = MutableStateFlow(ThermalReading())
    val reading: StateFlow<ThermalReading> = _reading.asStateFlow()

    private var started = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = publish(intent)
    }

    @Synchronized
    fun start() {
        if (started) return
        started = true
        runCatching {
            val sticky = ContextCompat.registerReceiver(
                appContext, receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
            sticky?.let(::publish)
        }
    }

    private fun publish(intent: Intent) {
        val raw = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val celsius = if (raw == Int.MIN_VALUE) null else raw / 10f
        val status = if (Build.VERSION.SDK_INT >= 29) {
            runCatching { appContext.getSystemService(PowerManager::class.java)?.currentThermalStatus ?: 0 }
                .getOrDefault(0)
        } else 0
        _reading.value = ThermalReading(celsius, status)
    }
}
