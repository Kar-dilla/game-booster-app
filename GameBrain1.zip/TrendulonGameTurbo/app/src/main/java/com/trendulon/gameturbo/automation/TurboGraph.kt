package com.trendulon.gameturbo.automation

import android.app.Application
import android.content.Context
import com.trendulon.gameturbo.AppGraph
import com.trendulon.gameturbo.TrendulonApp
import com.trendulon.gameturbo.profiles.TargetProfile

/**
 * Dev 3's container, built on top of Dev 1/2's [AppGraph]. Nothing in the core graph is modified.
 *   val turbo = Turbo.of(context)
 */
class TurboGraph(app: Application) {
    val core: AppGraph = (app as TrendulonApp).graph
    val settings = SettingsStore(app)
    val log = ActionLog(app)
    val thermal = ThermalMonitor(app).also { it.start() }
    val notifier = Notifier(app)
    val coordinator = BoostCoordinator(app, core, settings, log, thermal, notifier)
    val watcher = ForegroundWatcher(app, core.shizukuManager)
    val autoPilot = AutoPilot(app, core, settings, coordinator, watcher)

    fun selectedProfile(): TargetProfile? = coordinator.defaultProfile()
}

object Turbo {
    @Volatile
    private var instance: TurboGraph? = null

    fun of(context: Context): TurboGraph =
        instance ?: synchronized(this) {
            instance ?: TurboGraph(context.applicationContext as Application).also { instance = it }
        }
}
