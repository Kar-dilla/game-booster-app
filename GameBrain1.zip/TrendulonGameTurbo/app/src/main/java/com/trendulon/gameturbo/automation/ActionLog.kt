package com.trendulon.gameturbo.automation

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

enum class LogLevel { INFO, SUCCESS, WARNING, ERROR }

data class LogEntry(
    val time: Long,
    val level: LogLevel,
    val title: String,
    val detail: String = ""
)

/** Persistent history of what the app did (newest first, capped). Shown on the Log tab. */
class ActionLog(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("trendulon_action_log", Context.MODE_PRIVATE)

    private val _entries = MutableStateFlow(load())
    val entries: StateFlow<List<LogEntry>> = _entries.asStateFlow()

    @Synchronized
    fun add(level: LogLevel, title: String, detail: String = "") {
        val list = (listOf(LogEntry(System.currentTimeMillis(), level, title, detail)) + _entries.value)
            .take(MAX_ENTRIES)
        _entries.value = list
        persist(list)
    }

    @Synchronized
    fun clear() {
        _entries.value = emptyList()
        persist(emptyList())
    }

    private fun persist(list: List<LogEntry>) {
        val array = JSONArray()
        list.forEach {
            array.put(
                JSONObject()
                    .put("t", it.time)
                    .put("l", it.level.name)
                    .put("title", it.title)
                    .put("detail", it.detail)
            )
        }
        prefs.edit().putString(KEY, array.toString()).apply()
    }

    private fun load(): List<LogEntry> {
        val json = prefs.getString(KEY, null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(json)
            (0 until array.length()).map { i ->
                val o = array.getJSONObject(i)
                LogEntry(
                    time = o.optLong("t"),
                    level = runCatching { LogLevel.valueOf(o.optString("l")) }.getOrDefault(LogLevel.INFO),
                    title = o.optString("title"),
                    detail = o.optString("detail")
                )
            }
        }.getOrDefault(emptyList())
    }

    private companion object {
        const val KEY = "entries"
        const val MAX_ENTRIES = 200
    }
}
