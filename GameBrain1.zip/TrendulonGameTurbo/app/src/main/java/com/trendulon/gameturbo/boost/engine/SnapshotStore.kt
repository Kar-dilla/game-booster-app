package com.trendulon.gameturbo.boost.engine

import android.content.Context
import com.trendulon.gameturbo.profiles.BoostMode
import org.json.JSONArray
import org.json.JSONObject

/** One saved original. [value] null means "the key was not set" (restore = delete it). */
internal data class Original(val value: String?, val assumed: Boolean = false)

/**
 * What the device looked like BEFORE the boost. Written to disk before the first change is made,
 * so a restore still works after the app is killed or the phone reboots mid-boost.
 *
 * [entries] keeps capture order (= apply order); restore walks it backwards.
 */
internal class Snapshot(
    val entries: LinkedHashMap<String, Original> = LinkedHashMap(),
    val packages: LinkedHashSet<String> = LinkedHashSet(),
    var mode: BoostMode? = null,
    /** Irreversible actions that ran (cache wipe, kill-all). Informational only. */
    val irreversible: LinkedHashSet<String> = LinkedHashSet()
) {
    val isEmpty: Boolean get() = entries.isEmpty() && packages.isEmpty()
}

internal class SnapshotStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("trendulon_boost_snapshot", Context.MODE_PRIVATE)

    @Synchronized
    fun load(): Snapshot? {
        val json = prefs.getString(KEY, null) ?: return null
        return runCatching {
            val root = JSONObject(json)
            val snap = Snapshot()
            root.optString("mode").takeIf { it.isNotEmpty() }?.let {
                snap.mode = runCatching { BoostMode.valueOf(it) }.getOrNull()
            }
            root.optJSONArray("packages")?.let { a ->
                for (i in 0 until a.length()) snap.packages += a.getString(i)
            }
            root.optJSONArray("irreversible")?.let { a ->
                for (i in 0 until a.length()) snap.irreversible += a.getString(i)
            }
            root.optJSONArray("entries")?.let { a ->
                for (i in 0 until a.length()) {
                    val e = a.getJSONObject(i)
                    snap.entries[e.getString("id")] = Original(
                        value = if (e.isNull("v")) null else e.getString("v"),
                        assumed = e.optBoolean("a", false)
                    )
                }
            }
            snap
        }.getOrNull()
    }

    /** Synchronous (commit) on purpose: the snapshot must be on disk before any change is made. */
    @Synchronized
    fun save(snapshot: Snapshot): Boolean {
        if (snapshot.isEmpty) return clear()
        val entries = JSONArray()
        snapshot.entries.forEach { (id, o) ->
            entries.put(
                JSONObject()
                    .put("id", id)
                    .put("v", o.value ?: JSONObject.NULL)
                    .put("a", o.assumed)
            )
        }
        val root = JSONObject()
            .put("mode", snapshot.mode?.name ?: "")
            .put("packages", JSONArray(snapshot.packages.toList()))
            .put("irreversible", JSONArray(snapshot.irreversible.toList()))
            .put("entries", entries)
        return prefs.edit().putString(KEY, root.toString()).commit()
    }

    @Synchronized
    fun clear(): Boolean = prefs.edit().remove(KEY).commit()

    private companion object {
        const val KEY = "snapshot_json"
    }
}
