package com.trendulon.gameturbo.automation

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.PowerManager
import com.trendulon.gameturbo.shizuku.ShizukuManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive

/**
 * Emits the package currently in the foreground. `null` means "unknown / screen off" and must be ignored.
 *
 * Primary source: Usage Access events (cheap, no shell). Usage Access can be granted with one tap
 * through Shizuku. Fallback when it is not granted: `dumpsys` through Shizuku.
 */
class ForegroundWatcher(
    private val context: Context,
    private val shizuku: ShizukuManager
) {
    private val usage = context.getSystemService(UsageStatsManager::class.java)
    private val power = context.getSystemService(PowerManager::class.java)

    private var current: String? = null
    private var lastQuery = 0L

    fun foreground(intervalMs: Long = 1500L): Flow<String?> = flow {
        while (currentCoroutineContext().isActive) {
            emit(runCatching { poll() }.getOrNull())
            delay(intervalMs)
        }
    }.distinctUntilChanged().flowOn(Dispatchers.Default)

    private suspend fun poll(): String? {
        if (power?.isInteractive == false) return null // screen off: not a "game closed" signal
        return when {
            PermissionHelper.hasUsageAccess(context) -> pollUsage()
            shizuku.isConnected -> pollShell()
            else -> null
        }
    }

    @Suppress("DEPRECATION")
    private fun pollUsage(): String? {
        val manager = usage ?: return null
        val now = System.currentTimeMillis()
        val from = if (lastQuery == 0L) now - INITIAL_WINDOW_MS else lastQuery - 1_000L
        val events = manager.queryEvents(from, now)
        val event = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            when (event.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> current = event.packageName
                UsageEvents.Event.MOVE_TO_BACKGROUND -> if (event.packageName == current) current = null
            }
        }
        lastQuery = now
        return current
    }

    private suspend fun pollShell(): String? {
        val result = shizuku.exec(
            "dumpsys activity activities | grep -E 'topResumedActivity|mResumedActivity' | head -n 2", 4_000L
        )
        if (!result.isSuccess) return null
        return RESUMED_REGEX.find(result.stdout)?.groupValues?.get(1)
    }

    private companion object {
        const val INITIAL_WINDOW_MS = 30 * 60_000L
        // ... ActivityRecord{abc u0 com.pkg/.Activity t12}
        val RESUMED_REGEX = Regex("""\bu\d+\s+([A-Za-z0-9_.]+)/""")
    }
}
