package com.trendulon.gameturbo.services

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import com.trendulon.gameturbo.automation.LogLevel
import com.trendulon.gameturbo.automation.Notifier
import com.trendulon.gameturbo.automation.PermissionHelper
import com.trendulon.gameturbo.automation.Phase
import com.trendulon.gameturbo.automation.Turbo
import com.trendulon.gameturbo.automation.TurboGraph
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/**
 * One foreground service for everything that must survive the app being in the background:
 * auto-detect / auto-restore (AutoPilot), the floating button, and the status notification.
 * It runs only while it is needed (auto-detect on, floating button on, or a boost waiting for restore).
 */
class AutomationService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var turbo: TurboGraph
    private var floating: FloatingButton? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        turbo = Turbo.of(this)
        floating = FloatingButton(this, turbo)
        startAsForeground()

        scope.launch(Dispatchers.Default) {
            runCatching { turbo.autoPilot.run() }
        }

        scope.launch {
            combine(turbo.coordinator.ui, turbo.settings.state) { ui, s -> ui to s }.collect { (ui, s) ->
                val name = ui.session?.profile?.name
                val (title, text) = when (val phase = ui.phase) {
                    is Phase.Applying -> "Applying boost" to (name ?: "Please wait")
                    is Phase.Restoring -> "Restoring settings" to "Putting everything back"
                    Phase.Active -> "Boost active${name?.let { " for $it" } ?: ""}" to
                        "${ui.killedCount} apps closed" + if (ui.session?.gameSeen == true) "" else " - waiting for the game"
                    Phase.Idle -> "Game Turbo is ready" to
                        if (s.autoDetect) "Watching for your games" else "Floating button is on"
                }
                turbo.notifier.updateStatus(
                    turbo.notifier.statusNotification(title, text, canRestore = ui.active || ui.working)
                )

                if (s.floatingButton && PermissionHelper.hasOverlay(this@AutomationService)) {
                    floating?.show()
                    floating?.render(ui)
                } else {
                    floating?.hide()
                }

                val needed = s.autoDetect ||
                    (s.floatingButton && PermissionHelper.hasOverlay(this@AutomationService)) ||
                    ui.session != null
                if (!needed) stopSelf()
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        floating?.hide()
        scope.cancel()
        super.onDestroy()
    }

    private fun startAsForeground() {
        val notification = turbo.notifier.statusNotification("Game Turbo is ready", "Starting...", canRestore = false)
        runCatching {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(Notifier.ID_STATUS, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(Notifier.ID_STATUS, notification)
            }
        }.onFailure { stopSelf() }
    }

    companion object {
        /** Start or stop the service to match the current settings and boost state. Safe to call anywhere. */
        fun sync(context: Context) {
            val app = context.applicationContext
            val turbo = Turbo.of(app)
            val s = turbo.settings.value
            val needed = s.autoDetect ||
                (s.floatingButton && PermissionHelper.hasOverlay(app)) ||
                turbo.coordinator.session.value != null
            val intent = Intent(app, AutomationService::class.java)
            if (needed) {
                try {
                    ContextCompat.startForegroundService(app, intent)
                } catch (t: Throwable) {
                    // Android can refuse to start a foreground service from the background.
                    turbo.log.add(
                        LogLevel.WARNING, "Background service couldn't start",
                        "Open the app once and try again. Auto-restore may not run until then."
                    )
                }
            } else {
                app.stopService(intent)
            }
        }
    }
}
