package com.trendulon.gameturbo.automation

import com.trendulon.gameturbo.shizuku.ShizukuStatus

/** Turns technical errors into short messages a gamer can act on. */
object FriendlyErrors {

    fun shizukuNotReady(status: ShizukuStatus, installed: Boolean): String = when (status) {
        ShizukuStatus.Disconnected ->
            if (installed) "Shizuku isn't running. Open Shizuku, start it, then try again."
            else "Shizuku isn't installed. Install it first - the setup guide in Settings shows how."
        ShizukuStatus.NotAuthorized ->
            "Allow Trendulon in Shizuku to continue. Tap Connect on the home screen."
        ShizukuStatus.Connected -> "Shizuku is ready."
    }

    fun fromRaw(raw: String?): String {
        val text = raw?.trim().orEmpty()
        return when {
            text.isEmpty() -> "Something went wrong. Try again."
            text.contains("shizuku", ignoreCase = true) ->
                "Lost the connection to Shizuku. Make sure it's running, then try again."
            text.contains("timeout", ignoreCase = true) || text.contains("timed out", ignoreCase = true) ->
                "That took too long and was stopped. Try again."
            text.contains("permission", ignoreCase = true) ->
                "Android refused a setting change. Your phone's maker may block it - the rest still works."
            else -> text.take(160)
        }
    }

    /** "gpu_rendering" -> "Gpu rendering" */
    fun stepName(id: String): String =
        id.substringBefore(':').replace('_', ' ').replaceFirstChar { it.uppercase() }
}
