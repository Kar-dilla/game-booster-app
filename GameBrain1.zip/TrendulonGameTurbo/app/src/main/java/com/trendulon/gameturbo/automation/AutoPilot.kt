package com.trendulon.gameturbo.automation

import android.content.Context
import android.view.inputmethod.InputMethodManager
import com.trendulon.gameturbo.AppGraph
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * Auto features:
 *  - selected game comes to the foreground  -> boost
 *  - game goes to background / closes       -> restore (after a short grace period)
 * Runs inside [com.trendulon.gameturbo.services.AutomationService].
 */
class AutoPilot(
    private val context: Context,
    private val graph: AppGraph,
    private val settings: SettingsStore,
    private val coordinator: BoostCoordinator,
    private val watcher: ForegroundWatcher
) {
    @OptIn(ExperimentalCoroutinesApi::class)
    suspend fun run() = coroutineScope {
        var restoreJob: Job? = null

        // Only poll while it can matter: auto-detect is on, or a boost is waiting to be auto-restored.
        val needed = kotlinx.coroutines.flow.combine(settings.state, coordinator.session) { s, session ->
            s.autoDetect || (session != null && s.autoRestore && !s.keepBoostUntilManual)
        }.distinctUntilChanged()

        needed.flatMapLatest { on -> if (on) watcher.foreground() else emptyFlow() }
            .collect { pkg ->
                if (pkg == null) return@collect
                val s = settings.value
                val session = coordinator.session.value
                val game = graph.profileStore.profiles.value.firstOrNull { it.packageName == pkg }

                if (game != null) {
                    restoreJob?.cancel()
                    restoreJob = null
                    if (session?.profile?.packageName == pkg) {
                        coordinator.markGameSeen()
                    } else if (s.autoDetect) {
                        coordinator.boost(game, Trigger.AUTO)
                    }
                    return@collect
                }

                // Something else is in front. Only react if a boost is running for a game we have seen.
                if (session == null || !session.gameSeen) return@collect
                if (pkg in neutralPackages()) return@collect
                if (!s.autoRestore || s.keepBoostUntilManual) return@collect
                if (restoreJob?.isActive == true) return@collect

                val gamePkg = session.profile.packageName
                restoreJob = launch {
                    delay(settings.value.restoreDelaySeconds.coerceIn(3, 60) * 1000L)
                    val now = coordinator.session.value
                    if (now != null && now.profile.packageName == gamePkg) {
                        coordinator.restore(Trigger.AUTO)
                    }
                }
            }
    }

    /** Overlays that sit on top of a game without meaning the game was left. */
    private fun neutralPackages(): Set<String> {
        val result = hashSetOf("com.android.systemui")
        runCatching {
            context.getSystemService(InputMethodManager::class.java)
                ?.enabledInputMethodList?.forEach { result += it.packageName }
        }
        return result
    }
}
