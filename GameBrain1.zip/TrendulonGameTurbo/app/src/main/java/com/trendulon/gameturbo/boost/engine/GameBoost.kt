package com.trendulon.gameturbo.boost.engine

import com.trendulon.gameturbo.boost.BoostController
import com.trendulon.gameturbo.profiles.BoostMode
import com.trendulon.gameturbo.profiles.TargetProfile

/**
 * Optional convenience: Dev 2's [BoostEngine] + Dev 1's [BoostController] (process killer) behind
 * one start/stop pair. Nothing in Dev 1's code is changed; this only calls it.
 *
 * start: engine commands first (their last mandatory step is trim-caches + kill-all), then the
 *        Process Killer pass / continuous loop.
 * stop : stop the killer loop first, then restore every saved value.
 */
class GameBoost(
    private val engine: BoostEngine,
    private val controller: BoostController
) {
    suspend fun start(
        packageName: String,
        mode: BoostMode = BoostMode.PERFORMANCE,
        options: BoostOptions = BoostOptions()
    ): BoostReport {
        val report = engine.apply(packageName, mode, options)
        if (report.error == null) controller.boostNow(setOf(packageName))
        return report
    }

    /** Uses the mode saved in the profile. */
    suspend fun start(profile: TargetProfile, options: BoostOptions = BoostOptions()): BoostReport =
        start(profile.packageName, profile.mode, options)

    suspend fun stop(): RestoreReport {
        controller.stopBoost()
        return engine.restore()
    }
}
