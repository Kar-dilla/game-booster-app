package com.trendulon.gameturbo.boost.engine

import com.trendulon.gameturbo.shizuku.ShellResult

/**
 * The only thing the Boost Engine needs from Dev 1's code: "run this shell command with Shizuku
 * privileges". AppGraph adapts `ShizukuManager.exec` to this, so the engine never touches Shizuku
 * internals. May throw `ShizukuNotReadyException` (the engine handles it).
 */
fun interface ShellExecutor {
    suspend fun exec(command: String, timeoutMs: Long): ShellResult
}

internal data class Outcome(val ok: Boolean, val detail: String = "")

/** Thin helper around [ShellExecutor]. */
internal class Sh(private val executor: ShellExecutor) {

    suspend fun run(command: String, timeoutMs: Long = DEFAULT_TIMEOUT_MS): ShellResult =
        executor.exec(command, timeoutMs)

    /** Trimmed stdout, or null when the command failed (non-zero exit). */
    suspend fun read(command: String, timeoutMs: Long = DEFAULT_TIMEOUT_MS): String? {
        val r = run(command, timeoutMs)
        return if (r.isSuccess) r.stdout.trim() else null
    }

    /** Runs a state-changing command; success needs exit 0 AND no error text in the output. */
    suspend fun change(command: String, timeoutMs: Long = DEFAULT_TIMEOUT_MS): Outcome {
        val r = run(command, timeoutMs)
        val text = (r.stderr + "\n" + r.stdout).trim()
        return if (r.isSuccess && !FAILURE_TEXT.containsMatchIn(text)) {
            Outcome(true, text.lineSequence().firstOrNull().orEmpty())
        } else {
            Outcome(false, "exit=${r.exitCode} ${text.take(160)}".trim())
        }
    }

    companion object {
        const val DEFAULT_TIMEOUT_MS = 15_000L
        // cmd/pm/settings print these on failure and sometimes still exit 0.
        private val FAILURE_TEXT = Regex(
            "(?i)(exception|unknown command|permission denial|does not exist|\\berror\\b|\\bfailed\\b)"
        )
    }
}

/** Guards every value that ends up inside a shell command. */
internal object Safe {
    private val TOKEN = Regex("^[A-Za-z0-9._:,=+\\-]*$")

    fun isToken(value: String): Boolean = value.length <= 400 && TOKEN.matches(value)

    /** Single-quoted shell literal. Only call with values that passed [isToken]. */
    fun q(value: String): String = "'$value'"
}
