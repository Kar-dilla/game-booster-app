package com.trendulon.gameturbo.automation

import android.content.Context
import android.os.SystemClock
import com.trendulon.gameturbo.AppGraph
import com.trendulon.gameturbo.boost.engine.BoostEngineState
import com.trendulon.gameturbo.boost.engine.BoostReport
import com.trendulon.gameturbo.profiles.BoostMode
import com.trendulon.gameturbo.profiles.TargetProfile
import com.trendulon.gameturbo.services.AutomationService
import com.trendulon.gameturbo.shizuku.ShizukuStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

enum class Trigger { MANUAL, AUTO, TILE, FLOATING, RECOVERY }

sealed interface Phase {
    object Idle : Phase
    data class Applying(val step: String) : Phase
    object Active : Phase
    data class Restoring(val step: String) : Phase
}

/** What the UI layer knows about the running boost (the engine has no idea who started it). */
data class Session(
    val profile: TargetProfile,
    val trigger: Trigger,
    val startedAt: Long,
    /** The game has been seen in the foreground during this session. Auto-restore only arms after this. */
    val gameSeen: Boolean,
    val report: BoostReport? = null
)

data class TurboUiState(
    val phase: Phase = Phase.Idle,
    val session: Session? = null,
    val killedCount: Int = 0,
    val passes: Int = 0,
    val pendingRestore: Boolean = false,
    val temperatureC: Float? = null,
    val thermalStatus: Int = 0,
    val overheating: Boolean = false
) {
    val active: Boolean get() = phase is Phase.Active
    val working: Boolean get() = phase is Phase.Applying || phase is Phase.Restoring
    val starting: Boolean get() = phase is Phase.Idle && session != null
    val busy: Boolean get() = working || starting
}

/**
 * The single place the UI, the Quick Settings tile, the floating button and auto-detect go through.
 * It only CALLS Dev 1's killer and Dev 2's engine (via [com.trendulon.gameturbo.boost.engine.GameBoost]);
 * it never changes them.
 */
class BoostCoordinator(
    private val context: Context,
    private val graph: AppGraph,
    private val settings: SettingsStore,
    private val log: ActionLog,
    private val thermal: ThermalMonitor,
    private val notifier: Notifier
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val mutex = Mutex()
    private val engine get() = graph.boostEngine

    private val _session = MutableStateFlow<Session?>(null)
    val session: StateFlow<Session?> = _session.asStateFlow()

    private val _pending = MutableStateFlow(runCatching { graph.boostEngine.hasPendingRestore }.getOrDefault(false))

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 8)
    /** One-line, user-friendly messages for a Snackbar. */
    val events: SharedFlow<String> = _events.asSharedFlow()

    val ui: StateFlow<TurboUiState> = combine(
        graph.boostEngine.state,
        graph.boostController.state,
        _session,
        _pending,
        thermal.reading
    ) { engineState, killer, session, pending, heat ->
        val phase = when (engineState) {
            BoostEngineState.Idle -> Phase.Idle
            is BoostEngineState.Applying -> Phase.Applying(engineState.step)
            is BoostEngineState.Active -> Phase.Active
            is BoostEngineState.Restoring -> Phase.Restoring(engineState.step)
        }
        TurboUiState(
            phase = phase,
            session = session,
            killedCount = killer.killedCount,
            passes = killer.passes,
            pendingRestore = pending,
            temperatureC = heat.batteryC,
            thermalStatus = heat.thermalStatus
        )
    }.combine(settings.state) { state, s ->
        val hot = (state.temperatureC ?: 0f) >= s.temperatureLimitC || state.thermalStatus >= THERMAL_SEVERE
        state.copy(overheating = s.temperatureWarning && hot)
    }.stateIn(scope, SharingStarted.Eagerly, TurboUiState())

    private var lastHeatWarning = 0L

    init {
        scope.launch { ui.collect { checkHeat(it) } }
        scope.launch {
            graph.shizukuManager.status.collect { if (it == ShizukuStatus.Connected) recoverIfNeeded() }
        }
    }

    // ---- public API ---------------------------------------------------------------------------

    /** Selected profile (Games tab), else the last one used, else the first saved. */
    fun defaultProfile(): TargetProfile? {
        val store = graph.profileStore
        val profiles = store.profiles.value
        val selected = store.selectedPackages.value
        return profiles.firstOrNull { it.packageName in selected }
            ?: profiles.firstOrNull { it.packageName == settings.value.lastProfilePackage }
            ?: profiles.firstOrNull()
    }

    /** True when starting this profile must first show the Maximum-mode warning. */
    fun requiresMaxConfirmation(profile: TargetProfile, trigger: Trigger): Boolean =
        profile.mode == BoostMode.MAXIMUM && !(trigger == Trigger.AUTO && settings.value.allowAutoMaximum)

    fun boost(profile: TargetProfile, trigger: Trigger = Trigger.MANUAL, maxConfirmed: Boolean = false) {
        scope.launch { doBoost(profile, trigger, maxConfirmed) }
    }

    /** Normal restore (also stops the kill loop). */
    fun restore(trigger: Trigger = Trigger.MANUAL) {
        scope.launch { doRestore(trigger) }
    }

    /** Emergency button: stop everything, retry restore until nothing is pending. */
    fun restoreEverything() {
        scope.launch { doRestoreEverything() }
    }

    fun markGameSeen() {
        _session.update { if (it != null && !it.gameSeen) it.copy(gameSeen = true) else it }
    }

    // ---- boost --------------------------------------------------------------------------------

    private suspend fun doBoost(profile: TargetProfile, trigger: Trigger, maxConfirmed: Boolean) =
        mutex.withLock {
            val shizuku = graph.shizukuManager
            val status = shizuku.status.value
            if (status != ShizukuStatus.Connected) {
                val msg = FriendlyErrors.shizukuNotReady(status, shizuku.isShizukuAppInstalled())
                log.add(LogLevel.ERROR, "Couldn't start boost", msg)
                _events.tryEmit(msg)
                return@withLock
            }

            var mode = profile.mode
            if (mode == BoostMode.MAXIMUM && !maxConfirmed &&
                !(trigger == Trigger.AUTO && settings.value.allowAutoMaximum)
            ) {
                mode = BoostMode.PERFORMANCE
                log.add(
                    LogLevel.WARNING, "Maximum mode needs confirmation",
                    "Started ${profile.name} in Performance instead. Open the app to confirm Maximum."
                )
                _events.tryEmit("Maximum needs your confirmation - using Performance instead.")
            }
            val effective = profile.copy(mode = mode)

            val current = _session.value
            if (engine.state.value is BoostEngineState.Active &&
                current?.profile?.packageName == effective.packageName && current.profile.mode == mode
            ) {
                markGameSeen()
                return@withLock // already boosted exactly like this
            }

            _session.value = Session(
                profile = effective,
                trigger = trigger,
                startedAt = System.currentTimeMillis(),
                gameSeen = trigger == Trigger.AUTO // auto-detect fires because the game IS in the foreground
            )
            log.add(LogLevel.INFO, "Boost started for ${effective.name}", "${mode.label()} mode - ${trigger.label()}")
            syncService()

            val report = try {
                graph.gameBoost.start(effective)
            } catch (t: Throwable) {
                _session.value = null
                val msg = FriendlyErrors.fromRaw(t.message)
                log.add(LogLevel.ERROR, "Boost failed", msg)
                _events.tryEmit(msg)
                syncService()
                return@withLock
            }

            _pending.value = runCatching { engine.hasPendingRestore }.getOrDefault(false)
            if (report.error != null) {
                _session.value = null
                val msg = FriendlyErrors.fromRaw(report.error)
                log.add(LogLevel.ERROR, "Boost failed", msg)
                _events.tryEmit(msg)
                syncService()
                return@withLock
            }

            _session.update { it?.copy(report = report) }
            settings.update { it.copy(lastProfilePackage = profile.packageName) }
            val skipped = report.steps.filter { it.status == com.trendulon.gameturbo.boost.engine.StepStatus.FAILED }
            if (skipped.isEmpty()) {
                log.add(
                    LogLevel.SUCCESS, "Boost active for ${effective.name}",
                    "${report.applied} tweaks applied in ${report.durationMs / 1000}s"
                )
                _events.tryEmit("Boost active for ${effective.name}")
            } else {
                val names = skipped.joinToString { FriendlyErrors.stepName(it.id) }
                log.add(
                    LogLevel.WARNING, "Boost active, ${skipped.size} tweak(s) not supported",
                    "${report.applied} applied. Your phone refused: $names"
                )
                _events.tryEmit("Boost active - ${skipped.size} tweak(s) aren't supported on this phone.")
            }
        }

    // ---- restore ------------------------------------------------------------------------------

    private suspend fun doRestore(trigger: Trigger) = mutex.withLock {
        val shizuku = graph.shizukuManager
        val name = _session.value?.profile?.name
        if (!shizuku.isConnected) {
            graph.boostController.stopBoost()
            val msg = "Can't restore right now - Shizuku is offline. It will restore automatically when Shizuku is back."
            log.add(LogLevel.ERROR, "Restore waiting for Shizuku", msg)
            _events.tryEmit(msg)
            _pending.value = runCatching { engine.hasPendingRestore }.getOrDefault(false)
            return@withLock
        }
        val report = try {
            graph.gameBoost.stop()
        } catch (t: Throwable) {
            val msg = FriendlyErrors.fromRaw(t.message)
            log.add(LogLevel.ERROR, "Restore failed", msg)
            _events.tryEmit("Restore failed - tap Restore Everything to retry.")
            return@withLock
        }
        _pending.value = runCatching { engine.hasPendingRestore }.getOrDefault(false)
        if (report.stillPending == 0 && report.error == null) {
            _session.value = null
            log.add(LogLevel.SUCCESS, "Settings restored", "${trigger.restoreLabel()}${name?.let { " - $it" } ?: ""}")
            _events.tryEmit("Everything restored")
        } else {
            log.add(
                LogLevel.WARNING, "Restore incomplete",
                "${report.stillPending} setting(s) are still pending. Tap Restore Everything to retry."
            )
            _events.tryEmit("Some settings couldn't be restored yet - tap Restore Everything.")
        }
        syncService()
    }

    private suspend fun doRestoreEverything() {
        graph.boostController.stopBoost() // stop killing immediately, even if a boost is still applying
        mutex.withLock {
            if (!graph.shizukuManager.isConnected) {
                val msg = "Shizuku is offline. Start Shizuku and tap again - nothing is lost, it's all saved."
                log.add(LogLevel.ERROR, "Restore Everything couldn't run", msg)
                _events.tryEmit(msg)
                return@withLock
            }
            log.add(LogLevel.INFO, "Restore Everything started")
            var last: com.trendulon.gameturbo.boost.engine.RestoreReport? = null
            for (attempt in 0 until 3) {
                last = runCatching { engine.restore() }.getOrNull()
                _pending.value = runCatching { engine.hasPendingRestore }.getOrDefault(false)
                if (!_pending.value) break
                if (attempt < 2) delay(600)
            }
            val done = !_pending.value
            if (done) {
                _session.value = null
                val notes = last?.notRestorable.orEmpty()
                log.add(
                    LogLevel.SUCCESS, "Everything restored",
                    if (notes.isEmpty()) "All settings are back to how they were."
                    else "Settings are back. Can't be undone: ${notes.joinToString("; ")}"
                )
                _events.tryEmit("Everything restored")
            } else {
                val n = last?.stillPending ?: 0
                log.add(
                    LogLevel.ERROR, "Restore Everything incomplete",
                    "$n setting(s) couldn't be put back. Check Shizuku and try again, or reboot the phone."
                )
                _events.tryEmit("$n setting(s) couldn't be restored. Try again or reboot.")
            }
            syncService()
        }
    }

    /** App was killed mid-boost: the engine still holds saved originals. Put them back once Shizuku is up. */
    private suspend fun recoverIfNeeded() {
        delay(1_500)
        val needs = runCatching { engine.hasPendingRestore }.getOrDefault(false)
        if (!needs || mutex.isLocked || _session.value != null || engine.state.value !is BoostEngineState.Idle) return
        log.add(LogLevel.INFO, "Unfinished boost found", "Restoring your original settings automatically.")
        doRestore(Trigger.RECOVERY)
    }

    // ---- extras -------------------------------------------------------------------------------

    private fun checkHeat(state: TurboUiState) {
        if (!state.active || !state.overheating) return
        val now = SystemClock.elapsedRealtime()
        if (lastHeatWarning != 0L && now - lastHeatWarning < HEAT_WARNING_GAP_MS) return
        lastHeatWarning = now
        val temp = state.temperatureC?.let { String.format("%.1f°C", it) } ?: "very warm"
        val text = "Your phone is $temp. Take a break or restore to cool down."
        log.add(LogLevel.WARNING, "Phone is getting hot", text)
        notifier.alert("Phone is getting hot", text)
        _events.tryEmit(text)
    }

    private fun syncService() = AutomationService.sync(context)

    private fun BoostMode.label() = when (this) {
        BoostMode.BALANCED -> "Balanced"
        BoostMode.PERFORMANCE -> "Performance"
        BoostMode.MAXIMUM -> "Maximum"
    }

    private fun Trigger.label() = when (this) {
        Trigger.MANUAL -> "started manually"
        Trigger.AUTO -> "game detected"
        Trigger.TILE -> "from Quick Settings"
        Trigger.FLOATING -> "from floating button"
        Trigger.RECOVERY -> "recovery"
    }

    private fun Trigger.restoreLabel() = when (this) {
        Trigger.AUTO -> "Game closed"
        Trigger.RECOVERY -> "Recovered after the app was closed"
        else -> "Restored by you"
    }

    private companion object {
        const val THERMAL_SEVERE = 3
        const val HEAT_WARNING_GAP_MS = 5 * 60_000L
    }
}
