package com.trendulon.gameturbo.services

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Restarts the background service after a reboot / app update if auto-detect or the floating button is on. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            runCatching { AutomationService.sync(context) }
        }
    }
}
