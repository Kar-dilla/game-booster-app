package com.trendulon.gameturbo.boost.engine

import android.content.Context
import android.os.Build
import android.util.Log
import com.trendulon.gameturbo.killer.PackageNames
import com.trendulon.gameturbo.profiles.BoostMode
import com.trendulon.gameturbo.shizuku.ShizukuNotReadyException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Dev 2 - Boost Engine. Runs the performance commands through Shizuku and puts everything back.
 *
 * ```
 * val report  = engine.apply("com.activision.callofduty.shooter")            // PERFORMANCE (default)
 * val report2 = engine.apply("com.pkg", BoostMode.MAXIMUM)
 * val restore = engine.restore()
 * ```
 *
 * Guarantees:
 *  - Originals are read and written to disk BEFORE the first change (survives app death / reboot).
 *  - A value that cannot be read is NOT changed (we never change what we cannot put back).
 *  - Steps run in the fixed order from [Tweaks.build]. A failing step is reported and the rest
 *    still run; an unreachable Shizuku aborts the run (the snapshot stays, restore() still works).
 *  - Calling [apply] again while a boost is active never overwrites the saved originals.
 *  - [restore] walks the changes backwards, reads each value back to verify it, and keeps any
 *    step that failed so that calling [restore] again retries it.
 *  - apply/restore never run at the same time (mutex).
 *
 * Does not touch the UI, the Process Killer or the Shizuku code. Combine with the killer through
 * [GameBoost] if you want one call for both.
 */
class BoostEngine internal constructor(
    private val executor: ShellExecutor,
    private val store: SnapshotStore,
    private val sdkInt: Int
) {
    constructor(context: Context, executor: ShellExecutor) :
        this(executor, SnapshotStore(context), Build.VERSION.SDK_INT)

    private val mutex = Mutex()
    private val _state = MutableStateFlow<BoostEngineState>(BoostEngineState.Idle)
    val state: StateFlow<BoostEngineState> = _state.asStateFlow()

    /**
     * True when changes are saved and not yet restored (boost active, or the app died mid-boost).
     * Call [restore] on app start when this is true.
     */
    val hasPendingRestore: Boolean get() = store.load()?.isEmpty == false

    suspend fun apply(
        packageName: String,
        mode: BoostMode = BoostMode.PERFORMANCE,
        options: BoostOptions = BoostOptions()
    ): BoostReport = mutex.withLock {
        val started = System.currentTimeMillis()
        fun elapsed() = System.currentTimeMillis() - started

        if (!PackageNames.isValid(packageName)) {
            return@withLock BoostReport(packageName, mode, emptyList(), elapsed(), error = "Invalid package name")
        }

        val sh = Sh(executor)
        val results = ArrayList<StepResult>()
        var finished = false
        try {
            val plan = BoostPlan.forMode(mode, options)

            // Detecting the refresh rate is also the first Shizuku call: if Shizuku is down we
            // fail here, before anything was saved or changed.
            _state.value = BoostEngineState.Applying(packageName, mode, "detect")
            val hz = if (sdkInt >= 29) {
                BoostParsers.maxRefreshRate(sh.read("dumpsys display", 30_000L).orEmpty())
            } else null

            val built = Tweaks.build(TweakContext(packageName, plan, options, sdkInt, hz))
            results += built.skipped

            val snap = store.load() ?: Snapshot()

            // Mode switch while a boost is active: undo what the new mode no longer includes.
            val newIds = built.steps.map { it.id }.toSet()
            val stale = snap.entries.keys.filter { id ->
                val owner = Tweaks.packageOf(id)
                (owner == null || owner == packageName) && id !in newIds
            }
            if (stale.isNotEmpty()) {
                snap.packages += packageName
                restoreEntries(sh, snap, stale, results)
            }

            // 1) Save originals first.
            val newlyCaptured = HashSet<String>()
            val unusable = HashSet<String>()
            for (step in built.steps) {
                if (step !is Tweak || step.id in snap.entries) continue
                _state.value = BoostEngineState.Applying(packageName, mode, "save original: ${step.id}")
                val original = step.read(sh)
                if (original == null) {
                    unusable += step.id
                    results += StepResult(step.id, StepStatus.SKIPPED, "current value unreadable here, left unchanged")
                } else {
                    snap.entries[step.id] = original
                    newlyCaptured += step.id
                }
            }
            snap.packages += packageName
            snap.mode = mode
            if (!store.save(snap)) {
                return@withLock BoostReport(
                    packageName, mode, results, elapsed(),
                    error = "Could not save the original values, so nothing was changed"
                )
            }

            // 2) Apply in the fixed order.
            for (step in built.steps) {
                _state.value = BoostEngineState.Applying(packageName, mode, step.id)
                when (step) {
                    is Tweak -> {
                        if (step.id in unusable) continue
                        val out = step.apply(sh)
                        if (out.ok) {
                            results += StepResult(step.id, StepStatus.OK, out.detail)
                        } else {
                            results += StepResult(step.id, StepStatus.FAILED, out.detail)
                            // Command failed => assume nothing changed; forget a freshly saved original.
                            if (step.id in newlyCaptured) {
                                snap.entries.remove(step.id)
                                store.save(snap)
                            }
                        }
                    }
                    is Action -> {
                        val out = step.run(sh)
                        results += StepResult(step.id, if (out.ok) StepStatus.OK else StepStatus.FAILED, out.detail)
                        if (out.ok) {
                            snap.irreversible += step.irreversibleTag
                            store.save(snap)
                        }
                    }
                }
            }

            val report = BoostReport(packageName, mode, results, elapsed())
            _state.value = BoostEngineState.Active(packageName, mode, report)
            finished = true
            report
        } catch (e: CancellationException) {
            throw e
        } catch (e: ShizukuNotReadyException) {
            BoostReport(packageName, mode, results, elapsed(), error = e.message ?: "Shizuku not ready")
        } catch (t: Throwable) {
            Log.e(TAG, "Boost failed", t)
            BoostReport(packageName, mode, results, elapsed(), error = t.toString())
        } finally {
            if (!finished) _state.value = BoostEngineState.Idle
        }
    }

    suspend fun restore(): RestoreReport = mutex.withLock {
        val snap = store.load() ?: return@withLock RestoreReport(emptyList(), 0, emptyList())
        val sh = Sh(executor)
        val results = ArrayList<StepResult>()
        val notRestorable = snap.irreversible.mapNotNull { IRREVERSIBLE_TEXT[it] }
        try {
            restoreEntries(sh, snap, snap.entries.keys.toList(), results)
            val pending = snap.entries.size
            if (pending == 0) store.clear()
            _state.value = BoostEngineState.Idle
            RestoreReport(results, pending, notRestorable)
        } catch (e: CancellationException) {
            throw e
        } catch (e: ShizukuNotReadyException) {
            _state.value = BoostEngineState.Idle
            RestoreReport(results, snap.entries.size, notRestorable, error = e.message ?: "Shizuku not ready")
        } catch (t: Throwable) {
            Log.e(TAG, "Restore failed", t)
            _state.value = BoostEngineState.Idle
            RestoreReport(results, snap.entries.size, notRestorable, error = t.toString())
        }
    }

    /**
     * Restores [ids] newest-first. A successful step is removed from the snapshot (and the
     * snapshot is saved right away); a failed step stays so it can be retried.
     */
    private suspend fun restoreEntries(sh: Sh, snap: Snapshot, ids: List<String>, results: MutableList<StepResult>) {
        val catalogue = Tweaks.catalogue(snap.packages, sdkInt)
        for (id in ids.asReversed()) {
            val original = snap.entries[id] ?: continue
            val tweak = catalogue[id]
            if (tweak == null) {
                snap.entries.remove(id)
                store.save(snap)
                results += StepResult(id, StepStatus.SKIPPED, "unknown step, dropped from the snapshot")
                continue
            }
            _state.value = BoostEngineState.Restoring(id)
            val out = tweak.restore(sh, original)
            if (!out.ok) {
                results += StepResult(id, StepStatus.FAILED, "restore command failed: ${out.detail}")
                continue
            }
            if (tweak.verifiable) {
                val now = tweak.read(sh)
                if (now != null && now.value != original.value) {
                    results += StepResult(
                        id, StepStatus.FAILED,
                        "read back '${now.value}', expected '${original.value}'"
                    )
                    continue
                }
            }
            snap.entries.remove(id)
            store.save(snap)
            val note = if (original.assumed) "restored to the default (original value was not readable)" else ""
            results += StepResult(id, StepStatus.OK, note)
        }
    }

    private companion object {
        const val TAG = "BoostEngine"
        val IRREVERSIBLE_TEXT = mapOf(
            "trim_caches" to "App caches were deleted (cannot be undone; apps rebuild them).",
            "kill_all" to "Background apps were closed (they restart on their own)."
        )
    }
}
