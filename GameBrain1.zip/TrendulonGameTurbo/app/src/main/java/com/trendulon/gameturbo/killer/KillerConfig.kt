package com.trendulon.gameturbo.killer

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Killer settings.
 * @param continuousEnabled re-kill repeatedly while boost is active (the toggle).
 * @param intervalSeconds   seconds between passes; clamped to 10..30 (see [safeIntervalSeconds]).
 * @param onlyKillRunning   only force-stop apps that currently have a process (accurate "killed"
 *                          counts, faster passes). Falls back to all apps if the process list
 *                          cannot be read.
 */
data class KillerConfig(
    val continuousEnabled: Boolean = false,
    val intervalSeconds: Int = DEFAULT_INTERVAL_SECONDS,
    val onlyKillRunning: Boolean = true
) {
    val safeIntervalSeconds: Int get() = intervalSeconds.coerceIn(MIN_INTERVAL_SECONDS, MAX_INTERVAL_SECONDS)

    companion object {
        const val MIN_INTERVAL_SECONDS = 10
        const val MAX_INTERVAL_SECONDS = 30
        const val DEFAULT_INTERVAL_SECONDS = 15
    }
}

/** Persisted, observable [KillerConfig]. */
class KillerConfigStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("trendulon_killer_config", Context.MODE_PRIVATE)

    private val _config = MutableStateFlow(load())
    val config: StateFlow<KillerConfig> = _config.asStateFlow()

    @Synchronized
    fun update(transform: (KillerConfig) -> KillerConfig) {
        val new = transform(_config.value)
        _config.value = new
        prefs.edit()
            .putBoolean(K_CONTINUOUS, new.continuousEnabled)
            .putInt(K_INTERVAL, new.intervalSeconds)
            .putBoolean(K_ONLY_RUNNING, new.onlyKillRunning)
            .apply()
    }

    fun setContinuous(enabled: Boolean) = update { it.copy(continuousEnabled = enabled) }
    fun setIntervalSeconds(seconds: Int) = update { it.copy(intervalSeconds = seconds) }

    private fun load() = KillerConfig(
        continuousEnabled = prefs.getBoolean(K_CONTINUOUS, false),
        intervalSeconds = prefs.getInt(K_INTERVAL, KillerConfig.DEFAULT_INTERVAL_SECONDS),
        onlyKillRunning = prefs.getBoolean(K_ONLY_RUNNING, true)
    )

    private companion object {
        const val K_CONTINUOUS = "continuous"
        const val K_INTERVAL = "interval"
        const val K_ONLY_RUNNING = "only_running"
    }
}
