package com.trendulon.gameturbo.boost.engine

import kotlin.math.roundToInt

/**
 * Pure parsing helpers for shell output. These formats vary between Android versions and OEMs,
 * so every parser returns null when it does not recognise the output (the engine then falls back
 * or skips instead of guessing).
 */
internal object BoostParsers {

    /** `settings get` prints the literal text "null" for an unset key. */
    fun settingValue(raw: String?): String? {
        val v = raw?.trim() ?: return null
        return if (v.isEmpty() || v == "null") null else v
    }

    /** Highest refresh rate (Hz) found in `dumpsys display`, e.g. "fps=120.0". Null if none. */
    fun maxRefreshRate(dumpsysDisplay: String): Int? =
        FPS.findAll(dumpsysDisplay)
            .mapNotNull { it.groupValues[1].toFloatOrNull() }
            .filter { it in 30f..360f }
            .maxOrNull()
            ?.roundToInt()

    /** From `cmd game list-modes <pkg>`: "... current mode: performance, available ...". */
    fun currentGameMode(output: String): String? =
        GAME_MODE.find(output)?.groupValues?.get(1)?.lowercase()

    /** From `cmd appops get <pkg> <OP>`: "RUN_ANY_IN_BACKGROUND: allow; time=...". */
    fun appOpMode(output: String, op: String): String? {
        if (output.contains("No operations", ignoreCase = true)) return "default"
        val m = Regex("(?m)^\\s*" + Regex.escape(op) + ":\\s*([a-z_]+)").find(output) ?: return null
        return m.groupValues[1].lowercase()
    }

    /** True if [pkg] has any entry (system or user) in `cmd deviceidle whitelist` output. */
    fun isDeviceIdleWhitelisted(output: String, pkg: String): Boolean =
        output.lineSequence().any { line ->
            val parts = line.trim().split(',')
            parts.size >= 2 && parts[1] == pkg
        }

    /** First "[status=speed-profile]" in `dumpsys package <pkg>` (the dexopt state). */
    fun compileStatus(dumpsysPackage: String): String? =
        STATUS.find(dumpsysPackage)?.groupValues?.get(1)

    /** Sets/replaces one `key=value` inside a comma separated `activity_manager_constants` string. */
    fun mergeConstant(existing: String?, key: String, value: Int): String {
        val parts = existing.orEmpty().split(',')
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("$key=") }
        return (parts + "$key=$value").joinToString(",")
    }

    private val FPS = Regex("\\bfps=([0-9]+(?:\\.[0-9]+)?)")
    private val GAME_MODE = Regex("current mode:\\s*([A-Za-z0-9_]+)", RegexOption.IGNORE_CASE)
    private val STATUS = Regex("\\[status=([a-z\\-]+)\\]")
}
