package com.trendulon.gameturbo.automation

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.trendulon.gameturbo.R
import com.trendulon.gameturbo.services.ActionReceiver
import com.trendulon.gameturbo.ui.MainActivity

class Notifier(context: Context) {
    private val appContext = context.applicationContext

    init {
        val nm = appContext.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_STATUS, "Boost status", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Shown while auto-detect or a boost is running."
                setShowBadge(false)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERTS, "Warnings", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Heat warnings and restore problems."
            }
        )
    }

    fun statusNotification(title: String, text: String, canRestore: Boolean): Notification {
        val open = PendingIntent.getActivity(
            appContext, 0, Intent(appContext, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = NotificationCompat.Builder(appContext, CH_STATUS)
            .setSmallIcon(R.drawable.ic_stat_bolt)
            .setColor(Color.parseColor("#FF6A00"))
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(open)
        if (canRestore) {
            val restore = PendingIntent.getBroadcast(
                appContext, 1,
                Intent(appContext, ActionReceiver::class.java).setAction(ActionReceiver.ACTION_RESTORE),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            builder.addAction(0, "Restore", restore)
        }
        return builder.build()
    }

    fun updateStatus(notification: Notification) {
        runCatching {
            if (PermissionHelper.hasNotifications(appContext)) {
                NotificationManagerCompat.from(appContext).notify(ID_STATUS, notification)
            }
        }
    }

    fun alert(title: String, text: String) {
        runCatching {
            if (!PermissionHelper.hasNotifications(appContext)) return
            val open = PendingIntent.getActivity(
                appContext, 2, Intent(appContext, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(appContext, CH_ALERTS)
                .setSmallIcon(R.drawable.ic_stat_bolt)
                .setColor(Color.parseColor("#FF6A00"))
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setContentIntent(open)
                .build()
            NotificationManagerCompat.from(appContext).notify(ID_ALERT, n)
        }
    }

    companion object {
        const val CH_STATUS = "status"
        const val CH_ALERTS = "alerts"
        const val ID_STATUS = 1001
        const val ID_ALERT = 1002
    }
}
