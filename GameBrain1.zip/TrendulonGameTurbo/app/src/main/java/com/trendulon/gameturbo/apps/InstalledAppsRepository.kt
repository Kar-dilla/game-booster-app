package com.trendulon.gameturbo.apps

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class InstalledApp(
    val label: String,
    val packageName: String,
    val isGame: Boolean
)

enum class AppFilter { GAMES, ALL }

/**
 * Lists launchable apps for target selection. Uses the LAUNCHER intent query, so it needs no
 * QUERY_ALL_PACKAGES permission. "Games" is a heuristic (app category / game flag); some games
 * do not declare it, so offer the ALL filter as well.
 */
class InstalledAppsRepository(context: Context) {
    private val appContext = context.applicationContext

    @Suppress("DEPRECATION")
    suspend fun list(filter: AppFilter = AppFilter.ALL): List<InstalledApp> = withContext(Dispatchers.IO) {
        val pm = appContext.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(intent, 0)
            .mapNotNull { it.activityInfo?.applicationInfo }
            .distinctBy { it.packageName }
            .filter { it.packageName != appContext.packageName }
            .map { info ->
                val isGame = info.category == ApplicationInfo.CATEGORY_GAME ||
                    (info.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                InstalledApp(info.loadLabel(pm).toString(), info.packageName, isGame)
            }
            .filter { filter == AppFilter.ALL || it.isGame }
            .sortedBy { it.label.lowercase() }
    }
}
