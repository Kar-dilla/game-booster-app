package com.trendulon.gameturbo.services

import android.app.PendingIntent
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.trendulon.gameturbo.R
import com.trendulon.gameturbo.automation.Phase
import com.trendulon.gameturbo.automation.Trigger
import com.trendulon.gameturbo.automation.Turbo
import com.trendulon.gameturbo.automation.TurboUiState
import com.trendulon.gameturbo.ui.ConfirmBoostActivity
import com.trendulon.gameturbo.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Quick Settings tile: tap to boost the selected game, tap again to restore. */
class BoostTileService : TileService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var job: Job? = null

    override fun onStartListening() {
        super.onStartListening()
        val turbo = Turbo.of(this)
        job?.cancel()
        job = scope.launch { turbo.coordinator.ui.collect { render(it) } }
    }

    override fun onStopListening() {
        job?.cancel()
        super.onStopListening()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    override fun onClick() {
        super.onClick()
        val turbo = Turbo.of(this)
        val coordinator = turbo.coordinator
        val ui = coordinator.ui.value
        when {
            ui.busy -> Unit
            ui.active -> coordinator.restore(Trigger.TILE)
            else -> {
                val profile = coordinator.defaultProfile()
                when {
                    profile == null -> openActivity(Intent(this, MainActivity::class.java))
                    coordinator.requiresMaxConfirmation(profile, Trigger.TILE) ->
                        openActivity(ConfirmBoostActivity.intent(this, profile.packageName, Trigger.TILE))
                    else -> coordinator.boost(profile, Trigger.TILE)
                }
            }
        }
    }

    private fun render(ui: TurboUiState) {
        val tile = qsTile ?: return
        tile.label = getString(R.string.tile_label)
        tile.icon = Icon.createWithResource(this, R.drawable.ic_bolt)
        tile.state = if (ui.active || ui.busy) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        if (Build.VERSION.SDK_INT >= 29) {
            tile.subtitle = when (ui.phase) {
                is Phase.Applying -> "Applying..."
                is Phase.Restoring -> "Restoring..."
                Phase.Active -> ui.session?.profile?.name ?: "On"
                Phase.Idle -> if (ui.starting) "Starting..." else "Off"
            }
        }
        tile.updateTile()
    }

    @Suppress("DEPRECATION")
    private fun openActivity(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(
                PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            )
        } else {
            startActivityAndCollapse(intent)
        }
    }
}
