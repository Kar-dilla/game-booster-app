package com.trendulon.gameturbo.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.trendulon.gameturbo.automation.ThemeMode

/** Colours taken from the Trendulon Newsroom screenshots: near-black, orange accent, green/yellow status. */
object TurboColors {
    val Orange = Color(0xFFFF6A00)
    val Green = Color(0xFF4ADE80)
    val Yellow = Color(0xFFFACC15)
    val Red = Color(0xFFF87171)

    val DarkBg = Color(0xFF050505)
    val DarkCard = Color(0xFF0F0F10)
    val DarkRaised = Color(0xFF171718)
    val DarkBorder = Color(0xFF222224)
    val DarkMuted = Color(0xFF9A9AA0)
}

private val DarkScheme = darkColorScheme(
    primary = TurboColors.Orange,
    onPrimary = Color(0xFF0A0A0A),
    primaryContainer = Color(0xFF3A1B05),
    onPrimaryContainer = TurboColors.Orange,
    secondary = TurboColors.Orange,
    onSecondary = Color(0xFF0A0A0A),
    secondaryContainer = Color(0xFF2A1708),
    onSecondaryContainer = TurboColors.Orange,
    background = TurboColors.DarkBg,
    onBackground = Color.White,
    surface = TurboColors.DarkCard,
    onSurface = Color.White,
    surfaceVariant = TurboColors.DarkRaised,
    onSurfaceVariant = TurboColors.DarkMuted,
    surfaceContainer = TurboColors.DarkCard,
    surfaceContainerHigh = TurboColors.DarkRaised,
    outline = TurboColors.DarkBorder,
    outlineVariant = Color(0xFF1B1B1D),
    error = TurboColors.Red,
    onError = Color(0xFF0A0A0A)
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFFE85D00),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFE3D1),
    onPrimaryContainer = Color(0xFF7A2E00),
    secondary = Color(0xFFE85D00),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFE3D1),
    onSecondaryContainer = Color(0xFF7A2E00),
    background = Color(0xFFF7F7F8),
    onBackground = Color(0xFF0A0A0A),
    surface = Color.White,
    onSurface = Color(0xFF0A0A0A),
    surfaceVariant = Color(0xFFEFEFF1),
    onSurfaceVariant = Color(0xFF5E5E66),
    surfaceContainer = Color.White,
    surfaceContainerHigh = Color(0xFFEFEFF1),
    outline = Color(0xFFDADADF),
    outlineVariant = Color(0xFFEAEAEE),
    error = Color(0xFFD14343),
    onError = Color.White
)

private val TurboTypography = Typography(
    headlineLarge = TextStyle(fontWeight = FontWeight.ExtraBold, fontSize = 34.sp, lineHeight = 38.sp, letterSpacing = (-0.5).sp),
    headlineMedium = TextStyle(fontWeight = FontWeight.ExtraBold, fontSize = 28.sp, lineHeight = 32.sp, letterSpacing = (-0.3).sp),
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 28.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 17.sp, lineHeight = 22.sp),
    bodyLarge = TextStyle(fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 23.sp),
    bodyMedium = TextStyle(fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 17.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 15.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 12.sp, letterSpacing = 1.sp),
    labelSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 11.sp, letterSpacing = 2.sp)
)

@Composable
fun TrendulonTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }
    MaterialTheme(
        colorScheme = if (dark) DarkScheme else LightScheme,
        typography = TurboTypography,
        content = content
    )
}
