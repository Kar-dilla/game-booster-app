# Shizuku instantiates the user service by class name.
-keep class com.trendulon.gameturbo.shizuku.ShellUserService { *; }
