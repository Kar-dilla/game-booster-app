# TRENDULON Game Turbo — Dev 1 (Core + Process Killer)

Foundation layer: Shizuku integration, target/profile storage, whitelist and the process killer.
**No UI is included** (as instructed). Everything is exposed as plain Kotlin classes / `StateFlow`s
for the UI to bind to.

> **Not compiled or tested.** This was written without an Android SDK or device. Expect to open it
> in Android Studio, let Gradle sync, and fix any small compile issue. See "Known limits" below.

- Package: `com.trendulon.gameturbo` · minSdk 26 · targetSdk/compileSdk 34 · Kotlin, single module `:app`
- Shizuku API 13.1.5 (`dev.rikka.shizuku:api` + `provider`)
- `gradle/wrapper/gradle-wrapper.properties` is included (Gradle 8.7) but not `gradle-wrapper.jar`.
  Android Studio regenerates it on sync, or run `gradle wrapper` once.
- No Activity is declared in the manifest on purpose. The UI developer adds `MainActivity`.

## Getting the graph (all the objects you need)

```kotlin
val graph = (application as TrendulonApp).graph
graph.shizukuManager      // connection + exec
graph.processKiller       // one kill pass
graph.boostController     // Boost Now / Stop Boost (+ continuous loop)
graph.whitelistStore      // user whitelist
graph.killerConfigStore   // continuous toggle + interval
graph.profileStore        // saved profiles + selected targets
graph.installedApps       // list apps (Games / All)
```

## How to connect to Shizuku

Users need the Shizuku app installed and running (started via wireless debugging, ADB, or root).

```kotlin
val shizuku = graph.shizukuManager

// Observe (for the status label and to enable/disable privileged features)
shizuku.status.collect { s ->           // ShizukuStatus.Connected / Disconnected / NotAuthorized
    // Connected -> enable features; otherwise disable them
}
shizuku.mode.collect { m -> }           // ShizukuMode.ADB / ROOT / UNKNOWN

// "Connect to Shizuku" button handler:
shizuku.connect()
```

What `connect()` does: not running -> opens the Shizuku app; running but not authorized -> shows the
permission prompt (if the user chose "deny and don't ask again" it opens the Shizuku app instead);
connected -> binds the shell service.

Status is checked on app launch (`TrendulonApp.onCreate` calls `start()`), on every binder
received/dead event, and by a watchdog every 2 s (disconnected) / 5 s (connected). If Shizuku dies
and comes back, the manager re-binds automatically. `shizuku.autoReconnect = false` pauses the
watchdog.

Privileged commands for any feature (Dev 2 can reuse this):
```kotlin
val r = shizuku.exec("settings put global window_animation_scale 0")   // suspend; r.exitCode / r.stdout / r.stderr
```
`exec` throws `ShizukuNotReadyException` if Shizuku is not Connected. Commands run through a Shizuku
UserService (`ShellUserService`), because `Shizuku.newProcess` is private in API 13+.

## How to call the Process Killer

Class: `killer/ProcessKiller` (one pass) and `boost/BoostController` (Boost Now / Stop Boost).

```kotlin
// One pass, directly. Keep the game alive:
val report: KillReport = graph.processKiller.killNow(targets = setOf("com.activision.callofduty.shooter"))
// report.killed, report.failed, report.survivors, report.skippedProtected, report.error

// Boost Now / Stop Boost (state for the status panel is in boostController.state):
graph.killerConfigStore.setContinuous(true)           // the continuous re-kill toggle
graph.killerConfigStore.setIntervalSeconds(15)        // clamped to 10..30
graph.boostController.boostNow(setOf("com.activision.callofduty.shooter"))
// or boostController.boostNow(profile)  // TargetProfile
graph.boostController.stopBoost()

graph.boostController.state.collect { st ->
    // st.active, st.killedCount, st.killedPackages (live list), st.passes, st.lastReport, st.lastError
}
```
If continuous is OFF, `boostNow` does one pass and finishes. If ON, it repeats until `stopBoost()`.
The toggle and interval are re-read each loop, so changing them while boosting applies live.

### What gets killed / what never does
Candidates = user-installed apps (`pm list packages -3`), force-stopped with `am force-stop`.
Never killed:
1. `ExclusionList` hard list (`android`, `com.android.systemui`, `com.android.phone`,
   `com.android.providers.*`, settings, telecom, GMS, Shizuku itself, ...)
2. `ProtectedPackagesResolver` (resolved on the device): this app, default launcher(s), enabled
   keyboards, default dialer + SMS app, enabled accessibility services
3. User whitelist (`WhitelistStore`)
4. The `targets` passed in
5. The app currently in the foreground (best effort, from `dumpsys activity activities`)

Reliability features: only running apps are targeted (`ps -A -o NAME`) so counts are real; survivors
are verified and force-stopped a second time; every package name is regex-validated before being
placed into a shell command; passes can't overlap (mutex); per-package success/fail is reported.

## Important files

| File | Purpose |
|---|---|
| `shizuku/ShizukuManager.kt` | Connect, status/mode flows, permission, death handling, auto-reconnect, `exec` |
| `shizuku/ShellUserService.kt`, `aidl/.../IShellService.aidl`, `ShellResult.aidl/.kt` | Shell executor that runs inside the Shizuku process |
| `shizuku/ShizukuStatus.kt` | `ShizukuStatus`, `ShizukuMode`, `ShizukuNotReadyException` |
| `killer/ProcessKiller.kt` | The kill pass |
| `killer/ExclusionList.kt`, `ProtectedPackagesResolver.kt` | Hard + dynamic protection |
| `killer/WhitelistStore.kt` | User whitelist (persisted, `StateFlow`) |
| `killer/KillerConfig.kt` | `KillerConfig` + `KillerConfigStore` (continuous toggle, interval, only-running) |
| `killer/KillReport.kt`, `PackageNames.kt` | Pass result; package-name validation |
| `boost/BoostController.kt` | Boost Now / Stop Boost + continuous loop + `BoostState` |
| `profiles/TargetProfile.kt`, `ProfileStore.kt` | Saved profiles (name, package, `BoostMode`) + selected targets |
| `apps/InstalledAppsRepository.kt` | App list for selection (Games / All filter) |
| `AppGraph.kt`, `TrendulonApp.kt` | Manual dependency container + Application class |

## Notes for Dev 2

- **Stop Boost does not restore anything.** This module changes no system settings, so there is
  nothing to restore here. Your Auto Restore system should hook into `boostNow` / `stopBoost`.
- `BoostMode` is only stored on the profile. The killer ignores it (Balanced / Performance / Maximum
  differences are yours to implement).
- Reuse `ShizukuManager.exec(...)` for all your `settings` / `cmd` / `pm` / `dumpsys` commands.
- **Foreground service:** the continuous loop runs in the app process. If Android freezes or kills the
  app in the background, the loop stops. For real background reliability, run `boostNow` from a
  foreground service (not in my scope, so not done).
- Auto-detect "target app came to foreground" is not implemented (outside my task list). The foreground
  lookup inside the killer is only a safety exclusion.
- The Quick Settings tile / floating button / action log / thermal / export-import are not included.
- If the UI developer wants the first-launch flow: show an "Install Shizuku" hint when
  `shizukuManager.isShizukuAppInstalled()` is false.

## Known limits (be aware)

- **Untested build.** Verify on a real device with Shizuku running.
- Force-stop is not permanent: any app can be relaunched by the user, another app, or a launcher
  action. Continuous re-kill (10-30 s) is the mitigation. Apps listed in `report.survivors` ignored
  the force-stop twice.
- Only user-installed apps are targeted. System apps and updated system apps (Chrome, YouTube on many
  devices) are not killed by design; widening this means extending `listUserPackages()` in
  `ProcessKiller` and relying on the exclusion list.
- OEM battery managers (MIUI, ColorOS, One UI) may restart some apps; the survivors list shows it.
- `ps -A -o NAME` and `dumpsys` output can vary by OEM. If the process list cannot be read, the killer
  falls back to force-stopping all candidates; if the foreground lookup fails, it simply skips that
  one extra protection.
- Games filter in `InstalledAppsRepository` is a heuristic (category / game flag), so offer "All apps".
- `QUERY_ALL_PACKAGES` is deliberately not used (`<queries>` in the manifest covers what is needed).

---

# Dev 2 - Boost Engine (`boost/engine/`)

Added on top of Dev 1's code. UI, Process Killer and Shizuku code are untouched. The only edit to an
existing file is **`AppGraph.kt`** (imports + `boostEngine` + `gameBoost`, appended at the end).
**Not compiled or tested** (no Android SDK / device here). Expect to sync in Android Studio and fix
small compile issues, then run the on-device checks below.

## Usage

```kotlin
val engine = (application as TrendulonApp).graph.boostEngine

val report = engine.apply("com.activision.callofduty.shooter")             // PERFORMANCE (default)
val report2 = engine.apply("com.pkg", BoostMode.MAXIMUM, BoostOptions(maximumCompileFilter = CompileFilter.SPEED))
val restore = engine.restore()          // puts everything back

engine.state            // StateFlow<BoostEngineState>: Idle / Applying(step) / Active / Restoring(step)
engine.hasPendingRestore // true if a boost is active OR the app died mid-boost -> call restore() on launch
```
Optional one-call wrapper with Dev 1's killer: `graph.gameBoost.start(profile)` / `.stop()`
(start = engine commands, then `boostController.boostNow`; stop = `stopBoost`, then restore).

## Execution order (fixed, see `Tweaks.build`)

1. `cmd game mode performance <pkg>` (Android 12+)
2. Background process limit (Android 12+: `device_config ... max_cached_processes`; 8-11: `activity_manager_constants`)
3. Animations: `window_animation_scale`, `transition_animation_scale`, `animator_duration_scale` -> 0
4. Peak refresh rate (`peak_refresh_rate`, plus `min_refresh_rate` in Performance/Maximum). Rate is read from `dumpsys display`
5. Battery unrestricted: `cmd deviceidle whitelist +pkg` + appops `RUN_IN_BACKGROUND`, `RUN_ANY_IN_BACKGROUND` -> allow
6. Do Not Disturb (Priority only, so alarms still ring)
7. `pm trim-caches` then `am kill-all`
8. Maximum only: `pm compile -m speed|everything -f <pkg>`, then 9. disable HW overlays, then 10. force GPU rendering

## Modes (one table: `BoostPlan.forMode`)

| | Balanced | Performance (default) | Maximum |
|---|---|---|---|
| Steps 1-7 | yes | yes | yes |
| Background process limit | 4 | 0 | 0 |
| `min_refresh_rate` locked | no | yes | yes |
| compile / HW overlays / GPU | no | no | yes |

This split is my interpretation of the spec (it only lists "mandatory" vs "optional/Maximum").
Change the numbers in `BoostPlan.kt` if you want a different split.
`TargetProfile` / `ProfileStore` (Dev 1) default to BALANCED, the spec says Performance is the default.
I did not touch them; the UI should pass the mode explicitly, or change that default.

## Save / restore

- Originals are read first and written to disk (SharedPreferences, `commit()`) BEFORE the first change.
- A value that cannot be read is not changed.
- Calling `apply` again (other mode / other game) never overwrites saved originals. Switching to a
  lower mode undoes what the new mode no longer includes.
- `restore()` goes backwards, reads each value back to verify, keeps failed steps so a second call retries.
- Keys that were unset are deleted again (`settings delete` / `device_config delete`), not set to a guess.

### What restore cannot undo
- `pm trim-caches` (caches of ALL apps, including the game's, are gone)
- `am kill-all` (apps restart on their own)
- `pm compile` is put back to the previous filter, which is equivalent but not guaranteed byte-identical.

## Known limits / verify on a real device

I wrote the commands and parsers from knowledge of AOSP behaviour without a device. These are the
weakest spots; check them first (run in `adb shell`):

| Step | Check | Risk |
|---|---|---|
| Game mode | `cmd game list-modes <pkg>` should print "current mode: ..." | If the text differs, original is assumed `standard` (flagged `assumed`). Only works for apps the OS treats as games |
| Background limit | `device_config get activity_manager max_cached_processes`; then watch `dumpsys activity processes` | Equivalent to the dev-option cap but system may re-sync the flag; OEMs differ |
| Refresh rate | `dumpsys display \| grep fps=` | Samsung uses its own `refresh_rate_mode`, not handled |
| DND | `settings get global zen_mode` after `cmd notification set_dnd priority` | Android 15 "modes" may behave differently |
| HW overlays | `service call SurfaceFlinger 1008 i32 1` | No read-back; original assumed 0. Often does NOT help games and can raise GPU load / heat |
| GPU rendering | `getprop persist.sys.ui.hw` after `setprop` | Many ROMs block `persist.*` writes for shell (reported as FAILED, not faked). Only affects apps started afterwards, and mostly View-based UI, not Vulkan/GL game engines |
| compile | `dumpsys package <pkg> \| grep status=` | Can take minutes (20 min timeout) |
| trim-caches | n/a | Can make the first game load slower. Disable with `BoostOptions(trimCaches = false)` |

Other notes: single user (user 0) only. One active boost at a time is the intended use. Run it from a
foreground service if it must survive the app being backgrounded (same note as Dev 1).

---

# Dev 3 - UI / UX, Automation, Profiles & Polish

Added on top of Dev 1 + Dev 2. **Not changed:** everything in `killer/`, `boost/`, `shizuku/`, `profiles/`,
`apps/`, `AppGraph.kt`, `TrendulonApp.kt`. Edited for the UI only: `AndroidManifest.xml`, `app/build.gradle.kts`
(Compose), `res/values/strings.xml`. **Not compiled or tested** (no Android SDK here): sync in Android Studio,
fix small compile issues, then test on a device with Shizuku running.

| Package | What |
|---|---|
| `ui/` | `MainActivity`, `ConfirmBoostActivity` (Maximum warning over a game/the shade) |
| `ui/screens/` | Home (status panel, game + mode, Boost/Restore, pipeline, Restore Everything), Games (profiles CRUD + app picker), Log, Settings (+whitelist), Onboarding, permissions panel |
| `ui/theme`, `ui/components` | Trendulon look (black + orange, from the newsroom screenshots), dark/light/system |
| `automation/` | `BoostCoordinator` (single entry point to `GameBoost`), `AutoPilot` (detect -> boost, leave -> restore), `ForegroundWatcher`, `SettingsStore`, `ActionLog`, `ThermalMonitor`, `Notifier`, `PermissionHelper`, `Turbo` (`Turbo.of(context)`) |
| `services/` | `AutomationService` (foreground service), `BoostTileService`, `FloatingButton`, `BootReceiver`, `ActionReceiver` |

## Behaviour worth knowing
- Everything goes through `BoostCoordinator` -> `graph.gameBoost.start/stop`. The UI passes the mode explicitly.
- **Auto-detect**: Usage Access events (one-tap grant through Shizuku), falling back to `dumpsys` via Shizuku.
  Screen-off is ignored. Auto-restore waits a configurable delay (default 8 s) and only arms after the game was seen.
  SystemUI and keyboards don't count as "left the game". "Keep boost until I turn it off" disables auto-restore.
- **Maximum safety**: warning with a required checkbox on select and on every manual start. Tile and floating button
  open `ConfirmBoostActivity` instead of starting Maximum. Auto-detect uses Performance unless "Start Maximum
  automatically" is switched on (off by default). The coordinator also refuses an unconfirmed Maximum as a last line of defence.
- **Restore Everything**: stops the kill loop at once, then retries `engine.restore()` up to 3 times. If the app dies
  mid-boost, the saved originals are restored automatically the next time Shizuku connects.
- **Heat warning**: battery temperature (+ system thermal status on Android 10+), once per 5 minutes while boosting.
- Maximum's `pm compile` can take minutes (Dev 2 note); the status panel says so and Restore Everything still stops the killer immediately.

## Things to verify on a device
Quick Settings tile start of the foreground service (Android may refuse it from the background; it is logged), usage-access
auto-grant (`appops set ... GET_USAGE_STATS allow`), overlay grant, the `dumpsys` fallback parser on your OEM, and Compose version
compatibility after Gradle sync.
