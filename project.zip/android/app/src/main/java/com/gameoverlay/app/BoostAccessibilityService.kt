package com.gameoverlay.app

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.ArrayDeque

/**
 * Force-closes other apps the way a human would:
 *  1. Open Recents and tap Clear / Close all (this is what actually removes
 *     cards from the recents tray — killBackgroundProcesses cannot).
 *  2. Open each leftover app's system App Info page and tap Force stop.
 *
 * Required on Android 14+ where killBackgroundProcesses is limited to our UID.
 */
class BoostAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private val queue = ArrayDeque<String>()
    private var keepPackage: String? = null
    private var running = false
    private var phase = Phase.IDLE
    private var closed = 0
    private var onDone: ((Int) -> Unit)? = null
    private var recentsClicks = 0

    override fun onServiceConnected() {
        instance = this
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onInterrupt() {}

    fun startBoost(targets: List<String>, keepPkg: String?, done: (Int) -> Unit) {
        handler.post {
            if (running) {
                done(0)
                return@post
            }
            running = true
            closed = 0
            recentsClicks = 0
            keepPackage = keepPkg
            onDone = done
            queue.clear()
            queue.addAll(targets.filter { it != keepPkg && it != packageName })
            OverlayService.instance?.setHiddenForBoost(true)
            phase = Phase.RECENTS
            performGlobalAction(GLOBAL_ACTION_RECENTS)
            handler.postDelayed({ clickClearAllFromRoot() }, 450)
            handler.postDelayed({ advanceFromRecents() }, RECENTS_TIMEOUT_MS)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!running || event == null) return
        when (phase) {
            Phase.RECENTS -> {
                if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                    event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                ) {
                    clickClearAllFromRoot()
                }
            }
            Phase.FORCE_STOP -> handleForceStopEvent(event)
            Phase.IDLE, Phase.RETURNING -> {}
        }
    }

    private fun clickClearAllFromRoot() {
        if (phase != Phase.RECENTS) return
        val root = rootInActiveWindow ?: return
        if (clickClearAll(root)) {
            recentsClicks++
            closed = (closed + 4).coerceAtLeast(closed) // recents wipe is a batch
        }
        root.recycle()
    }

    private fun clickClearAll(node: AccessibilityNodeInfo): Boolean {
        val texts = arrayOf(
            "Clear all", "Close all", "Clear", "Close", "CLEAR ALL", "CLOSE ALL",
            "Clear All", "Close All", "Remove all",
            "清理", "清除", "全部清除", "全部关闭", "关闭全部", "一键清理"
        )
        for (t in texts) {
            if (clickByText(node, t)) return true
        }
        val ids = arrayOf(
            "com.miui.home:id/clearAnimView",
            "com.miui.home:id/clear_all",
            "com.miui.home:id/clearAll",
            "com.mi.android.globallauncher:id/clearAnimView",
            "com.android.systemui:id/clearAnimView",
            "com.android.systemui:id/dismiss_all",
            "com.android.systemui:id/clear_all",
            "com.android.systemui:id/recents_clear_all",
            "com.sec.android.app.launcher:id/clear_all_button",
            "com.sec.android.app.launcher:id/clear_all"
        )
        for (id in ids) {
            if (clickByViewId(node, id)) return true
        }
        // Content-desc sweep (Xiaomi trash button often has no visible text).
        if (clickByDescContains(node, listOf("clear", "close all", "清理", "清除"))) return true
        return false
    }

    private fun advanceFromRecents() {
        if (phase != Phase.RECENTS) return
        performGlobalAction(GLOBAL_ACTION_BACK)
        handler.postDelayed({
            if (queue.isEmpty()) {
                finishBoost()
            } else {
                phase = Phase.FORCE_STOP
                openNextAppInfo()
            }
        }, 280)
    }

    private fun openNextAppInfo() {
        val pkg = queue.pollFirst()
        if (pkg == null) {
            finishBoost()
            return
        }
        currentForcePkg = pkg
        forceStopClicked = false
        confirmClicked = false
        try {
            val intent = android.content.Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = android.net.Uri.parse("package:$pkg")
                addFlags(
                    android.content.Intent.FLAG_ACTIVITY_NEW_TASK or
                        android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK or
                        android.content.Intent.FLAG_ACTIVITY_NO_HISTORY or
                        android.content.Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
                )
            }
            startActivity(intent)
        } catch (_: Exception) {
            handler.post { openNextAppInfo() }
            return
        }
        handler.removeCallbacks(forceStopWatchdog)
        handler.postDelayed(forceStopWatchdog, PER_APP_TIMEOUT_MS)
    }

    private var currentForcePkg: String? = null
    private var forceStopClicked = false
    private var confirmClicked = false

    private val forceStopWatchdog = Runnable {
        if (phase != Phase.FORCE_STOP) return@Runnable
        performGlobalAction(GLOBAL_ACTION_BACK)
        handler.postDelayed({ openNextAppInfo() }, 180)
    }

    private fun handleForceStopEvent(event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        ) return
        val root = rootInActiveWindow ?: return
        try {
            if (!forceStopClicked) {
                val labels = arrayOf(
                    "Force stop", "Force Stop", "FORCE STOP",
                    "强行停止", "强制停止", "Force Stop "
                )
                for (t in labels) {
                    if (clickByText(root, t)) {
                        forceStopClicked = true
                        break
                    }
                }
            } else if (!confirmClicked) {
                val confirms = arrayOf(
                    "OK", "Ok", "Force stop", "FORCE STOP", "Yes", "Determine",
                    "确定", "强行停止", "OK "
                )
                for (t in confirms) {
                    if (clickByText(root, t, requireEnabled = true)) {
                        confirmClicked = true
                        closed++
                        handler.removeCallbacks(forceStopWatchdog)
                        handler.postDelayed({
                            performGlobalAction(GLOBAL_ACTION_BACK)
                            handler.postDelayed({ openNextAppInfo() }, 160)
                        }, 200)
                        break
                    }
                }
            }
        } finally {
            root.recycle()
        }
    }

    private fun finishBoost() {
        handler.removeCallbacksAndMessages(null)
        phase = Phase.RETURNING
        performGlobalAction(GLOBAL_ACTION_BACK)
        handler.postDelayed({
            OverlayService.instance?.setHiddenForBoost(false)
            val count = closed
            val cb = onDone
            reset()
            cb?.invoke(count)
        }, 280)
    }

    private fun reset() {
        running = false
        phase = Phase.IDLE
        queue.clear()
        onDone = null
        currentForcePkg = null
        keepPackage = null
    }

    private fun clickByText(
        node: AccessibilityNodeInfo,
        text: String,
        requireEnabled: Boolean = true
    ): Boolean {
        val matches = node.findAccessibilityNodeInfosByText(text) ?: return false
        for (m in matches) {
            val ok = clickNodeOrParent(m, requireEnabled)
            m.recycle()
            if (ok) return true
        }
        return false
    }

    private fun clickByViewId(node: AccessibilityNodeInfo, viewId: String): Boolean {
        val matches = node.findAccessibilityNodeInfosByViewId(viewId) ?: return false
        for (m in matches) {
            val ok = clickNodeOrParent(m, requireEnabled = false)
            m.recycle()
            if (ok) return true
        }
        return false
    }

    private fun clickByDescContains(node: AccessibilityNodeInfo, keys: List<String>): Boolean {
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""
        if (desc.isNotEmpty() && keys.any { desc.contains(it.lowercase()) }) {
            if (clickNodeOrParent(node, requireEnabled = false)) return true
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val hit = clickByDescContains(child, keys)
            child.recycle()
            if (hit) return true
        }
        return false
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo, requireEnabled: Boolean): Boolean {
        var cur: AccessibilityNodeInfo? = node
        var depth = 0
        while (cur != null && depth < 6) {
            val enabled = if (requireEnabled) cur.isEnabled else true
            if (enabled && (cur.isClickable || cur.isCheckable)) {
                return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            cur = cur.parent
            depth++
        }
        return false
    }

    private enum class Phase { IDLE, RECENTS, FORCE_STOP, RETURNING }

    companion object {
        @Volatile
        var instance: BoostAccessibilityService? = null
            private set

        fun isConnected(): Boolean = instance != null

        private const val RECENTS_TIMEOUT_MS = 1400L
        private const val PER_APP_TIMEOUT_MS = 2200L
    }
}
