package com.gameoverlay.app

/**
 * Privileged, Shizuku-backed session actions. Each function is a no-op
 * (returns false) if the user hasn't granted Shizuku permission, so callers
 * can always call these and just fall back to the existing behaviour
 * (Accessibility force-stop, no refresh-rate change, etc).
 */
object GameModeController {

    fun available(): Boolean = ShizukuManager.hasPermission()

    /** Instant, silent force-stop — replaces the Accessibility "simulate taps" path. */
    fun forceStop(packageName: String, onDone: ((Boolean) -> Unit)? = null) {
        if (!available()) {
            onDone?.invoke(false)
            return
        }
        ShizukuManager.execAsync("am force-stop $packageName") { code, _ ->
            onDone?.invoke(code == 0)
        }
    }

    fun forceStopAll(packages: List<String>, onDone: ((Int) -> Unit)? = null) {
        if (!available() || packages.isEmpty()) {
            onDone?.invoke(0)
            return
        }
        ShizukuManager.execAsync(packages.joinToString(" && ") { "am force-stop $it" }) { _, _ ->
            onDone?.invoke(packages.size)
        }
    }

    /**
     * Forces peak+min refresh rate for the session. Many OEM ROMs cap games
     * to 60Hz to save battery even on 90/120/144Hz panels; this writes the
     * system setting shell can reach but a normal app permission can't.
     */
    fun lockRefreshRate(hz: Float, onDone: ((Boolean) -> Unit)? = null) {
        if (!available()) {
            onDone?.invoke(false)
            return
        }
        val cmd = "settings put system peak_refresh_rate $hz && " +
            "settings put system min_refresh_rate $hz"
        ShizukuManager.execAsync(cmd) { code, _ -> onDone?.invoke(code == 0) }
    }

    /** Restores the device's default (usually the panel's max) refresh rate behavior. */
    fun restoreRefreshRate(defaultHz: Float = 60f, onDone: ((Boolean) -> Unit)? = null) {
        if (!available()) {
            onDone?.invoke(false)
            return
        }
        val cmd = "settings delete system peak_refresh_rate && " +
            "settings delete system min_refresh_rate"
        ShizukuManager.execAsync(cmd) { code, _ ->
            if (code == 0) onDone?.invoke(true) else {
                // Some ROMs don't support delete; fall back to writing the default.
                val fallback = "settings put system peak_refresh_rate $defaultHz && " +
                    "settings put system min_refresh_rate $defaultHz"
                ShizukuManager.execAsync(fallback) { c2, _ -> onDone?.invoke(c2 == 0) }
            }
        }
    }

    /** Switches Private DNS to a low-latency resolver for the session. */
    fun setGamingDns(hostname: String = "1dot1dot1dot1.cloudflare-dns.com", onDone: ((Boolean) -> Unit)? = null) {
        if (!available()) {
            onDone?.invoke(false)
            return
        }
        val cmd = "settings put global private_dns_mode hostname && " +
            "settings put global private_dns_specifier $hostname"
        ShizukuManager.execAsync(cmd) { code, _ -> onDone?.invoke(code == 0) }
    }

    /**
     * Reads what the display hardware itself reports it can do, via DisplayManager —
     * no assumption, no hardcoded 90/120/144 guess. A locked rate this app requests
     * that isn't in this list will either get silently clamped to the nearest
     * supported mode or ignored outright by the OEM's settings provider, so always
     * pick from here rather than a number that "sounds right" for a gaming phone.
     */
    fun supportedRefreshRates(context: android.content.Context): List<Float> {
        return try {
            val dm = context.getSystemService(android.content.Context.DISPLAY_SERVICE)
                as android.hardware.display.DisplayManager
            val display = dm.getDisplay(android.view.Display.DEFAULT_DISPLAY)
                ?: return listOf(60f)
            display.supportedModes
                .map { it.refreshRate }
                .distinctBy { Math.round(it) }
                .sortedDescending()
                .ifEmpty { listOf(60f) }
        } catch (_: Exception) {
            listOf(60f)
        }
    }

    fun maxSupportedRefreshRate(context: android.content.Context): Float =
        supportedRefreshRates(context).maxOrNull() ?: 60f

    /** Restores automatic Private DNS mode. */
    fun restoreDns(onDone: ((Boolean) -> Unit)? = null) {
        if (!available()) {
            onDone?.invoke(false)
            return
        }
        ShizukuManager.execAsync("settings put global private_dns_mode opportunistic") { code, _ ->
            onDone?.invoke(code == 0)
        }
    }

    /**
     * Forces Android's "fixed performance mode" — the same knob PowerManager exposes
     * to apps as `PowerManager.setPowerMode` / `Window.setSustainedPerformanceMode`,
     * but only shell (via Shizuku) can flip it globally without the app itself holding
     * a rendering window. On devices that actually implement it, this pins CPU/GPU to
     * a fixed clock table instead of letting the thermal/idle governor ramp them up
     * and down every few hundred ms — that ramping is a real source of frame-time
     * spikes ("stutter") in games, independent of raw average FPS.
     *
     * BE HONEST about what this is, both to the user and in code:
     *  - It requires `cmd power` to exist and the OEM to have wired up fixed-performance
     *    mode at all. Stock AOSP-based ROMs and Pixels generally support it; some heavily
     *    customized OEM skins silently ignore the command (exit code 0, no effect) or
     *    don't expose it below Android 11 (API 30).
     *  - It disables the thermal governor's ability to downclock preemptively, so a
     *    long session WILL run hotter and drain battery faster than normal. On a phone
     *    that's already thermal-throttling, forcing fixed-performance mode can make
     *    things worse, not better — check thermalStatusLabel() before relying on this.
     *  - This is not a magic "unlock max clocks" switch. It fixes clocks at whatever
     *    the OEM's performance table says for this mode — usually high, not necessarily
     *    the device's absolute peak.
     * Always pair enabling this with restoring it (false) when the session ends; never
     * leave a phone pinned at fixed performance in the background.
     */
    fun setPerformanceMode(enabled: Boolean, onDone: ((Boolean) -> Unit)? = null) {
        if (!available()) {
            onDone?.invoke(false)
            return
        }
        val cmd = "cmd power set-fixed-performance-mode-enabled $enabled"
        ShizukuManager.execAsync(cmd) { code, output ->
            // Some ROMs return a non-zero exit with a "not supported" message rather
            // than throwing — treat anything other than a clean 0 as failure so the UI
            // doesn't lie about a mode that silently didn't apply.
            onDone?.invoke(code == 0 && !output.contains("not supported", ignoreCase = true))
        }
    }

    /**
     * Temporarily trims how many cached processes the system keeps around,
     * pushing Android's own Low Memory Killer to be more aggressive while
     * gaming. Restore afterwards — leaving this low hurts everyday
     * multitasking and app-switch speed.
     */
    fun tightenCachedProcessLimit(onDone: ((Boolean) -> Unit)? = null) {
        if (!available()) {
            onDone?.invoke(false)
            return
        }
        ShizukuManager.execAsync("device_config put activity_manager max_cached_processes 8") { code, _ ->
            onDone?.invoke(code == 0)
        }
    }

    fun restoreCachedProcessLimit(onDone: ((Boolean) -> Unit)? = null) {
        if (!available()) {
            onDone?.invoke(false)
            return
        }
        ShizukuManager.execAsync("device_config delete activity_manager max_cached_processes") { code, _ ->
            onDone?.invoke(code == 0)
        }
    }

    data class FrameStats(
        val totalFrames: Int,
        val jankyFrames: Int,
        val jankyPercent: Double,
        val p50Ms: Int,
        val p90Ms: Int,
        val p95Ms: Int,
        val p99Ms: Int
    ) {
        /** Derived from the 50th-percentile frame time, not a raw counter — Android
         *  exposes frame timing, not an "fps" number, so this is an estimate. */
        val estimatedFps: Int get() = if (p50Ms > 0) (1000 / p50Ms).coerceAtMost(240) else 0
    }

    /**
     * Pulls REAL frame-timing data for the foreground game via
     * `dumpsys gfxinfo <pkg>`, which HWUI/SurfaceFlinger maintain per app.
     * This replaces the old "we just show the locked screen refresh rate and
     * call it FPS" placeholder — this is genuine per-app render data, not a
     * substitute metric. Returns null if Shizuku isn't available, the package
     * has no rendering stats yet (just launched), or parsing fails — callers
     * must handle null by falling back to the refresh-rate label, and must
     * NOT silently reuse the last good reading as if it were current.
     */
    fun frameStats(packageName: String, onDone: (FrameStats?) -> Unit) {
        if (!available()) {
            onDone(null)
            return
        }
        ShizukuManager.execAsync("dumpsys gfxinfo $packageName") { code, output ->
            onDone(if (code == 0) parseGfxInfo(output) else null)
        }
    }

    private fun parseGfxInfo(output: String): FrameStats? {
        // Typical block:
        //   Total frames rendered: 4213
        //   Janky frames: 128 (3.04%)
        //   50th percentile: 9ms
        //   90th percentile: 16ms
        //   95th percentile: 21ms
        //   99th percentile: 41ms
        fun intAfter(label: String): Int? =
            Regex("$label:\\s*(\\d+)").find(output)?.groupValues?.get(1)?.toIntOrNull()
        fun msAfter(label: String): Int? =
            Regex("$label:\\s*(\\d+)ms").find(output)?.groupValues?.get(1)?.toIntOrNull()
        fun pctAfter(label: String): Double? =
            Regex("$label:\\s*\\d+\\s*\\(([\\d.]+)%\\)").find(output)?.groupValues?.get(1)?.toDoubleOrNull()

        val total = intAfter("Total frames rendered") ?: return null
        val janky = intAfter("Janky frames") ?: return null
        val jankyPct = pctAfter("Janky frames") ?: 0.0
        val p50 = msAfter("50th percentile") ?: return null
        val p90 = msAfter("90th percentile") ?: 0
        val p95 = msAfter("95th percentile") ?: 0
        val p99 = msAfter("99th percentile") ?: 0
        if (total == 0) return null // app hasn't rendered a frame in this dumpsys window yet
        return FrameStats(total, janky, jankyPct, p50, p90, p95, p99)
    }
}
