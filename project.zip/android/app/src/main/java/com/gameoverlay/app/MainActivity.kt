package com.gameoverlay.app

import android.Manifest
import android.app.AppOpsManager
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.RadioGroup
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private data class AppEntry(val label: String, val packageName: String)

    private lateinit var lvApps: ListView
    private lateinit var tvPermStatus: TextView
    private lateinit var tvShizukuStatus: TextView
    private var appEntries: List<AppEntry> = emptyList()

    private val shizukuPermListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == ShizukuManager.REQUEST_CODE) {
                runOnUiThread {
                    refreshShizukuStatus()
                    val granted = grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED
                    Toast.makeText(
                        this,
                        if (granted) "Shizuku permission granted" else "Shizuku permission denied",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        lvApps = findViewById(R.id.lvApps)
        tvPermStatus = findViewById(R.id.tvPermStatus)
        tvShizukuStatus = findViewById(R.id.tvShizukuStatus)

        ShizukuManager.addListeners()
        ShizukuManager.addPermissionResultListener(shizukuPermListener)

        // The list sits inside a ScrollView (for the rest of the settings page),
        // so the outer ScrollView was stealing every drag before it reached the
        // list — that's why it looked frozen on the first ~4 apps. Telling the
        // parent not to intercept touches while a finger is down on the list
        // lets ListView handle its own vertical scrolling again.
        lvApps.setOnTouchListener { v, event ->
            v.parent?.requestDisallowInterceptTouchEvent(true)
            if (event.action == android.view.MotionEvent.ACTION_UP ||
                event.action == android.view.MotionEvent.ACTION_CANCEL
            ) {
                v.parent?.requestDisallowInterceptTouchEvent(false)
            }
            false
        }

        loadInstalledApps()
        restoreSelection()

        val switchAutoMode = findViewById<Switch>(R.id.switchAutoMode)
        switchAutoMode.isChecked = Prefs.isAutoModeEnabled(this)
        switchAutoMode.setOnCheckedChangeListener { _, checked ->
            Prefs.setAutoModeEnabled(this, checked)
        }

        val switchForce = findViewById<Switch>(R.id.switchForceClose)
        switchForce.isChecked = Prefs.isForceCloseEnabled(this)
        switchForce.setOnCheckedChangeListener { _, checked ->
            Prefs.setForceCloseEnabled(this, checked)
            if (checked && !isAccessibilityEnabled()) {
                Toast.makeText(
                    this,
                    "Force-close needs Accessibility — open it below",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        findViewById<android.widget.Button>(R.id.btnOverlayPerm).setOnClickListener {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        }
        findViewById<android.widget.Button>(R.id.btnUsagePerm).setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        findViewById<android.widget.Button>(R.id.btnDndPerm).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        findViewById<android.widget.Button>(R.id.btnWriteSettingsPerm).setOnClickListener {
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_WRITE_SETTINGS,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (_: Exception) {
            }
        }
        findViewById<android.widget.Button>(R.id.btnAccessPerm).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Turn on Game Turbo → Force close", Toast.LENGTH_LONG).show()
        }
        findViewById<android.widget.Button>(R.id.btnNotificationPerm).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                Toast.makeText(this, "Turn on Game Turbo ticker access", Toast.LENGTH_LONG).show()
            } catch (_: Exception) {
            }
        }
        findViewById<android.widget.Button>(R.id.btnShizukuPerm).setOnClickListener {
            when {
                !ShizukuManager.isAvailable() -> Toast.makeText(
                    this,
                    "Open the Shizuku app and tap Start first",
                    Toast.LENGTH_LONG
                ).show()
                ShizukuManager.hasPermission() -> Toast.makeText(
                    this,
                    "Already granted",
                    Toast.LENGTH_SHORT
                ).show()
                else -> ShizukuManager.requestPermission()
            }
        }

        val switchRefreshLock = findViewById<Switch>(R.id.switchRefreshLock)
        switchRefreshLock.isChecked = Prefs.isRefreshRateLockEnabled(this)
        switchRefreshLock.setOnCheckedChangeListener { _, checked ->
            Prefs.setRefreshRateLockEnabled(this, checked)
            if (checked && !ShizukuManager.hasPermission()) {
                Toast.makeText(this, "Grant Shizuku permission above first", Toast.LENGTH_LONG).show()
            }
        }

        val switchGamingDns = findViewById<Switch>(R.id.switchGamingDns)
        switchGamingDns.isChecked = Prefs.isGamingDnsEnabled(this)
        switchGamingDns.setOnCheckedChangeListener { _, checked ->
            Prefs.setGamingDnsEnabled(this, checked)
            if (checked && !ShizukuManager.hasPermission()) {
                Toast.makeText(this, "Grant Shizuku permission above first", Toast.LENGTH_LONG).show()
            }
        }

        val radioDnsProvider = findViewById<RadioGroup>(R.id.radioDnsProvider)
        val editNextDnsId = findViewById<EditText>(R.id.editNextDnsId)
        val tvDnsAutoResult = findViewById<TextView>(R.id.tvDnsAutoResult)
        editNextDnsId.setText(Prefs.getNextDnsId(this))

        fun refreshDnsProviderUi() {
            val provider = Prefs.getDnsProvider(this)
            editNextDnsId.visibility =
                if (provider == "nextdns" || provider == "auto") android.view.View.VISIBLE
                else android.view.View.GONE
            val lastWinner = Prefs.getLastDnsWinner(this)
            tvDnsAutoResult.visibility =
                if (provider == "auto" && lastWinner.isNotEmpty()) android.view.View.VISIBLE
                else android.view.View.GONE
            tvDnsAutoResult.text = if (provider == "auto") "Last session: $lastWinner" else ""
        }

        when (Prefs.getDnsProvider(this)) {
            "nextdns" -> radioDnsProvider.check(R.id.radioDnsNextDns)
            "auto" -> radioDnsProvider.check(R.id.radioDnsAuto)
            else -> radioDnsProvider.check(R.id.radioDnsCloudflare)
        }
        refreshDnsProviderUi()

        radioDnsProvider.setOnCheckedChangeListener { _, checkedId ->
            val provider = when (checkedId) {
                R.id.radioDnsNextDns -> "nextdns"
                R.id.radioDnsAuto -> "auto"
                else -> "cloudflare"
            }
            Prefs.setDnsProvider(this, provider)
            if (provider != "cloudflare" && Prefs.getNextDnsId(this).isBlank()) {
                Toast.makeText(this, "Enter your NextDNS config ID below", Toast.LENGTH_SHORT).show()
            }
            refreshDnsProviderUi()
        }

        editNextDnsId.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) Prefs.setNextDnsId(this, editNextDnsId.text.toString())
        }

        val switchPerfMode = findViewById<Switch>(R.id.switchPerfMode)
        switchPerfMode.isChecked = Prefs.isPerfModeEnabled(this)
        switchPerfMode.setOnCheckedChangeListener { _, checked ->
            Prefs.setPerfModeEnabled(this, checked)
            if (checked && !ShizukuManager.hasPermission()) {
                Toast.makeText(this, "Grant Shizuku permission above first", Toast.LENGTH_LONG).show()
            }
        }

        findViewById<android.widget.Button>(R.id.btnAutostart).setOnClickListener {
            openXiaomiAutostart()
        }
        findViewById<android.widget.Button>(R.id.btnBatterySelf).setOnClickListener {
            requestOwnBatteryUnrestricted()
        }

        findViewById<android.widget.Button>(R.id.btnSave).setOnClickListener {
            saveSelection()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }

        findViewById<android.widget.Button>(R.id.btnStart).setOnClickListener {
            if (!hasOverlayPermission() || !hasUsageAccess() || !hasDndAccess()) {
                Toast.makeText(this, "Grant Overlay, Usage and DND first", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if (Prefs.isForceCloseEnabled(this) && !isAccessibilityEnabled()) {
                Toast.makeText(
                    this,
                    "Enable Accessibility so Boost can actually close apps",
                    Toast.LENGTH_LONG
                ).show()
            }
            saveSelection()
            ContextCompat.startForegroundService(
                this,
                Intent(this, ForegroundWatcherService::class.java)
            )
            Toast.makeText(this, "Monitoring started", Toast.LENGTH_SHORT).show()
        }

        findViewById<android.widget.Button>(R.id.btnStop).setOnClickListener {
            stopService(Intent(this, ForegroundWatcherService::class.java))
            stopService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "Stopped", Toast.LENGTH_SHORT).show()
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                100
            )
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.BLUETOOTH_CONNECT),
                101
            )
        }
    }

    override fun onResume() {
        super.onResume()
        refreshPermStatus()
        refreshShizukuStatus()
    }

    override fun onDestroy() {
        ShizukuManager.removePermissionResultListener(shizukuPermListener)
        super.onDestroy()
    }

    private fun refreshShizukuStatus() {
        tvShizukuStatus.text = when {
            !ShizukuManager.isAvailable() -> "Not running — open Shizuku and tap Start"
            !ShizukuManager.hasPermission() -> "Running, permission not granted yet"
            else -> "Running and authorized — Power Mode active"
        }
    }

    private fun loadInstalledApps() {
        val pm = packageManager
        val apps = pm.getInstalledApplications(0)
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 || it.packageName == packageName }
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .map { AppEntry(pm.getApplicationLabel(it).toString(), it.packageName) }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }

        appEntries = apps
        lvApps.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_multiple_choice,
            apps.map { it.label }
        )
    }

    private fun restoreSelection() {
        val selected = Prefs.getSelectedGames(this)
        appEntries.forEachIndexed { index, entry ->
            if (entry.packageName in selected) lvApps.setItemChecked(index, true)
        }
    }

    private fun saveSelection() {
        val checked = lvApps.checkedItemPositions
        val selected = mutableSetOf<String>()
        for (i in appEntries.indices) {
            if (checked.get(i)) selected.add(appEntries[i].packageName)
        }
        Prefs.setSelectedGames(this, selected)
        Prefs.setNextDnsId(this, findViewById<EditText>(R.id.editNextDnsId).text.toString())
    }

    private fun hasOverlayPermission() = Settings.canDrawOverlays(this)

    private fun hasUsageAccess(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(),
                packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(),
                packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun hasDndAccess(): Boolean {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return nm.isNotificationPolicyAccessGranted
    }

    private fun isAccessibilityEnabled(): Boolean {
        val expected = ComponentName(this, BoostAccessibilityService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any {
            it.equals(expected, ignoreCase = true) ||
                it.contains("BoostAccessibilityService", ignoreCase = true)
        }
    }

    private fun hasNotificationAccess(): Boolean {
        return try {
            androidx.core.app.NotificationManagerCompat.getEnabledListenerPackages(this)
                .contains(packageName)
        } catch (_: Exception) {
            false
        }
    }

    private fun refreshPermStatus() {
        fun mark(ok: Boolean) = if (ok) "ON" else "off"
        tvPermStatus.text =
            "Overlay ${mark(hasOverlayPermission())}  ·  Usage ${mark(hasUsageAccess())}  ·  " +
                "DND ${mark(hasDndAccess())}  ·  Force-close ${mark(isAccessibilityEnabled())}  ·  " +
                "Ticker ${mark(hasNotificationAccess())}"
    }

    private fun openXiaomiAutostart() {
        val attempts = listOf(
            Intent().setComponent(
                ComponentName(
                    "com.miui.securitycenter",
                    "com.miui.permcenter.autostart.AutoStartManagementActivity"
                )
            ),
            Intent().setComponent(
                ComponentName(
                    "com.miui.securitycenter",
                    "com.miui.powercenter.PowerSettings"
                )
            ),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:$packageName"))
        )
        for (intent in attempts) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                startActivity(intent)
                Toast.makeText(this, "Allow autostart for Game Turbo", Toast.LENGTH_LONG).show()
                return
            } catch (_: Exception) {
            }
        }
    }

    private fun requestOwnBatteryUnrestricted() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            Toast.makeText(this, "Already unrestricted", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
            )
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }
}
