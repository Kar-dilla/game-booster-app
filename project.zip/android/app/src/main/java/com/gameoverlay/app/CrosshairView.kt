package com.gameoverlay.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/**
 * Draws a small center reticle. Deliberately minimal — a dot + cross, not a themed
 * crosshair pack, since this is a convenience overlay, not the app's main feature.
 */
class CrosshairView(context: Context) : View(context) {

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(200, 255, 255, 255)
        strokeWidth = 3f
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(220, 255, 80, 80)
        style = Paint.Style.FILL
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val armLength = 14f
        val gap = 4f
        canvas.drawLine(cx - armLength, cy, cx - gap, cy, linePaint)
        canvas.drawLine(cx + gap, cy, cx + armLength, cy, linePaint)
        canvas.drawLine(cx, cy - armLength, cx, cy - gap, linePaint)
        canvas.drawLine(cx, cy + gap, cx, cy + armLength, linePaint)
        canvas.drawCircle(cx, cy, 2f, dotPaint)
    }
}
