package com.gameoverlay.app

import android.app.Notification
import android.service.notification.StatusBarNotification
import android.service.notification.NotificationListenerService

/**
 * Feeds the compact top-of-screen ticker while a game session is active, so DND
 * (which already blocks the system heads-up banner) doesn't mean missing everything.
 *
 * Privacy: nothing here is written to disk, logged, or sent off-device. A posted
 * notification's title/text is read, optionally handed to OverlayService's ticker
 * for a few seconds on screen, and then dropped. If the user never enables the
 * "Ticker" toggle, or no game session is running, this class still receives every
 * notification (that's how the OS API works) but does nothing with any of them.
 */
class TickerNotificationListenerService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return // don't ticker our own persistent notification
        if (!Prefs.isTickerEnabled(this)) return
        val overlay = OverlayService.instance ?: return // no game session active — nothing to show

        val notification = sbn.notification
        // Ongoing notifications (music controls, download progress, our own foreground
        // service icons) aren't "messages" — skip them so the ticker doesn't turn into noise.
        if (notification.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        if (notification.flags and Notification.FLAG_FOREGROUND_SERVICE != 0) return

        val extras = notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim()
        if (title.isNullOrEmpty() && text.isNullOrEmpty()) return

        overlay.showTicker(title.orEmpty(), text.orEmpty())
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        // No-op: the ticker auto-dismisses itself on a timer, independent of the
        // original notification's lifecycle.
    }
}
