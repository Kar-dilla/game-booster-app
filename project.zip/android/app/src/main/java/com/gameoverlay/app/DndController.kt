package com.gameoverlay.app

import android.app.NotificationManager
import android.content.Context

object DndController {

    fun hasAccess(context: Context): Boolean {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return nm.isNotificationPolicyAccessGranted
    }

    fun isDndOn(context: Context): Boolean {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
    }

    /** Enables DND for the session, remembering whether it was already on. */
    fun enable(context: Context) {
        if (!hasAccess(context)) return
        Prefs.setDndWasOn(context, isDndOn(context))
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
    }

    /** Reverts DND to whatever it was before the session, called on game close. */
    fun revert(context: Context) {
        if (!hasAccess(context)) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val wasOn = Prefs.getDndWasOn(context)
        nm.setInterruptionFilter(
            if (wasOn) NotificationManager.INTERRUPTION_FILTER_NONE
            else NotificationManager.INTERRUPTION_FILTER_ALL
        )
    }

    /** Plain "turn it off", for a manual tap in the panel. Not the same as revert() —
     *  this always means off, regardless of what was saved before the session started. */
    fun disable(context: Context) {
        if (!hasAccess(context)) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
    }
}
