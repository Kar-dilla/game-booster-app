package com.gameoverlay.app

import android.app.ActivityManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process

object BoosterUtils {

    data class BoostResult(
        val freedMb: Long,
        val closedCount: Int,
        val consideredCount: Int,
        val skippedSystemCount: Int,
        val method: String
    )

    data class BoostPlan(
        val ramBeforeMb: Long,
        val targets: List<String>,
        val skippedSystemCount: Int,
        val consideredCount: Int
    )

    fun freeRamMb(context: Context): Long {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return info.availMem / (1024 * 1024)
    }

    /**
     * Build the kill list from usage stats (last 8 hours). On Android 14+
     * killBackgroundProcesses() can only kill our own UID, so this list is
     * handed to Accessibility to actually force-stop and clear recents.
     */
    fun plan(context: Context, foregroundPackage: String?): BoostPlan {
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val myPackage = context.packageName
        val end = System.currentTimeMillis()
        val start = end - 8L * 60 * 60 * 1000
        val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_BEST, start, end)

        var considered = 0
        var skipped = 0
        val scored = ArrayList<Pair<String, Long>>()

        stats?.forEach { usage ->
            val pkg = usage.packageName ?: return@forEach
            if (pkg == myPackage || pkg == foregroundPackage) return@forEach
            if (usage.lastTimeUsed < start) return@forEach
            considered++
            if (!isEligibleForKill(context, pkg)) {
                skipped++
                return@forEach
            }
            scored.add(pkg to usage.lastTimeUsed)
        }

        val targets = scored
            .sortedByDescending { it.second }
            .map { it.first }
            .distinct()
            .take(MAX_FORCE_STOP)

        return BoostPlan(
            ramBeforeMb = freeRamMb(context),
            targets = targets,
            skippedSystemCount = skipped,
            consideredCount = considered
        )
    }

    /**
     * Best-effort kill without Accessibility:
     *  1. Hidden forceStopPackage (works on some OEM builds)
     *  2. killBackgroundProcesses (Android 13 and below; own UID on 14+)
     *  3. GC
     * Returns how many packages we *attempted*.
     */
    fun softKill(context: Context, packages: List<String>): Int {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        var attempted = 0
        for (pkg in packages) {
            var ok = tryForceStopHidden(am, pkg)
            try {
                am.killBackgroundProcesses(pkg)
                ok = true
            } catch (_: Exception) {
            }
            if (ok) attempted++
        }
        try {
            Runtime.getRuntime().gc()
            System.runFinalization()
        } catch (_: Exception) {
        }
        return attempted
    }

    fun resultAfter(context: Context, plan: BoostPlan, closedCount: Int, method: String): BoostResult {
        val after = freeRamMb(context)
        return BoostResult(
            freedMb = (after - plan.ramBeforeMb).coerceAtLeast(0),
            closedCount = closedCount,
            consideredCount = plan.consideredCount,
            skippedSystemCount = plan.skippedSystemCount,
            method = method
        )
    }

    /**
     * Signature-level API. Fails on stock Android; some Xiaomi/HyperOS builds
     * still honor it for sideloaded tools. Worth one try before Accessibility.
     */
    private fun tryForceStopHidden(am: ActivityManager, pkg: String): Boolean {
        return try {
            val method = ActivityManager::class.java.getDeclaredMethod(
                "forceStopPackage",
                String::class.java
            )
            method.isAccessible = true
            method.invoke(am, pkg)
            true
        } catch (_: Throwable) {
            try {
                val getService = ActivityManager::class.java.getDeclaredMethod("getService")
                getService.isAccessible = true
                val iam = getService.invoke(null) ?: return false
                val userId = if (Build.VERSION.SDK_INT >= 24) {
                    Process.myUserHandle().hashCode()
                } else 0
                val fs = iam.javaClass.getMethod(
                    "forceStopPackage",
                    String::class.java,
                    Int::class.javaPrimitiveType
                )
                fs.invoke(iam, pkg, userId)
                true
            } catch (_: Throwable) {
                false
            }
        }
    }

    private val HARD_PROTECTED = setOf(
        "android",
        "com.android.systemui",
        "com.android.phone",
        "com.android.dialer",
        "com.android.settings",
        "com.android.permissioncontroller",
        "com.google.android.permissioncontroller",
        "com.google.android.gms",
        "com.google.android.gsf",
        "com.google.android.ext.services",
        "com.google.android.inputmethod.latin",
        "com.android.inputmethod.latin",
        "com.android.vending",
        "com.xiaomi.finddevice",
        "com.miui.securitycenter",
        "com.lbe.security.miui",
        "com.miui.home",
        "com.mi.android.globallauncher"
    )

    private fun isEligibleForKill(context: Context, packageName: String): Boolean {
        if (packageName in HARD_PROTECTED) return false
        if (packageName.startsWith("com.android.")) return false
        if (packageName == defaultLauncherPackage(context)) return false
        return try {
            val info = context.packageManager.getApplicationInfo(packageName, 0)
            // Never force-stop other persistent / system-flagged packages.
            if ((info.flags and ApplicationInfo.FLAG_PERSISTENT) != 0) return false
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }
    }

    private fun defaultLauncherPackage(context: Context): String? {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val resolveInfo = context.packageManager.resolveActivity(
            intent,
            PackageManager.MATCH_DEFAULT_ONLY
        )
        return resolveInfo?.activityInfo?.packageName
    }

    private const val MAX_FORCE_STOP = 12
}
