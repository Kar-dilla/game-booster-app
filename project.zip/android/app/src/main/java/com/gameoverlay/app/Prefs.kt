package com.gameoverlay.app

import android.content.Context

object Prefs {
    private const val FILE = "game_overlay_prefs"
    private const val KEY_GAMES = "selected_games"
    private const val KEY_DND_WAS_ON = "dnd_prev_state"
    private const val KEY_AUTO_MODE = "auto_mode"
    private const val KEY_FORCE_CLOSE = "force_close"
    private const val KEY_ANTI_MISTOUCH = "anti_mistouch"
    private const val KEY_BT_WAS_ON = "bt_prev_state"
    private const val KEY_ROTATION_WAS_ON = "rotation_prev_state"
    private const val KEY_ROTATION_LOCK_ENABLED = "rotation_lock_enabled"
    private const val KEY_CROSSHAIR = "crosshair_enabled"
    private const val KEY_BRIGHTNESS_LOCK = "brightness_lock_enabled"
    private const val KEY_TICKER = "ticker_enabled"
    private const val KEY_REFRESH_RATE_LOCK = "refresh_rate_lock_enabled"
    private const val KEY_REFRESH_RATE_HZ = "refresh_rate_hz"
    private const val KEY_GAMING_DNS = "gaming_dns_enabled"
    private const val KEY_DNS_PROVIDER = "dns_provider" // "cloudflare" | "nextdns" | "auto"
    private const val KEY_NEXTDNS_ID = "nextdns_config_id"
    private const val KEY_LAST_DNS_WINNER = "last_dns_winner" // last auto-benchmark result, for display only
    private const val KEY_PERF_MODE_ENABLED = "perf_mode_enabled"

    fun isRefreshRateLockEnabled(context: Context): Boolean {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(KEY_REFRESH_RATE_LOCK, false)
    }

    fun setRefreshRateLockEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_REFRESH_RATE_LOCK, enabled).apply()
    }

    fun getRefreshRateHz(context: Context): Float {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getFloat(KEY_REFRESH_RATE_HZ, 120f)
    }

    fun setRefreshRateHz(context: Context, hz: Float) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putFloat(KEY_REFRESH_RATE_HZ, hz).apply()
    }

    fun isGamingDnsEnabled(context: Context): Boolean {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(KEY_GAMING_DNS, false)
    }

    fun setGamingDnsEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_GAMING_DNS, enabled).apply()
    }

    /** "cloudflare" (default), "nextdns", or "auto" (benchmark both at session start). */
    fun getDnsProvider(context: Context): String {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getString(KEY_DNS_PROVIDER, "cloudflare") ?: "cloudflare"
    }

    fun setDnsProvider(context: Context, provider: String) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putString(KEY_DNS_PROVIDER, provider).apply()
    }

    /** User's personal NextDNS config ID (the short hex string from their NextDNS
     *  dashboard, e.g. "abc123"). Blank means NextDNS isn't usable yet. */
    fun getNextDnsId(context: Context): String {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getString(KEY_NEXTDNS_ID, "") ?: ""
    }

    fun setNextDnsId(context: Context, id: String) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putString(KEY_NEXTDNS_ID, id.trim()).apply()
    }

    /** Purely informational: what Auto mode picked last session, so the settings
     *  screen can show "Auto picked: NextDNS (18ms vs 31ms)" instead of a black box. */
    fun setLastDnsWinner(context: Context, summary: String) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putString(KEY_LAST_DNS_WINNER, summary).apply()
    }

    fun getLastDnsWinner(context: Context): String {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getString(KEY_LAST_DNS_WINNER, "") ?: ""
    }

    /** Forces the sustained "fixed performance mode" via Shizuku (locks CPU/GPU clocks,
     *  disabling the thermal/idle governor's normal ramping). Default OFF: this trades
     *  battery + heat for consistency, and on some devices does nothing at all — see
     *  GameModeController.setPerformanceMode for the honest caveats. */
    fun isPerfModeEnabled(context: Context): Boolean {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(KEY_PERF_MODE_ENABLED, false)
    }

    fun setPerfModeEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_PERF_MODE_ENABLED, enabled).apply()
    }

    fun getSelectedGames(context: Context): Set<String> {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return sp.getStringSet(KEY_GAMES, emptySet()) ?: emptySet()
    }

    fun setSelectedGames(context: Context, packages: Set<String>) {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        sp.edit().putStringSet(KEY_GAMES, packages).apply()
    }

    fun setDndWasOn(context: Context, wasOn: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_DND_WAS_ON, wasOn).apply()
    }

    fun getDndWasOn(context: Context): Boolean {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(KEY_DND_WAS_ON, false)
    }

    fun isAutoModeEnabled(context: Context): Boolean {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(KEY_AUTO_MODE, true)
    }

    fun setAutoModeEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_AUTO_MODE, enabled).apply()
    }

    /** Force-close other apps on Boost (Accessibility recents-clear + force-stop). Default ON. */
    fun isForceCloseEnabled(context: Context): Boolean {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(KEY_FORCE_CLOSE, true)
    }

    fun setForceCloseEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_FORCE_CLOSE, enabled).apply()
    }

    fun isAntiMistouchEnabled(context: Context): Boolean {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(KEY_ANTI_MISTOUCH, false)
    }

    fun setAntiMistouchEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ANTI_MISTOUCH, enabled).apply()
    }

    fun setBtWasOn(context: Context, wasOn: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_BT_WAS_ON, wasOn).apply()
    }

    fun getBtWasOn(context: Context): Boolean {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(KEY_BT_WAS_ON, false)
    }

    fun setRotationWasOn(context: Context, wasOn: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ROTATION_WAS_ON, wasOn).apply()
    }

    fun getRotationWasOn(context: Context): Boolean {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(KEY_ROTATION_WAS_ON, false)
    }

    /** Whether a game session should auto-lock rotation. Default off — off by default
     *  since not everyone wants it, unlike DND/Wi-Fi lock which are safe to assume. */
    fun isRotationLockSessionEnabled(context: Context): Boolean {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(KEY_ROTATION_LOCK_ENABLED, false)
    }

    fun setRotationLockSessionEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ROTATION_LOCK_ENABLED, enabled).apply()
    }

    /** Center reticle overlay. Default off — purely cosmetic, opt-in. */
    fun isCrosshairEnabled(context: Context): Boolean {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(KEY_CROSSHAIR, false)
    }

    fun setCrosshairEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_CROSSHAIR, enabled).apply()
    }

    /** Freezes screen brightness at its current value for the session (stops
     *  hand-shadow dimming in landscape). Default off — changes a physical sensation
     *  the user should choose, unlike a background radio/CPU tweak. */
    fun isBrightnessLockEnabled(context: Context): Boolean {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(KEY_BRIGHTNESS_LOCK, false)
    }

    fun setBrightnessLockEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_BRIGHTNESS_LOCK, enabled).apply()
    }

    /** Compact top-of-screen ticker for incoming notifications, sourced from
     *  NotificationListenerService. Default OFF: this permission reads every
     *  notification's content system-wide, so it must be something the user
     *  deliberately turns on, never something that activates silently. */
    fun isTickerEnabled(context: Context): Boolean {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(KEY_TICKER, false)
    }

    fun setTickerEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_TICKER, enabled).apply()
    }
}
