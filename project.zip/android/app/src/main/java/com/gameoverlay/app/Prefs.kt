package com.gameoverlay.app

import android.content.Context

object Prefs {
    private const val FILE = "game_overlay_prefs"
    private const val KEY_GAMES = "selected_games"
    private const val KEY_DND_WAS_ON = "dnd_prev_state"
    private const val KEY_AUTO_MODE = "auto_mode"
    private const val KEY_FORCE_CLOSE = "force_close"
    private const val KEY_ANTI_MISTOUCH = "anti_mistouch"
    private const val KEY_BT_WAS_ON = "bt_prev_state"
    private const val KEY_ROTATION_WAS_ON = "rotation_prev_state"
    private const val KEY_ROTATION_LOCK_ENABLED = "rotation_lock_enabled"

    fun getSelectedGames(context: Context): Set<String> {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return sp.getStringSet(KEY_GAMES, emptySet()) ?: emptySet()
    }

    fun setSelectedGames(context: Context, packages: Set<String>) {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        sp.edit().putStringSet(KEY_GAMES, packages).apply()
    }

    fun setDndWasOn(context: Context, wasOn: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_DND_WAS_ON, wasOn).apply()
    }

    fun getDndWasOn(context: Context): Boolean {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(KEY_DND_WAS_ON, false)
    }

    fun isAutoModeEnabled(context: Context): Boolean {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(KEY_AUTO_MODE, true)
    }

    fun setAutoModeEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_AUTO_MODE, enabled).apply()
    }

    /** Force-close other apps on Boost (Accessibility recents-clear + force-stop). Default ON. */
    fun isForceCloseEnabled(context: Context): Boolean {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(KEY_FORCE_CLOSE, true)
    }

    fun setForceCloseEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_FORCE_CLOSE, enabled).apply()
    }

    fun isAntiMistouchEnabled(context: Context): Boolean {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(KEY_ANTI_MISTOUCH, false)
    }

    fun setAntiMistouchEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ANTI_MISTOUCH, enabled).apply()
    }

    fun setBtWasOn(context: Context, wasOn: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_BT_WAS_ON, wasOn).apply()
    }

    fun getBtWasOn(context: Context): Boolean {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(KEY_BT_WAS_ON, false)
    }

    fun setRotationWasOn(context: Context, wasOn: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ROTATION_WAS_ON, wasOn).apply()
    }

    fun getRotationWasOn(context: Context): Boolean {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(KEY_ROTATION_WAS_ON, false)
    }

    /** Whether a game session should auto-lock rotation. Default off — off by default
     *  since not everyone wants it, unlike DND/Wi-Fi lock which are safe to assume. */
    fun isRotationLockSessionEnabled(context: Context): Boolean {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(KEY_ROTATION_LOCK_ENABLED, false)
    }

    fun setRotationLockSessionEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ROTATION_LOCK_ENABLED, enabled).apply()
    }
}
