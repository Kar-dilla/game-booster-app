package com.gameoverlay.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import android.widget.ToggleButton
import androidx.core.app.NotificationCompat
import kotlin.concurrent.thread
import kotlin.math.abs
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var panelView: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private lateinit var session: SessionEngine

    private val handler = Handler(Looper.getMainLooper())
    private var expanded = false
    private var hiddenForBoost = false
    private var gamePackage: String? = null
    private var sessionStartMs = 0L
    private var lastBoostFreedMb = 0L
    private var autoModeApplied = false
    private var pingGeneration = 0
    private var lastPingMs: Long = -1
    private var boosting = false
    private var peeking = true

    private val statsRunnable = object : Runnable {
        override fun run() {
            updateBubblePing()
            if (expanded) updateStats()
            handler.postDelayed(this, STATS_INTERVAL_MS)
        }
    }

    private val collapseOnIdle = Runnable { setExpanded(false) }
    private val peekRunnable = Runnable { peekToEdge() }

    override fun onCreate() {
        super.onCreate()
        instance = this
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        session = SessionEngine(this)
        createChannel()
        startForeground(NOTIF_ID, buildNotification())
        sessionStartMs = System.currentTimeMillis()
        // WIFI_MODE_FULL_LOW_LATENCY + a partial wake lock stop the radio from
        // power-saving between packets and stop Doze from parking the CPU —
        // both are free wins for ping/jitter, so grab them for every game
        // session, not only when "Auto-optimize" is switched on.
        session.acquireWifiLock()
        session.acquireWakeLock()
        addBubble()
        handler.post(statsRunnable)
        handler.postDelayed(peekRunnable, PEEK_DELAY_MS)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val pkg = intent?.getStringExtra(EXTRA_GAME_PACKAGE)
        if (pkg != null && pkg != gamePackage) {
            gamePackage = pkg
            if (!autoModeApplied) {
                autoModeApplied = true
                applyAutoModeOnce()
            }
        }
        return START_STICKY
    }

    private fun applyAutoModeOnce() {
        if (!Prefs.isAutoModeEnabled(this)) return
        session.startSession()
        if (DndController.hasAccess(this)) DndController.enable(this)
        thread { runBoost(silent = true) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        if (instance === this) instance = null
        handler.removeCallbacksAndMessages(null)
        showSessionSummary()
        DndController.revert(this)
        session.endSession()
        removePanel()
        bubbleView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        bubbleView = null
        super.onDestroy()
    }

    private fun showSessionSummary() {
        val minutes = ((System.currentTimeMillis() - sessionStartMs) / 60000).coerceAtLeast(0)
        Toast.makeText(
            this,
            "Session ${minutes}m · ~${lastBoostFreedMb} MB freed",
            Toast.LENGTH_LONG
        ).show()
    }

    fun setHiddenForBoost(hidden: Boolean) {
        handler.post {
            hiddenForBoost = hidden
            if (hidden) {
                bubbleView?.visibility = View.GONE
                panelView?.visibility = View.GONE
            } else {
                if (expanded) {
                    panelView?.visibility = View.VISIBLE
                } else {
                    bubbleView?.visibility = View.VISIBLE
                }
            }
        }
    }

    // ---------- Bubble (Xiaomi-style: small, docks, half-hides) ----------

    private fun addBubble() {
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_bubble, null)
        bubbleView = view

        val type = overlayType()
        val params = WindowManager.LayoutParams(
            dp(BUBBLE_DP),
            dp(BUBBLE_DP),
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 0
        params.y = dp(160)
        bubbleParams = params

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false

        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    handler.removeCallbacks(peekRunnable)
                    peeking = false
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (abs(dx) > 8 || abs(dy) > 8) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    try { windowManager.updateViewLayout(view, params) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) v.performClick()
                    else snapToEdge()
                    true
                }
                else -> false
            }
        }
        view.setOnClickListener { setExpanded(true) }

        windowManager.addView(view, params)
    }

    private fun snapToEdge() {
        val params = bubbleParams ?: return
        val view = bubbleView ?: return
        val screenW = resources.displayMetrics.widthPixels
        val size = view.width.coerceAtLeast(dp(BUBBLE_DP))
        params.x = if (params.x + size / 2 < screenW / 2) 0 else screenW - size
        params.y = params.y.coerceIn(dp(24), resources.displayMetrics.heightPixels - size - dp(24))
        try { windowManager.updateViewLayout(view, params) } catch (_: Exception) {}
        handler.removeCallbacks(peekRunnable)
        handler.postDelayed(peekRunnable, PEEK_DELAY_MS)
    }

    /** Slide ~45% of the bubble off-screen, Xiaomi Game Turbo style. */
    private fun peekToEdge() {
        if (expanded || hiddenForBoost) return
        val params = bubbleParams ?: return
        val view = bubbleView ?: return
        val screenW = resources.displayMetrics.widthPixels
        val size = view.width.coerceAtLeast(dp(BUBBLE_DP))
        val hide = (size * 0.46f).toInt()
        params.x = if (params.x + size / 2 < screenW / 2) -hide else screenW - size + hide
        peeking = true
        try { windowManager.updateViewLayout(view, params) } catch (_: Exception) {}
    }

    // ---------- Compact panel ----------

    private fun setExpanded(show: Boolean) {
        expanded = show
        handler.removeCallbacks(collapseOnIdle)
        handler.removeCallbacks(peekRunnable)
        if (show) {
            peeking = false
            if (panelView == null) addPanel()
            bubbleView?.visibility = View.GONE
            updateStats()
            scheduleAutoCollapse()
        } else {
            removePanel()
            if (!hiddenForBoost) bubbleView?.visibility = View.VISIBLE
            handler.postDelayed(peekRunnable, PEEK_DELAY_MS)
        }
    }

    private fun addPanel() {
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_panel, null)
        panelView = view

        val type = overlayType()
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        positionPanel(params)

        view.findViewById<View>(R.id.btnCollapse).setOnClickListener { setExpanded(false) }

        view.findViewById<View>(R.id.btnBoost).setOnClickListener {
            resetAutoCollapse()
            runBoost(silent = false)
        }
        view.findViewById<View>(R.id.btnBoost).setOnLongClickListener {
            resetAutoCollapse()
            requestBatteryExemption()
            true
        }

        val dndToggle = view.findViewById<ToggleButton>(R.id.toggleDnd)
        dndToggle.isChecked = DndController.isDndOn(this)
        dndToggle.setOnClickListener {
            resetAutoCollapse()
            if (!DndController.hasAccess(this)) {
                dndToggle.isChecked = false
                Toast.makeText(this, "Grant DND access in Game Turbo", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (dndToggle.isChecked) DndController.enable(this) else DndController.revert(this)
        }

        val wifiToggle = view.findViewById<ToggleButton>(R.id.toggleWifiLock)
        wifiToggle.isChecked = session.wifiHeld
        wifiToggle.setOnClickListener {
            resetAutoCollapse()
            if (wifiToggle.isChecked) session.acquireWifiLock() else session.releaseWifiLock()
        }

        val guardToggle = view.findViewById<ToggleButton>(R.id.toggleGuard)
        guardToggle.isChecked = session.antiMistouchOn || Prefs.isAntiMistouchEnabled(this)
        guardToggle.setOnClickListener {
            resetAutoCollapse()
            session.setAntiMistouch(guardToggle.isChecked)
        }

        val btToggle = view.findViewById<ToggleButton>(R.id.toggleBt)
        btToggle.isChecked = false
        btToggle.setOnClickListener {
            resetAutoCollapse()
            val ok = session.setBluetoothOff(btToggle.isChecked)
            if (!ok) {
                btToggle.isChecked = false
                Toast.makeText(this, "Bluetooth permission denied", Toast.LENGTH_SHORT).show()
            }
        }

        view.setOnTouchListener { _, _ -> resetAutoCollapse(); false }

        windowManager.addView(view, params)
    }

    private fun positionPanel(params: WindowManager.LayoutParams) {
        val screenW = resources.displayMetrics.widthPixels
        val bx = bubbleParams?.x ?: 0
        val by = bubbleParams?.y ?: dp(160)
        val panelW = dp(156)
        val onLeft = bx < screenW / 2
        params.x = if (onLeft) dp(8) else (screenW - panelW - dp(8)).coerceAtLeast(0)
        params.y = by.coerceIn(dp(48), resources.displayMetrics.heightPixels - dp(220))
    }

    private fun removePanel() {
        panelView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        panelView = null
    }

    // ---------- Boost ----------

    private fun runBoost(silent: Boolean) {
        if (boosting) return
        boosting = true
        val resultView = panelView?.findViewById<TextView>(R.id.tvBoostResult)
        if (!silent) {
            resultView?.visibility = View.VISIBLE
            resultView?.text = "Closing apps…"
        }
        thread {
            val plan = BoosterUtils.plan(this, gamePackage)
            val soft = BoosterUtils.softKill(this, plan.targets)
            val force = Prefs.isForceCloseEnabled(this)
            val access = BoostAccessibilityService.isConnected()

            if (force && access && plan.targets.isNotEmpty()) {
                val latch = CountDownLatch(1)
                val closed = java.util.concurrent.atomic.AtomicInteger(0)
                handler.post {
                    BoostAccessibilityService.instance?.startBoost(plan.targets, gamePackage) {
                        closed.set(it)
                        latch.countDown()
                    } ?: latch.countDown()
                }
                val finished = latch.await(22, TimeUnit.SECONDS)
                if (!finished) {
                    handler.post { setHiddenForBoost(false) }
                }
                val result = BoosterUtils.resultAfter(
                    this, plan, closed.get().coerceAtLeast(soft),
                    "force"
                )
                handler.post { onBoostDone(result, silent) }
            } else {
                val result = BoosterUtils.resultAfter(this, plan, soft, if (access) "soft" else "no-access")
                handler.post { onBoostDone(result, silent) }
            }
        }
    }

    private fun onBoostDone(result: BoosterUtils.BoostResult, silent: Boolean) {
        boosting = false
        lastBoostFreedMb += result.freedMb
        if (silent) {
            updateStats()
            return
        }
        val resultView = panelView?.findViewById<TextView>(R.id.tvBoostResult)
        resultView?.visibility = View.VISIBLE
        resultView?.text = when {
            result.method == "no-access" && result.closedCount == 0 ->
                "Enable Accessibility to force-close"
            result.consideredCount == 0 ->
                "Nothing to close"
            else ->
                "Closed ${result.closedCount} · +${result.freedMb} MB"
        }
        updateStats()
        resetAutoCollapse()
        if (result.method == "no-access") {
            Toast.makeText(
                this,
                "Turn on Accessibility (Game Turbo) so Boost can actually close apps",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun requestBatteryExemption() {
        val target = gamePackage ?: run {
            Toast.makeText(this, "No game detected yet", Toast.LENGTH_SHORT).show()
            return
        }
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(target)) {
            Toast.makeText(this, "Already unrestricted", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
            data = Uri.parse("package:$target")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "Couldn't open battery settings", Toast.LENGTH_SHORT).show()
        }
    }

    private fun scheduleAutoCollapse() {
        handler.postDelayed(collapseOnIdle, AUTO_COLLAPSE_MS)
    }

    private fun resetAutoCollapse() {
        handler.removeCallbacks(collapseOnIdle)
        scheduleAutoCollapse()
    }

    // ---------- Stats ----------

    private fun updateBubblePing() {
        val view = bubbleView ?: return
        val label = view.findViewById<TextView>(R.id.tvBubbleLabel)
        if (lastPingMs > 0) {
            label.text = lastPingMs.toString()
        }
        thread {
            val (host, port) = NetworkMonitor.pingHostForGame(gamePackage)
            val rtt = NetworkMonitor.pingMs(host, port, 900)
            handler.post {
                if (rtt >= 0) {
                    lastPingMs = rtt
                    label.text = rtt.toString()
                    val color = when {
                        rtt <= 60 -> 0xFF5EEAD4.toInt()
                        rtt <= 120 -> 0xFFE8D48B.toInt()
                        else -> 0xFFFF7A7A.toInt()
                    }
                    label.setTextColor(color)
                }
            }
        }
    }

    private fun updateStats() {
        val view = panelView ?: return
        val freeMb = BoosterUtils.freeRamMb(this)
        view.findViewById<TextView>(R.id.tvRam).text = "${freeMb}M"
        val link = NetworkMonitor.linkInfo(this)
        view.findViewById<TextView>(R.id.tvNetwork).text = link.type

        val pingView = view.findViewById<TextView>(R.id.tvPing)
        pingView.text = if (lastPingMs > 0) "${lastPingMs}ms" else "…"
        val generation = ++pingGeneration
        thread {
            val (host, port) = NetworkMonitor.pingHostForGame(gamePackage)
            val stats = NetworkMonitor.measurePingStats(host, port, probes = 3)
            handler.post {
                if (generation != pingGeneration) return@post
                if (!stats.reachable) {
                    pingView.text = "timeout"
                    pingView.setTextColor(0xFFFF7A7A.toInt())
                    return@post
                }
                lastPingMs = stats.avgMs
                val color = when {
                    stats.avgMs <= 60 && stats.jitterMs <= 15 && stats.lossPercent == 0 ->
                        0xFF5EEAD4.toInt()
                    stats.avgMs <= 120 && stats.jitterMs <= 30 ->
                        0xFFE8D48B.toInt()
                    else -> 0xFFFF7A7A.toInt()
                }
                pingView.setTextColor(color)
                pingView.text = "${stats.avgMs}ms"
                bubbleView?.findViewById<TextView>(R.id.tvBubbleLabel)?.apply {
                    text = stats.avgMs.toString()
                    setTextColor(color)
                }
            }
        }
    }

    private fun overlayType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Game Turbo", NotificationManager.IMPORTANCE_MIN
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Game Turbo active")
            .setContentText("Edge bubble · tap to boost")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
    }

    companion object {
        const val EXTRA_GAME_PACKAGE = "extra_game_package"
        @Volatile
        var instance: OverlayService? = null
            private set
        private const val CHANNEL_ID = "overlay_channel"
        private const val NOTIF_ID = 1002
        private const val STATS_INTERVAL_MS = 4000L
        private const val AUTO_COLLAPSE_MS = 7000L
        private const val PEEK_DELAY_MS = 1800L
        private const val BUBBLE_DP = 36
    }
}
