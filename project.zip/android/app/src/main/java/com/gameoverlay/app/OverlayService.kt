package com.gameoverlay.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.util.TypedValue
import android.view.Display
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import android.widget.ToggleButton
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import kotlin.concurrent.thread
import kotlin.math.abs
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var panelView: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private lateinit var session: SessionEngine

    private val handler = Handler(Looper.getMainLooper())
    private var expanded = false
    private var hiddenForBoost = false
    private var gamePackage: String? = null
    private var sessionStartMs = 0L
    private var lastBoostFreedMb = 0L
    private var autoModeApplied = false
    private var pingGeneration = 0
    private var fpsPollGeneration = 0
    private var lastPingMs: Long = -1
    private var boosting = false
    private var peeking = true
    private var preWarpPingMs: Long = -1
    private var preWarpHost: String? = null
    private var crosshairView: View? = null
    private var tickerView: View? = null
    private var brightnessLocked = false
    private var thermalWarned = false

    private val statsRunnable = object : Runnable {
        override fun run() {
            updateBubblePing()
            if (expanded) updateStats()
            handler.postDelayed(this, STATS_INTERVAL_MS)
        }
    }

    private val collapseOnIdle = Runnable { setExpanded(false) }
    private val peekRunnable = Runnable { peekToEdge() }

    override fun onCreate() {
        super.onCreate()
        instance = this
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        session = SessionEngine(this)
        createChannel()
        startForeground(NOTIF_ID, buildNotification())
        sessionStartMs = System.currentTimeMillis()
        // WIFI_MODE_FULL_LOW_LATENCY + a partial wake lock stop the radio from
        // power-saving between packets and stop Doze from parking the CPU —
        // both are free wins for ping/jitter, so grab them for every game
        // session, not only when "Auto-optimize" is switched on.
        session.acquireWifiLock()
        session.acquireWakeLock()
        if (Prefs.isRefreshRateLockEnabled(this)) {
            GameModeController.lockRefreshRate(Prefs.getRefreshRateHz(this))
        }
        if (Prefs.isGamingDnsEnabled(this)) {
            applyGamingDns()
        }
        if (Prefs.isPerfModeEnabled(this)) {
            GameModeController.setPerformanceMode(true) { ok ->
                if (!ok) handler.post {
                    Toast.makeText(
                        this,
                        "Performance mode not supported on this device/ROM",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
        addBubble()
        if (Prefs.isCrosshairEnabled(this)) addCrosshair()
        if (Prefs.isBrightnessLockEnabled(this)) applyBrightnessLock(true)
        handler.post(statsRunnable)
        handler.postDelayed(peekRunnable, PEEK_DELAY_MS)
    }

    /**
     * Applies Private DNS for the session according to the user's chosen provider:
     *  - "cloudflare" / "nextdns": switch straight to that hostname, no measurement.
     *  - "auto": benchmark every configured candidate's DoT port (853) right now, on
     *    this network, and use whichever answered fastest. This is deliberately run
     *    fresh every session start rather than cached — "NextDNS was faster on my home
     *    Wi-Fi" tells you nothing about the mobile-data network you're on at a friend's
     *    house. See NetworkMonitor.benchmarkDnsProviders for what this measurement
     *    actually is (DoT TCP-connect time, not a real DNS query).
     * Falls back to Cloudflare if NextDNS is selected/auto but no config ID is set.
     */
    private fun applyGamingDns() {
        val provider = Prefs.getDnsProvider(this)
        val nextDnsHost = NetworkMonitor.nextDnsHost(Prefs.getNextDnsId(this))
        when (provider) {
            "nextdns" -> {
                val host = nextDnsHost ?: NetworkMonitor.CLOUDFLARE_DNS_HOST
                if (nextDnsHost == null) {
                    Toast.makeText(this, "No NextDNS config ID set — using Cloudflare", Toast.LENGTH_LONG).show()
                }
                GameModeController.setGamingDns(host)
            }
            "auto" -> {
                val candidates = mutableListOf(
                    NetworkMonitor.DnsCandidate("Cloudflare", NetworkMonitor.CLOUDFLARE_DNS_HOST)
                )
                if (nextDnsHost != null) {
                    candidates.add(NetworkMonitor.DnsCandidate("NextDNS", nextDnsHost))
                }
                thread {
                    val result = NetworkMonitor.benchmarkDnsProviders(candidates)
                    val summary = if (result.results.size > 1) {
                        result.results.joinToString(" vs ") { (c, s) ->
                            "${c.label} ${if (s.reachable) "${s.avgMs}ms" else "timeout"}"
                        }
                    } else {
                        "${result.winner.label} only (no NextDNS ID set)"
                    }
                    Prefs.setLastDnsWinner(this, "${result.winner.label} — $summary")
                    GameModeController.setGamingDns(result.winner.hostname)
                }
            }
            else -> GameModeController.setGamingDns(NetworkMonitor.CLOUDFLARE_DNS_HOST)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val pkg = intent?.getStringExtra(EXTRA_GAME_PACKAGE)
        if (pkg != null && pkg != gamePackage) {
            gamePackage = pkg
            if (!autoModeApplied) {
                autoModeApplied = true
                applyAutoModeOnce()
            }
        }
        return START_STICKY
    }

    private fun applyAutoModeOnce() {
        if (!Prefs.isAutoModeEnabled(this)) return
        session.startSession()
        if (DndController.hasAccess(this)) DndController.enable(this)
        thread { runBoost(silent = true) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        if (instance === this) instance = null
        handler.removeCallbacksAndMessages(null)
        showSessionSummary()
        DndController.revert(this)
        session.endSession()
        if (Prefs.isRefreshRateLockEnabled(this)) GameModeController.restoreRefreshRate()
        if (Prefs.isGamingDnsEnabled(this)) GameModeController.restoreDns()
        // Always attempt to un-pin performance mode, even if the pref was flipped off
        // mid-session — a stuck fixed-clock state is worse than a redundant shell call.
        GameModeController.setPerformanceMode(false)
        removeCrosshair()
        hideTicker()
        removePanel()
        bubbleView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        bubbleView = null
        super.onDestroy()
    }

    private fun showSessionSummary() {
        val minutes = ((System.currentTimeMillis() - sessionStartMs) / 60000).coerceAtLeast(0)
        Toast.makeText(
            this,
            "Session ${minutes}m · ~${lastBoostFreedMb} MB freed",
            Toast.LENGTH_LONG
        ).show()
    }

    fun setHiddenForBoost(hidden: Boolean) {
        handler.post {
            hiddenForBoost = hidden
            if (hidden) {
                bubbleView?.visibility = View.GONE
                panelView?.visibility = View.GONE
            } else {
                if (expanded) {
                    panelView?.visibility = View.VISIBLE
                } else {
                    bubbleView?.visibility = View.VISIBLE
                }
            }
        }
    }

    // ---------- Bubble (Xiaomi-style: small, docks, half-hides) ----------

    private fun addBubble() {
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_bubble, null)
        bubbleView = view

        val type = overlayType()
        val params = WindowManager.LayoutParams(
            dp(BUBBLE_DP),
            dp(BUBBLE_DP),
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 0
        params.y = dp(160)
        bubbleParams = params

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false

        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    handler.removeCallbacks(peekRunnable)
                    peeking = false
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (abs(dx) > 8 || abs(dy) > 8) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    try { windowManager.updateViewLayout(view, params) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) v.performClick()
                    else snapToEdge()
                    true
                }
                else -> false
            }
        }
        view.setOnClickListener { setExpanded(true) }

        windowManager.addView(view, params)
    }

    private fun snapToEdge() {
        val params = bubbleParams ?: return
        val view = bubbleView ?: return
        val screenW = resources.displayMetrics.widthPixels
        val size = view.width.coerceAtLeast(dp(BUBBLE_DP))
        params.x = if (params.x + size / 2 < screenW / 2) 0 else screenW - size
        params.y = params.y.coerceIn(dp(24), resources.displayMetrics.heightPixels - size - dp(24))
        try { windowManager.updateViewLayout(view, params) } catch (_: Exception) {}
        handler.removeCallbacks(peekRunnable)
        handler.postDelayed(peekRunnable, PEEK_DELAY_MS)
    }

    /** Slide ~45% of the bubble off-screen, Xiaomi Game Turbo style. */
    private fun peekToEdge() {
        if (expanded || hiddenForBoost) return
        val params = bubbleParams ?: return
        val view = bubbleView ?: return
        val screenW = resources.displayMetrics.widthPixels
        val size = view.width.coerceAtLeast(dp(BUBBLE_DP))
        val hide = (size * 0.46f).toInt()
        params.x = if (params.x + size / 2 < screenW / 2) -hide else screenW - size + hide
        peeking = true
        try { windowManager.updateViewLayout(view, params) } catch (_: Exception) {}
    }

    // ---------- Compact panel ----------

    private fun setExpanded(show: Boolean) {
        expanded = show
        handler.removeCallbacks(collapseOnIdle)
        handler.removeCallbacks(peekRunnable)
        if (show) {
            peeking = false
            if (panelView == null) addPanel()
            bubbleView?.visibility = View.GONE
            updateStats()
            scheduleAutoCollapse()
        } else {
            removePanel()
            if (!hiddenForBoost) bubbleView?.visibility = View.VISIBLE
            handler.postDelayed(peekRunnable, PEEK_DELAY_MS)
        }
    }

    private fun addPanel() {
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_panel, null)
        panelView = view

        val type = overlayType()
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        positionPanel(params)

        view.findViewById<View>(R.id.btnCollapse).setOnClickListener { setExpanded(false) }

        view.findViewById<View>(R.id.btnBoost).setOnClickListener {
            resetAutoCollapse()
            runBoost(silent = false)
        }
        view.findViewById<View>(R.id.btnBoost).setOnLongClickListener {
            resetAutoCollapse()
            requestBatteryExemption()
            true
        }

        val dndToggle = view.findViewById<ToggleButton>(R.id.toggleDnd)
        dndToggle.isChecked = DndController.isDndOn(this)
        dndToggle.setOnClickListener {
            resetAutoCollapse()
            if (!DndController.hasAccess(this)) {
                dndToggle.isChecked = false
                Toast.makeText(this, "Grant DND access in Game Turbo", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (dndToggle.isChecked) DndController.enable(this) else DndController.disable(this)
        }

        val wifiToggle = view.findViewById<ToggleButton>(R.id.toggleWifiLock)
        wifiToggle.isChecked = session.wifiHeld
        wifiToggle.setOnClickListener {
            resetAutoCollapse()
            if (wifiToggle.isChecked) session.acquireWifiLock() else session.releaseWifiLock()
        }

        val guardToggle = view.findViewById<ToggleButton>(R.id.toggleGuard)
        guardToggle.isChecked = session.antiMistouchOn || Prefs.isAntiMistouchEnabled(this)
        guardToggle.setOnClickListener {
            resetAutoCollapse()
            session.setAntiMistouch(guardToggle.isChecked)
        }

        val btToggle = view.findViewById<ToggleButton>(R.id.toggleBt)
        btToggle.isChecked = false
        btToggle.setOnClickListener {
            resetAutoCollapse()
            val wantOff = btToggle.isChecked
            btToggle.isEnabled = false
            // setBluetoothOff may now block briefly on a Shizuku shell round-trip
            // (svc bluetooth), so it must never run on the UI thread — do it in
            // the background and only touch views in the callback below.
            thread {
                val ok = session.setBluetoothOff(wantOff)
                handler.post {
                    btToggle.isEnabled = true
                    if (!ok) {
                        // No Shizuku and Android 13+ blocks silent BT toggling entirely —
                        // this isn't a permission problem, so don't tell the user to grant one.
                        btToggle.isChecked = !wantOff
                        session.openBluetoothPanel()
                        Toast.makeText(this, "Tap the Bluetooth switch that just opened", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }

        val rotationToggle = view.findViewById<ToggleButton>(R.id.toggleRotation)
        rotationToggle.isChecked = session.rotationLocked
        rotationToggle.setOnClickListener {
            resetAutoCollapse()
            if (!session.canWriteSettings()) {
                rotationToggle.isChecked = false
                Toast.makeText(this, "Grant Modify system settings in Game Turbo", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            val wantLocked = rotationToggle.isChecked
            val ok = session.setRotationLock(wantLocked)
            // Verify against the real system value instead of trusting our own call —
            // if the write silently didn't apply, the toggle shouldn't lie about it.
            val actuallyLocked = session.rotationLocked
            if (!ok || actuallyLocked != wantLocked) {
                rotationToggle.isChecked = actuallyLocked
                Toast.makeText(this, "Rotation lock write failed", Toast.LENGTH_SHORT).show()
            } else {
                Prefs.setRotationLockSessionEnabled(this, wantLocked)
                Toast.makeText(
                    this,
                    if (wantLocked) "Rotation locked (system-wide)" else "Rotation unlocked",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        val crosshairToggle = view.findViewById<ToggleButton>(R.id.toggleCrosshair)
        crosshairToggle.isChecked = crosshairView != null
        crosshairToggle.setOnClickListener {
            resetAutoCollapse()
            val want = crosshairToggle.isChecked
            if (want) addCrosshair() else removeCrosshair()
            Prefs.setCrosshairEnabled(this, want)
        }

        val brightnessToggle = view.findViewById<ToggleButton>(R.id.toggleBrightness)
        brightnessToggle.isChecked = brightnessLocked
        brightnessToggle.setOnClickListener {
            resetAutoCollapse()
            val want = brightnessToggle.isChecked
            applyBrightnessLock(want)
            Prefs.setBrightnessLockEnabled(this, want)
        }

        val tickerToggle = view.findViewById<ToggleButton>(R.id.toggleTicker)
        tickerToggle.isChecked = Prefs.isTickerEnabled(this)
        tickerToggle.setOnClickListener {
            resetAutoCollapse()
            val want = tickerToggle.isChecked
            if (want && !hasNotificationAccess()) {
                tickerToggle.isChecked = false
                Toast.makeText(this, "Grant Notification access, then try again", Toast.LENGTH_LONG).show()
                try {
                    val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                } catch (_: Exception) {
                }
                return@setOnClickListener
            }
            Prefs.setTickerEnabled(this, want)
            if (!want) hideTicker()
        }

        val warpButton = view.findViewById<View>(R.id.btnWarp)
        val warpResultView = view.findViewById<TextView>(R.id.tvWarpResult)
        warpButton.setOnClickListener {
            resetAutoCollapse()
            val (host, port) = NetworkMonitor.pingHostForGame(gamePackage)
            warpResultView.visibility = View.VISIBLE

            if (!NetworkMonitor.isAnyVpnActive(this)) {
                // No tunnel active yet: take the baseline reading now, then hand off to
                // WARP's own app — we can't drive its connect toggle ourselves, only the
                // player can tap it, since it's a system VPN permission prompt.
                warpResultView.text = "Measuring baseline…"
                thread {
                    val stats = NetworkMonitor.measurePingStats(host, port, probes = 3)
                    preWarpPingMs = if (stats.reachable) stats.avgMs else -1
                    preWarpHost = host
                    handler.post {
                        warpResultView.text = if (preWarpPingMs > 0)
                            "Baseline ${preWarpPingMs}ms. Connect WARP, then tap this again."
                        else
                            "Baseline unreachable. Connect WARP, then tap this again."
                        NetworkMonitor.openWarpOrStore(this)
                    }
                }
            } else {
                // Tunnel is active now: re-measure the SAME host so it's a fair comparison,
                // not a different game server responding differently.
                val compareHost = preWarpHost ?: host
                warpResultView.text = "Re-measuring with WARP…"
                thread {
                    val stats = NetworkMonitor.measurePingStats(compareHost, port, probes = 3)
                    val afterMs = if (stats.reachable) stats.avgMs else -1
                    handler.post {
                        warpResultView.text = when {
                            preWarpPingMs <= 0 || afterMs <= 0 ->
                                "With WARP: ${if (afterMs > 0) "${afterMs}ms" else "unreachable"}"
                            afterMs < preWarpPingMs - 5 ->
                                "Before ${preWarpPingMs}ms → WARP ${afterMs}ms — keep it on"
                            afterMs > preWarpPingMs + 5 ->
                                "Before ${preWarpPingMs}ms → WARP ${afterMs}ms — worse, turn it off"
                            else ->
                                "Before ${preWarpPingMs}ms → WARP ${afterMs}ms — no real difference"
                        }
                        preWarpPingMs = -1
                        preWarpHost = null
                    }
                }
            }
        }

        view.setOnTouchListener { _, _ -> resetAutoCollapse(); false }

        windowManager.addView(view, params)
    }

    private fun positionPanel(params: WindowManager.LayoutParams) {
        val screenW = resources.displayMetrics.widthPixels
        val bx = bubbleParams?.x ?: 0
        val by = bubbleParams?.y ?: dp(160)
        val panelW = dp(156)
        val onLeft = bx < screenW / 2
        params.x = if (onLeft) dp(8) else (screenW - panelW - dp(8)).coerceAtLeast(0)
        params.y = by.coerceIn(dp(48), resources.displayMetrics.heightPixels - dp(220))
    }

    private fun removePanel() {
        panelView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        panelView = null
    }

    // ---------- Crosshair ----------

    private fun addCrosshair() {
        if (crosshairView != null) return
        val view = CrosshairView(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            // NOT_TOUCHABLE is the important flag here — this window must never
            // receive a touch, or it would block taps meant for the game underneath.
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.CENTER
        try {
            windowManager.addView(view, params)
            crosshairView = view
        } catch (_: Exception) {
        }
    }

    private fun removeCrosshair() {
        crosshairView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        crosshairView = null
    }

    // ---------- Brightness lock ----------

    // Freezes brightness by setting an explicit value on our own overlay window's
    // LayoutParams — a per-window override the system honors without any special
    // permission, unlike writing Settings.System directly. Reading the current
    // value first (rather than hardcoding "max") means turning this on doesn't
    // itself change how bright the screen looks, only stops it drifting from there.
    private fun applyBrightnessLock(enable: Boolean) {
        val params = bubbleParams ?: return
        params.screenBrightness = if (enable) {
            val current = try {
                Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
            } catch (_: Exception) {
                128
            }
            (current / 255f).coerceIn(0.05f, 1f)
        } else {
            WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        }
        try {
            bubbleView?.let { windowManager.updateViewLayout(it, params) }
        } catch (_: Exception) {
        }
        brightnessLocked = enable
    }

    // ---------- Notification ticker ----------

    private val tickerHideRunnable = Runnable { hideTicker() }

    /** Called from TickerNotificationListenerService. Shows title/text for a few
     *  seconds at the top of the screen, then drops it — nothing is retained. */
    fun showTicker(title: String, text: String) {
        handler.post {
            if (!Prefs.isTickerEnabled(this)) return@post
            val combined = when {
                title.isNotEmpty() && text.isNotEmpty() -> "$title: $text"
                title.isNotEmpty() -> title
                else -> text
            }
            val shown = if (combined.length > 60) combined.take(57) + "…" else combined

            val view = tickerView ?: run {
                val v = LayoutInflater.from(this).inflate(R.layout.overlay_ticker, null)
                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    overlayType(),
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                )
                params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                params.y = dp(28)
                try {
                    windowManager.addView(v, params)
                    tickerView = v
                } catch (_: Exception) {
                }
                v
            }
            (view as? TextView)?.text = shown
            handler.removeCallbacks(tickerHideRunnable)
            handler.postDelayed(tickerHideRunnable, TICKER_VISIBLE_MS)
        }
    }

    private fun hideTicker() {
        handler.removeCallbacks(tickerHideRunnable)
        tickerView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        tickerView = null
    }

    private fun hasNotificationAccess(): Boolean {
        return try {
            NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        } catch (_: Exception) {
            false
        }
    }

    // ---------- Boost ----------

    private fun runBoost(silent: Boolean) {
        if (boosting) return
        boosting = true
        val resultView = panelView?.findViewById<TextView>(R.id.tvBoostResult)
        if (!silent) {
            resultView?.visibility = View.VISIBLE
            resultView?.text = "Closing apps…"
        }
        thread {
            val plan = BoosterUtils.plan(this, gamePackage)

            // Shizuku path: instant `am force-stop`, no Accessibility taps,
            // no visible flicker. Preferred whenever the user has granted it.
            if (GameModeController.available() && plan.targets.isNotEmpty()) {
                var closed = 0
                for (pkg in plan.targets) {
                    val (code, _) = ShizukuManager.exec("am force-stop $pkg")
                    if (code == 0) closed++
                }
                BoosterUtils.softKill(this, plan.targets)
                val result = BoosterUtils.resultAfter(this, plan, closed, "shizuku")
                handler.post { onBoostDone(result, silent) }
                return@thread
            }

            val soft = BoosterUtils.softKill(this, plan.targets)
            val force = Prefs.isForceCloseEnabled(this)
            val access = BoostAccessibilityService.isConnected()

            if (force && access && plan.targets.isNotEmpty()) {
                val latch = CountDownLatch(1)
                val closed = java.util.concurrent.atomic.AtomicInteger(0)
                handler.post {
                    BoostAccessibilityService.instance?.startBoost(plan.targets, gamePackage) {
                        closed.set(it)
                        latch.countDown()
                    } ?: latch.countDown()
                }
                val finished = latch.await(22, TimeUnit.SECONDS)
                if (!finished) {
                    handler.post { setHiddenForBoost(false) }
                }
                val result = BoosterUtils.resultAfter(
                    this, plan, closed.get().coerceAtLeast(soft),
                    "force"
                )
                handler.post { onBoostDone(result, silent) }
            } else {
                val result = BoosterUtils.resultAfter(this, plan, soft, if (access) "soft" else "no-access")
                handler.post { onBoostDone(result, silent) }
            }
        }
    }

    private fun onBoostDone(result: BoosterUtils.BoostResult, silent: Boolean) {
        boosting = false
        lastBoostFreedMb += result.freedMb
        if (silent) {
            updateStats()
            return
        }
        val resultView = panelView?.findViewById<TextView>(R.id.tvBoostResult)
        resultView?.visibility = View.VISIBLE
        resultView?.text = when {
            result.method == "no-access" && result.closedCount == 0 ->
                "Enable Accessibility to force-close"
            result.consideredCount == 0 ->
                "Nothing to close"
            else ->
                "Closed ${result.closedCount} · +${result.freedMb} MB"
        }
        updateStats()
        resetAutoCollapse()
        if (result.method == "no-access") {
            Toast.makeText(
                this,
                "Turn on Accessibility (Game Turbo) so Boost can actually close apps",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun requestBatteryExemption() {
        val target = gamePackage ?: run {
            Toast.makeText(this, "No game detected yet", Toast.LENGTH_SHORT).show()
            return
        }
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(target)) {
            Toast.makeText(this, "Already unrestricted", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
            data = Uri.parse("package:$target")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "Couldn't open battery settings", Toast.LENGTH_SHORT).show()
        }
    }

    private fun scheduleAutoCollapse() {
        handler.postDelayed(collapseOnIdle, AUTO_COLLAPSE_MS)
    }

    private fun resetAutoCollapse() {
        handler.removeCallbacks(collapseOnIdle)
        scheduleAutoCollapse()
    }

    // ---------- Stats ----------

    private fun updateBubblePing() {
        val view = bubbleView ?: return
        val label = view.findViewById<TextView>(R.id.tvBubbleLabel)
        if (lastPingMs > 0) {
            label.text = lastPingMs.toString()
        }
        thread {
            val (host, port) = NetworkMonitor.pingHostForGame(gamePackage)
            val rtt = NetworkMonitor.pingMs(host, port, 900)
            handler.post {
                if (rtt >= 0) {
                    lastPingMs = rtt
                    label.text = rtt.toString()
                    val color = when {
                        rtt <= 60 -> 0xFF5EEAD4.toInt()
                        rtt <= 120 -> 0xFFE8D48B.toInt()
                        else -> 0xFFFF7A7A.toInt()
                    }
                    label.setTextColor(color)
                }
            }
        }
    }

    private fun updateStats() {
        val view = panelView ?: return
        val freeMb = BoosterUtils.freeRamMb(this)
        view.findViewById<TextView>(R.id.tvRam).text = "${freeMb}M"
        val link = NetworkMonitor.linkInfo(this)
        val networkView = view.findViewById<TextView>(R.id.tvNetwork)
        val rr = refreshRateLabel()
        // Placeholder shown immediately; replaced below with real per-app frame
        // data if Shizuku is available, so the panel never sits blank while we wait.
        networkView.text = if (rr.isNotEmpty()) "${link.type} · $rr" else link.type

        val pkg = gamePackage
        if (pkg != null && GameModeController.available()) {
            val fpsGeneration = ++fpsPollGeneration
            GameModeController.frameStats(pkg) { stats ->
                handler.post {
                    if (fpsGeneration != fpsPollGeneration) return@post
                    if (stats != null) {
                        // Real measured frame data (dumpsys gfxinfo), not the screen's
                        // configured refresh rate — see GameModeController.frameStats.
                        networkView.text = "${link.type} · ~${stats.estimatedFps}fps · " +
                            "${"%.1f".format(stats.jankyPercent)}% jank"
                        networkView.setTextColor(
                            when {
                                stats.jankyPercent <= 2.0 -> 0xFF5EEAD4.toInt()
                                stats.jankyPercent <= 8.0 -> 0xFFE8D48B.toInt()
                                else -> 0xFFFF7A7A.toInt()
                            }
                        )
                    }
                    // If stats == null (no Shizuku data yet, e.g. game just launched),
                    // leave the refresh-rate placeholder in place rather than showing
                    // nothing — but never relabel it as FPS.
                }
            }
        }

        val thermalView = view.findViewById<TextView>(R.id.tvThermal)
        val thermalLabel = session.thermalStatusLabel()
        if (thermalLabel != null) {
            thermalView.visibility = View.VISIBLE
            thermalView.text = thermalLabel
            thermalView.setTextColor(
                when (thermalLabel) {
                    "Cool" -> 0xFF8A8F98.toInt() // neutral — nothing to warn about
                    "Warm" -> 0xFFFFC24B.toInt() // earliest warning: mild amber
                    "Hot" -> 0xFFFF9800.toInt() // orange
                    "Throttling" -> 0xFFFF5A36.toInt() // red-orange
                    else -> 0xFFFF3B30.toInt() // "Overheating" — full red
                }
            )
        } else {
            thermalView.visibility = View.GONE
        }

        // Charging while hot is what actually drives thermal throttling during long
        // sessions — warn once per elevated spell, not every 4s refresh, and reset
        // as soon as it cools back down so a later real spike warns again.
        val elevated = thermalLabel == "Hot" || thermalLabel == "Throttling" || thermalLabel == "Overheating"
        if (elevated && isCharging() && !thermalWarned) {
            thermalWarned = true
            Toast.makeText(
                this,
                "Getting hot while charging — consider unplugging or turning off fast charging",
                Toast.LENGTH_LONG
            ).show()
        } else if (!elevated) {
            thermalWarned = false
        }

        val pingView = view.findViewById<TextView>(R.id.tvPing)
        pingView.text = if (lastPingMs > 0) "${lastPingMs}ms" else "…"
        val generation = ++pingGeneration
        thread {
            val (host, port) = NetworkMonitor.pingHostForGame(gamePackage)
            val stats = NetworkMonitor.measurePingStats(host, port, probes = 3)
            handler.post {
                if (generation != pingGeneration) return@post
                if (!stats.reachable) {
                    pingView.text = "timeout"
                    pingView.setTextColor(0xFFFF7A7A.toInt())
                    return@post
                }
                lastPingMs = stats.avgMs
                val color = when {
                    stats.avgMs <= 60 && stats.jitterMs <= 15 && stats.lossPercent == 0 ->
                        0xFF5EEAD4.toInt()
                    stats.avgMs <= 120 && stats.jitterMs <= 30 ->
                        0xFFE8D48B.toInt()
                    else -> 0xFFFF7A7A.toInt()
                }
                pingView.setTextColor(color)
                pingView.text = "${stats.avgMs}ms"
                bubbleView?.findViewById<TextView>(R.id.tvBubbleLabel)?.apply {
                    text = stats.avgMs.toString()
                    setTextColor(color)
                }
            }
        }
    }

    private fun overlayType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
    }

    private fun isCharging(): Boolean {
        return try {
            val intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1) ?: -1
            plugged != 0
        } catch (_: Exception) {
            false
        }
    }

    // This is the display's configured refresh rate (a real value from the OS), NOT
    // the game's actual rendered frame rate — Android gives no public API to measure
    // another app's real FPS without root or a Shizuku/SurfaceFlinger bridge, so this
    // is labeled honestly as the screen's rate rather than presented as "your FPS".
    private fun refreshRateLabel(): String {
        return try {
            val dm = getSystemService(DISPLAY_SERVICE) as DisplayManager
            val display = dm.getDisplay(Display.DEFAULT_DISPLAY)
            "${display.refreshRate.toInt()}Hz"
        } catch (_: Exception) {
            ""
        }
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Game Turbo", NotificationManager.IMPORTANCE_MIN
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Game Turbo active")
            .setContentText("Edge bubble · tap to boost")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
    }

    companion object {
        const val EXTRA_GAME_PACKAGE = "extra_game_package"
        @Volatile
        var instance: OverlayService? = null
            private set
        private const val CHANNEL_ID = "overlay_channel"
        private const val NOTIF_ID = 1002
        private const val STATS_INTERVAL_MS = 4000L
        private const val AUTO_COLLAPSE_MS = 7000L
        private const val PEEK_DELAY_MS = 1800L
        private const val BUBBLE_DP = 36
        private const val TICKER_VISIBLE_MS = 4000L
    }
}
