package com.gameoverlay.app

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.abs

object NetworkMonitor {

    data class LinkInfo(
        val type: String,
        val detail: String,
        val rssi: Int?,
        val isFastBand: Boolean
    )

    fun connectionType(context: Context): String = linkInfo(context).type

    fun linkInfo(context: Context): LinkInfo {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
        val caps = network?.let { cm.getNetworkCapabilities(it) }
        if (caps == null) return LinkInfo("Offline", "No connection", null, false)
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> {
                val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION")
                val info = wm.connectionInfo
                val rssi = info?.rssi
                val freq = info?.frequency ?: 0
                val mbps = info?.linkSpeed ?: 0
                val band = when {
                    freq >= 5900 -> "6 GHz"
                    freq >= 4900 -> "5 GHz"
                    freq > 0 -> "2.4 GHz"
                    else -> "Wi-Fi"
                }
                val fast = freq >= 4900
                LinkInfo(
                    "Wi-Fi",
                    "$band · ${mbps} Mbps" + (rssi?.let { " · $it dBm" } ?: ""),
                    rssi,
                    fast
                )
            }
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ->
                LinkInfo("Mobile", "Mobile data", null, false)
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ->
                LinkInfo("Ethernet", "Ethernet", null, true)
            else -> LinkInfo("On", "Connected", null, false)
        }
    }

    fun pingHostForGame(packageName: String?): Pair<String, Int> {
        val pkg = packageName ?: return "1.1.1.1" to 443
        val host = when {
            pkg.contains("freefire") -> "common-lb.freefiremobile.com"
            pkg.contains("pubg") || pkg.contains("tencent.ig") || pkg.endsWith(".ig") ->
                "match.igamecj.com"
            pkg.contains("callofduty") || pkg.contains("codm") -> "codm.activision.com"
            pkg.contains("mobilelegends") || pkg.contains("mobile.legends") || pkg.contains("mlbb") ->
                "api.mobilelegends.com"
            pkg.contains("roblox") -> "clientsettings.roblox.com"
            pkg.contains("fortnite") || pkg.contains("epicgames") -> "fortnite-public-service-prod.ol.epicgames.com"
            pkg.contains("genshin") || pkg.contains("yuanshen") -> "sg-public-data-api.hoyoverse.com"
            pkg.contains("league") || pkg.contains("wildrift") -> "wildrift.leagueoflegends.com"
            pkg.contains("efootball") || pkg.contains("pes") -> "efootball.konami.net"
            else -> "1.1.1.1"
        }
        return host to 443
    }

    fun pingMs(host: String = "1.1.1.1", port: Int = 443, timeoutMs: Int = 1200): Long {
        return try {
            val start = System.currentTimeMillis()
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), timeoutMs)
            }
            System.currentTimeMillis() - start
        } catch (_: Exception) {
            -1L
        }
    }

    data class PingStats(
        val host: String,
        val probesSent: Int,
        val probesOk: Int,
        val minMs: Long,
        val avgMs: Long,
        val maxMs: Long,
        val jitterMs: Long
    ) {
        val lossPercent: Int
            get() = if (probesSent == 0) 0 else ((probesSent - probesOk) * 100) / probesSent
        val reachable: Boolean get() = probesOk > 0
    }

    fun measurePingStats(
        host: String = "1.1.1.1",
        port: Int = 443,
        probes: Int = 3,
        intervalMs: Long = 160,
        timeoutMs: Int = 1200
    ): PingStats {
        val samples = ArrayList<Long>(probes)
        var ok = 0
        repeat(probes) { index ->
            val rtt = pingMs(host, port, timeoutMs)
            if (rtt >= 0) {
                samples.add(rtt)
                ok++
            }
            if (index < probes - 1) {
                try {
                    Thread.sleep(intervalMs)
                } catch (_: InterruptedException) {
                }
            }
        }
        if (samples.isEmpty()) {
            return PingStats(host, probes, 0, -1, -1, -1, -1)
        }
        val min = samples.min()
        val max = samples.max()
        val avg = samples.sum() / samples.size
        val jitter = samples.sumOf { abs(it - avg) } / samples.size
        return PingStats(host, probes, ok, min, avg, max, jitter)
    }
}
