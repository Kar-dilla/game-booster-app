package com.gameoverlay.app

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.abs

object NetworkMonitor {

    data class LinkInfo(
        val type: String,
        val detail: String,
        val rssi: Int?,
        val isFastBand: Boolean
    )

    fun connectionType(context: Context): String = linkInfo(context).type

    fun linkInfo(context: Context): LinkInfo {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
        val caps = network?.let { cm.getNetworkCapabilities(it) }
        if (caps == null) return LinkInfo("Offline", "No connection", null, false)
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> {
                val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION")
                val info = wm.connectionInfo
                val rssi = info?.rssi
                val freq = info?.frequency ?: 0
                val mbps = info?.linkSpeed ?: 0
                val band = when {
                    freq >= 5900 -> "6 GHz"
                    freq >= 4900 -> "5 GHz"
                    freq > 0 -> "2.4 GHz"
                    else -> "Wi-Fi"
                }
                val fast = freq >= 4900
                LinkInfo(
                    "Wi-Fi",
                    "$band · ${mbps} Mbps" + (rssi?.let { " · $it dBm" } ?: ""),
                    rssi,
                    fast
                )
            }
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ->
                LinkInfo("Mobile", "Mobile data", null, false)
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ->
                LinkInfo("Ethernet", "Ethernet", null, true)
            else -> LinkInfo("On", "Connected", null, false)
        }
    }

    fun pingHostForGame(packageName: String?): Pair<String, Int> {
        val pkg = packageName ?: return "1.1.1.1" to 443
        val host = when {
            pkg.contains("freefire") -> "common-lb.freefiremobile.com"
            pkg.contains("pubg") || pkg.contains("tencent.ig") || pkg.endsWith(".ig") ->
                "match.igamecj.com"
            pkg.contains("callofduty") || pkg.contains("codm") -> "codm.activision.com"
            pkg.contains("mobilelegends") || pkg.contains("mobile.legends") || pkg.contains("mlbb") ->
                "api.mobilelegends.com"
            pkg.contains("roblox") -> "clientsettings.roblox.com"
            pkg.contains("fortnite") || pkg.contains("epicgames") -> "fortnite-public-service-prod.ol.epicgames.com"
            pkg.contains("genshin") || pkg.contains("yuanshen") -> "sg-public-data-api.hoyoverse.com"
            pkg.contains("league") || pkg.contains("wildrift") -> "wildrift.leagueoflegends.com"
            pkg.contains("efootball") || pkg.contains("pes") -> "efootball.konami.net"
            else -> "1.1.1.1"
        }
        return host to 443
    }

    fun pingMs(host: String = "1.1.1.1", port: Int = 443, timeoutMs: Int = 1200): Long {
        return try {
            val start = System.currentTimeMillis()
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), timeoutMs)
            }
            System.currentTimeMillis() - start
        } catch (_: Exception) {
            -1L
        }
    }

    data class PingStats(
        val host: String,
        val probesSent: Int,
        val probesOk: Int,
        val minMs: Long,
        val avgMs: Long,
        val maxMs: Long,
        val jitterMs: Long
    ) {
        val lossPercent: Int
            get() = if (probesSent == 0) 0 else ((probesSent - probesOk) * 100) / probesSent
        val reachable: Boolean get() = probesOk > 0
    }

    fun measurePingStats(
        host: String = "1.1.1.1",
        port: Int = 443,
        probes: Int = 3,
        intervalMs: Long = 160,
        timeoutMs: Int = 1200
    ): PingStats {
        val samples = ArrayList<Long>(probes)
        var ok = 0
        repeat(probes) { index ->
            val rtt = pingMs(host, port, timeoutMs)
            if (rtt >= 0) {
                samples.add(rtt)
                ok++
            }
            if (index < probes - 1) {
                try {
                    Thread.sleep(intervalMs)
                } catch (_: InterruptedException) {
                }
            }
        }
        if (samples.isEmpty()) {
            return PingStats(host, probes, 0, -1, -1, -1, -1)
        }
        val min = samples.min()
        val max = samples.max()
        val avg = samples.sum() / samples.size
        val jitter = samples.sumOf { abs(it - avg) } / samples.size
        return PingStats(host, probes, ok, min, avg, max, jitter)
    }

    // --- Cloudflare WARP: we cannot bundle a VPN tunnel inside this app, and no non-root
    // app can pick which server a game's matchmaking puts you on. What we CAN do for free
    // is exactly the measure -> tunnel -> re-measure protocol VPN providers themselves
    // recommend: detect WARP, let the player toggle it in its own app, then compare ping
    // with/without so THEY see whether it actually helped on their route — never assume it
    // will, since a tunnel only wins when the default ISP route is the bad part.
    private const val WARP_PACKAGE = "com.cloudflare.onedotonedotonedotone"

    fun isWarpInstalled(context: Context): Boolean {
        return try {
            context.packageManager.getPackageInfo(WARP_PACKAGE, 0)
            true
        } catch (_: Exception) {
            false
        }
    }

    // Android has no API to identify WHICH app owns an active VPN tunnel — only that
    // some VPN is active. Combined with isWarpInstalled(), this is a reasonable proxy
    // as long as WARP is the only VPN-type app the player has running for this.
    fun isAnyVpnActive(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
    }

    // --- Private DNS provider selection --------------------------------------------
    //
    // Android's Private DNS (DNS-over-TLS) only takes a hostname, not an IP, so we
    // can't actually resolve through a candidate before switching to it — we can only
    // TCP-connect to its DoT port (853), which every DoT server must accept a TLS
    // handshake on. That measures "can I reach this server's DoT port quickly", which
    // correlates with DNS lookup latency but is NOT the same as timing a real DNS
    // query. Treat the winner as "probably the closer/faster one on this network right
    // now", not a lab-grade benchmark.
    const val DOT_PORT = 853
    const val CLOUDFLARE_DNS_HOST = "1dot1dot1dot1.cloudflare-dns.com"

    fun nextDnsHost(configId: String): String? {
        val id = configId.trim()
        if (id.isEmpty()) return null
        // NextDNS's DoT hostname is literally the config ID under dns.nextdns.io —
        // no other formatting needed.
        return "$id.dns.nextdns.io"
    }

    data class DnsCandidate(val label: String, val hostname: String)
    data class DnsBenchResult(
        val winner: DnsCandidate,
        val winnerAvgMs: Long,
        val results: List<Pair<DnsCandidate, PingStats>>
    ) {
        val anyReachable: Boolean get() = results.any { it.second.reachable }
    }

    /**
     * Benchmarks every reachable candidate's DoT port and returns whichever answered
     * fastest. Call this off the main thread — each candidate takes up to ~probes *
     * timeout worst-case.
     *
     * IMPORTANT: if NOTHING responds, `winner` still points at Cloudflare for display
     * purposes (so the UI has something to show), but check `anyReachable` before
     * acting on it — a dead reading on this network is a reason to leave Private DNS
     * completely alone, not a reason to force strict mode blind. Forcing strict-mode
     * Private DNS to a host the current network can't reach makes Android refuse to
     * validate ANY connection, phone-wide, not just for the game — this is exactly
     * what breaks mobile data on carriers that block or throttle port 853.
     */
    fun benchmarkDnsProviders(
        candidates: List<DnsCandidate>,
        probes: Int = 2,
        timeoutMs: Int = 800
    ): DnsBenchResult {
        val results = candidates.map { candidate ->
            candidate to measurePingStats(candidate.hostname, DOT_PORT, probes, 120, timeoutMs)
        }
        val reachable = results.filter { it.second.reachable }
        val winner = reachable.minByOrNull { it.second.avgMs }
            ?: (candidates.firstOrNull { it.label == "Cloudflare" }
                ?: candidates.first()) to PingStats(candidates.first().hostname, 0, 0, -1, -1, -1, -1)
        return DnsBenchResult(winner.first, winner.second.avgMs, results)
    }

    /** Single reachability probe on a host's DoT port, for callers about to force
     *  strict-mode Private DNS to it and who need to know first whether that will
     *  just brick connectivity on the current network. Not a full benchmark. */
    fun isDotReachable(hostname: String, timeoutMs: Int = 900): Boolean =
        measurePingStats(hostname, DOT_PORT, probes = 1, intervalMs = 0L, timeoutMs = timeoutMs).reachable

    fun openWarpOrStore(context: Context) {
        val launch = context.packageManager.getLaunchIntentForPackage(WARP_PACKAGE)
        val intent = if (launch != null) {
            launch
        } else {
            android.content.Intent(
                android.content.Intent.ACTION_VIEW,
                android.net.Uri.parse("https://play.google.com/store/apps/details?id=$WARP_PACKAGE")
            )
        }
        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
        }
    }
}
