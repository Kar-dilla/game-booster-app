package com.gameoverlay.app

import android.content.pm.PackageManager
import android.util.Log
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.concurrent.thread

/**
 * Thin wrapper around the Shizuku API.
 *
 * Shizuku hands the app a privileged Binder once the user has started it
 * (wireless-debugging pairing, or adb). With that binder we can run shell
 * commands with adb's privilege level — no root required. This gives us:
 *  - instant `am force-stop <pkg>` instead of simulated Accessibility taps
 *  - `settings put system peak_refresh_rate ...` (needs WRITE_SECURE_SETTINGS,
 *    which normal apps can never hold, but shell can)
 *  - toggling Private DNS for the gaming session
 */
object ShizukuManager {

    private const val TAG = "ShizukuManager"
    const val REQUEST_CODE = 9001

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        Log.i(TAG, "Shizuku binder received")
    }
    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        Log.w(TAG, "Shizuku binder died — user closed Shizuku or device rebooted")
    }

    private var listenersAdded = false

    /** Call once, e.g. from Application.onCreate() or MainActivity.onCreate(). */
    fun addListeners() {
        if (listenersAdded) return
        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            listenersAdded = true
        } catch (_: Throwable) {
            // Shizuku not installed / not running yet — fine, we just stay unavailable.
        }
    }

    fun removeListeners() {
        if (!listenersAdded) return
        try {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
        } catch (_: Throwable) {
        }
        listenersAdded = false
    }

    /** True once Shizuku is running (paired + started) and has handed us a binder. */
    fun isAvailable(): Boolean = try {
        Shizuku.pingBinder()
    } catch (_: Throwable) {
        false
    }

    fun hasPermission(): Boolean {
        if (!isAvailable()) return false
        return try {
            if (Shizuku.isPreV11()) {
                false // ancient Shizuku, not worth supporting
            } else {
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            }
        } catch (_: Throwable) {
            false
        }
    }

    fun shouldShowRationale(): Boolean = try {
        Shizuku.shouldShowRequestPermissionRationale()
    } catch (_: Throwable) {
        false
    }

    /** Triggers the Shizuku permission prompt. Result arrives via the listener below. */
    fun requestPermission() {
        if (!isAvailable()) return
        try {
            if (!Shizuku.isPreV11()) {
                Shizuku.requestPermission(REQUEST_CODE)
            }
        } catch (_: Throwable) {
        }
    }

    fun addPermissionResultListener(listener: Shizuku.OnRequestPermissionResultListener) {
        try {
            Shizuku.addRequestPermissionResultListener(listener)
        } catch (_: Throwable) {
        }
    }

    fun removePermissionResultListener(listener: Shizuku.OnRequestPermissionResultListener) {
        try {
            Shizuku.removeRequestPermissionResultListener(listener)
        } catch (_: Throwable) {
        }
    }

    /**
     * Runs a shell command through Shizuku's privileged process and returns
     * (exitCode, combined stdout+stderr). Runs synchronously — always call
     * from a background thread (see [execAsync]).
     */
    fun exec(command: String): Pair<Int, String> {
        if (!hasPermission()) return -1 to "Shizuku permission not granted"
        return try {
            val process = newShizukuProcess(arrayOf("sh", "-c", command))
            val output = BufferedReader(InputStreamReader(process.inputStream)).readText() +
                BufferedReader(InputStreamReader(process.errorStream)).readText()
            val code = process.waitFor()
            code to output.trim()
        } catch (t: Throwable) {
            Log.e(TAG, "exec failed: $command", t)
            -1 to (t.message ?: "unknown error")
        }
    }

    /** Fire-and-forget variant for callers on the main thread (UI, service lifecycle). */
    fun execAsync(command: String, onResult: ((Int, String) -> Unit)? = null) {
        thread(name = "shizuku-exec") {
            val (code, output) = exec(command)
            onResult?.invoke(code, output)
        }
    }

    /**
     * Shizuku's public API only exposes AIDL calls; a raw process is obtained
     * through the hidden `Shizuku.newProcess(String[], String[], String)`
     * method that ships inside the same artifact. This reflection call is
     * the standard, widely-used pattern for Shizuku shell execution.
     */
    private fun newShizukuProcess(cmd: Array<String>): Process {
        val method = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        method.isAccessible = true
        return method.invoke(null, cmd, null, null) as Process
    }
}
