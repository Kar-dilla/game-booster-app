package com.gameoverlay.app

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.graphics.PixelFormat
import kotlin.concurrent.thread

/**
 * Device-wide session optimizations that actually affect the game:
 *  - Wi-Fi low-latency lock (stops radio power-save jitter)
 *  - Partial wake lock (stops Doze from parking the CPU mid-match)
 *  - Optional Bluetooth radio off (2.4 GHz Wi-Fi coexistence)
 *  - Optional anti-mistouch edge guards (blocks accidental back gestures)
 */
class SessionEngine(private val context: Context) {

    private var wifiLock: WifiManager.WifiLock? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var leftGuard: View? = null
    private var rightGuard: View? = null
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    val wifiHeld: Boolean get() = wifiLock?.isHeld == true
    val wakeHeld: Boolean get() = wakeLock?.isHeld == true

    fun acquireWifiLock() {
        if (wifiLock?.isHeld == true) return
        try {
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val lockType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            else
                @Suppress("DEPRECATION") WifiManager.WIFI_MODE_FULL_HIGH_PERF
            val lock = wm.createWifiLock(lockType, "GameTurbo:WifiLock")
            lock.setReferenceCounted(false)
            lock.acquire()
            wifiLock = lock
        } catch (_: Exception) {
        }
    }

    fun releaseWifiLock() {
        try {
            wifiLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {
        }
        wifiLock = null
    }

    fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            val lock = pm.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "GameTurbo:PlayWake"
            )
            lock.setReferenceCounted(false)
            lock.acquire()
            wakeLock = lock
        } catch (_: Exception) {
        }
    }

    fun releaseWakeLock() {
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {
        }
        wakeLock = null
    }

    // Since Android 13 (targetSdk Tiramisu+), Google blocked apps from silently
    // enabling/disabling Bluetooth: adapter.disable()/enable() now ALWAYS return
    // false and do nothing for any app targeting API 33+ via the normal SDK path.
    // If Shizuku is available we skip this restriction entirely (shell privilege
    // via `svc bluetooth`, see GameModeController) and this function is only the
    // fallback for users who haven't granted Shizuku.
    fun setBluetoothOff(off: Boolean): Boolean {
        if (GameModeController.available()) {
            if (off) Prefs.setBtWasOn(context, isBluetoothCurrentlyOn())
            var shizukuOk = false
            val latch = java.util.concurrent.CountDownLatch(1)
            if (off) {
                GameModeController.disableBluetooth { ok -> shizukuOk = ok; latch.countDown() }
            } else if (Prefs.getBtWasOn(context)) {
                GameModeController.restoreBluetooth { ok -> shizukuOk = ok; latch.countDown() }
            } else {
                latch.countDown() // nothing to restore
                shizukuOk = true
            }
            try { latch.await(2, java.util.concurrent.TimeUnit.SECONDS) } catch (_: InterruptedException) {}
            if (shizukuOk) return true
            // fall through to the SDK-path / panel fallback below if Shizuku's
            // shell command itself failed (e.g. permission revoked mid-session)
        }
        return try {
            val adapter = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                val bm = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
                bm.adapter
            } else {
                @Suppress("DEPRECATION")
                BluetoothAdapter.getDefaultAdapter()
            } ?: return false
            if (off) {
                Prefs.setBtWasOn(context, adapter.isEnabled)
                @Suppress("DEPRECATION")
                adapter.disable() // returns false on API 33+, by design — see comment above
            } else {
                if (Prefs.getBtWasOn(context)) {
                    @Suppress("DEPRECATION")
                    adapter.enable()
                } else {
                    true // nothing to restore
                }
            }
        } catch (_: SecurityException) {
            false
        } catch (_: Exception) {
            false
        }
    }

    // Fallback when the direct call above returns false: opens Android's own quick
    // Bluetooth panel (a bottom sheet, not a full screen leave) so the user can flip
    // it with one tap. This is the actual replacement path Google intends apps to use.
    private fun isBluetoothCurrentlyOn(): Boolean = try {
        val bm = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bm.adapter?.isEnabled ?: false
    } catch (_: Exception) {
        false
    }

    fun openBluetoothPanel() {
        try {
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                Intent(Settings.Panel.ACTION_BLUETOOTH)
            } else {
                Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (_: Exception) {
        }
    }

    fun setAntiMistouch(enabled: Boolean) {
        if (enabled) addGuards() else removeGuards()
        Prefs.setAntiMistouchEnabled(context, enabled)
    }

    val antiMistouchOn: Boolean get() = leftGuard != null

    // Requires WRITE_SETTINGS ("Modify system settings"), a special permission granted
    // via its own settings screen — not a plain runtime permission. Locks orientation
    // to whatever it currently is, and restores the user's prior auto-rotate setting
    // (not just "turn it back on") when the session ends.
    fun canWriteSettings(): Boolean = Settings.System.canWrite(context)

    fun setRotationLock(locked: Boolean): Boolean {
        if (!canWriteSettings()) return false
        return try {
            if (locked) {
                val wasAutoRotate = Settings.System.getInt(
                    context.contentResolver,
                    Settings.System.ACCELEROMETER_ROTATION,
                    1
                ) == 1
                Prefs.setRotationWasOn(context, wasAutoRotate)
                Settings.System.putInt(context.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0)
            } else {
                val restore = if (Prefs.getRotationWasOn(context)) 1 else 0
                Settings.System.putInt(context.contentResolver, Settings.System.ACCELEROMETER_ROTATION, restore)
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    val rotationLocked: Boolean
        get() = try {
            Settings.System.getInt(context.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1) == 0
        } catch (_: Exception) {
            false
        }

    // Android gives no API to control thermal throttling — only to report it. This
    // surfaces that honestly instead of implying the app can fix heat, which it can't.
    // PowerManager.currentThermalStatus is a real reading from the device's own thermal
    // HAL (hardware temperature sensors + OEM thresholds) — not a value this app computes
    // or estimates from anything. "Cool" is the normal baseline; each step after it is a
    // real escalation the OS itself reported, not a guess.
    fun thermalStatusLabel(): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return try {
            when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "Cool"
                PowerManager.THERMAL_STATUS_LIGHT -> "Warm" // earliest real warning: rising slightly
                PowerManager.THERMAL_STATUS_MODERATE -> "Hot"
                PowerManager.THERMAL_STATUS_SEVERE -> "Throttling"
                PowerManager.THERMAL_STATUS_CRITICAL,
                PowerManager.THERMAL_STATUS_EMERGENCY,
                PowerManager.THERMAL_STATUS_SHUTDOWN -> "Overheating"
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun addGuards() {
        if (leftGuard != null) return
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val density = context.resources.displayMetrics.density
        val width = (18 * density).toInt()
        fun make(gravity: Int): View {
            val v = View(context)
            v.setBackgroundColor(0x01000000) // essentially invisible, still receives touches
            val lp = WindowManager.LayoutParams(
                width,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = gravity
            wm.addView(v, lp)
            // Sitting in the edge zone is NOT enough on its own: Android's system
            // back-gesture recognizer claims that screen region before any app
            // window's touch listener ever sees it, regardless of z-order. Without
            // explicitly excluding this rect, the swipe-back gesture still fires
            // right through this view — this is the actual reason it looked like
            // it wasn't doing anything.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                v.post {
                    if (v.width > 0 && v.height > 0) {
                        v.systemGestureExclusionRects = listOf(
                            android.graphics.Rect(0, 0, v.width, v.height)
                        )
                    }
                }
            }
            return v
        }
        try {
            leftGuard = make(Gravity.START)
            rightGuard = make(Gravity.END)
        } catch (_: Exception) {
        }
    }

    private fun removeGuards() {
        try {
            leftGuard?.let { wm.removeView(it) }
        } catch (_: Exception) {
        }
        try {
            rightGuard?.let { wm.removeView(it) }
        } catch (_: Exception) {
        }
        leftGuard = null
        rightGuard = null
    }

    fun startSession() {
        acquireWifiLock()
        acquireWakeLock()
        if (Prefs.isAntiMistouchEnabled(context)) addGuards()
        if (Prefs.isRotationLockSessionEnabled(context)) setRotationLock(true)
    }

    fun endSession() {
        releaseWifiLock()
        releaseWakeLock()
        removeGuards()
        if (rotationLocked) setRotationLock(false)
        // Restore BT only if we turned it off.
        thread {
            try {
                setBluetoothOff(false)
            } catch (_: Exception) {
            }
        }
    }
}
