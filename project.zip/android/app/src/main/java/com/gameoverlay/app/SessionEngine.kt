package com.gameoverlay.app

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import android.os.PowerManager
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.graphics.PixelFormat
import kotlin.concurrent.thread

/**
 * Device-wide session optimizations that actually affect the game:
 *  - Wi-Fi low-latency lock (stops radio power-save jitter)
 *  - Partial wake lock (stops Doze from parking the CPU mid-match)
 *  - Optional Bluetooth radio off (2.4 GHz Wi-Fi coexistence)
 *  - Optional anti-mistouch edge guards (blocks accidental back gestures)
 */
class SessionEngine(private val context: Context) {

    private var wifiLock: WifiManager.WifiLock? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var leftGuard: View? = null
    private var rightGuard: View? = null
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    val wifiHeld: Boolean get() = wifiLock?.isHeld == true
    val wakeHeld: Boolean get() = wakeLock?.isHeld == true

    fun acquireWifiLock() {
        if (wifiLock?.isHeld == true) return
        try {
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val lockType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            else
                @Suppress("DEPRECATION") WifiManager.WIFI_MODE_FULL_HIGH_PERF
            val lock = wm.createWifiLock(lockType, "GameTurbo:WifiLock")
            lock.setReferenceCounted(false)
            lock.acquire()
            wifiLock = lock
        } catch (_: Exception) {
        }
    }

    fun releaseWifiLock() {
        try {
            wifiLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {
        }
        wifiLock = null
    }

    fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            val lock = pm.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "GameTurbo:PlayWake"
            )
            lock.setReferenceCounted(false)
            lock.acquire()
            wakeLock = lock
        } catch (_: Exception) {
        }
    }

    fun releaseWakeLock() {
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {
        }
        wakeLock = null
    }

    fun setBluetoothOff(off: Boolean): Boolean {
        return try {
            val adapter = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                val bm = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
                bm.adapter
            } else {
                @Suppress("DEPRECATION")
                BluetoothAdapter.getDefaultAdapter()
            } ?: return false
            if (off) {
                Prefs.setBtWasOn(context, adapter.isEnabled)
                @Suppress("DEPRECATION")
                adapter.disable()
            } else {
                if (Prefs.getBtWasOn(context)) {
                    @Suppress("DEPRECATION")
                    adapter.enable()
                }
            }
            true
        } catch (_: SecurityException) {
            false
        } catch (_: Exception) {
            false
        }
    }

    fun setAntiMistouch(enabled: Boolean) {
        if (enabled) addGuards() else removeGuards()
        Prefs.setAntiMistouchEnabled(context, enabled)
    }

    val antiMistouchOn: Boolean get() = leftGuard != null

    private fun addGuards() {
        if (leftGuard != null) return
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val density = context.resources.displayMetrics.density
        val width = (18 * density).toInt()
        fun make(gravity: Int): View {
            val v = View(context)
            v.setBackgroundColor(0x01000000) // essentially invisible, still receives touches
            val lp = WindowManager.LayoutParams(
                width,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = gravity
            wm.addView(v, lp)
            return v
        }
        try {
            leftGuard = make(Gravity.START)
            rightGuard = make(Gravity.END)
        } catch (_: Exception) {
        }
    }

    private fun removeGuards() {
        try {
            leftGuard?.let { wm.removeView(it) }
        } catch (_: Exception) {
        }
        try {
            rightGuard?.let { wm.removeView(it) }
        } catch (_: Exception) {
        }
        leftGuard = null
        rightGuard = null
    }

    fun startSession() {
        acquireWifiLock()
        acquireWakeLock()
        if (Prefs.isAntiMistouchEnabled(context)) addGuards()
    }

    fun endSession() {
        releaseWifiLock()
        releaseWakeLock()
        removeGuards()
        // Restore BT only if we turned it off.
        thread {
            try {
                setBluetoothOff(false)
            } catch (_: Exception) {
            }
        }
    }
}
