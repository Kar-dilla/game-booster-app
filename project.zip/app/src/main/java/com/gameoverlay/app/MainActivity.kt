package com.gameoverlay.app

import android.app.AppOpsManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private data class AppEntry(val label: String, val packageName: String)

    private lateinit var lvApps: ListView
    private lateinit var tvPermStatus: TextView
    private var appEntries: List<AppEntry> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        lvApps = findViewById(R.id.lvApps)
        tvPermStatus = findViewById(R.id.tvPermStatus)

        loadInstalledApps()
        restoreSelection()

        findViewById<android.widget.Button>(R.id.btnOverlayPerm).setOnClickListener {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }

        findViewById<android.widget.Button>(R.id.btnUsagePerm).setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }

        findViewById<android.widget.Button>(R.id.btnDndPerm).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }

        findViewById<android.widget.Button>(R.id.btnSave).setOnClickListener {
            saveSelection()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }

        findViewById<android.widget.Button>(R.id.btnStart).setOnClickListener {
            if (!allPermissionsGranted()) {
                Toast.makeText(this, "Grant all three permissions first", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            saveSelection()
            ContextCompat.startForegroundService(this, Intent(this, ForegroundWatcherService::class.java))
            Toast.makeText(this, "Monitoring started", Toast.LENGTH_SHORT).show()
        }

        findViewById<android.widget.Button>(R.id.btnStop).setOnClickListener {
            stopService(Intent(this, ForegroundWatcherService::class.java))
            stopService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "Stopped", Toast.LENGTH_SHORT).show()
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(
                this, arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 100
            )
        }
    }

    override fun onResume() {
        super.onResume()
        refreshPermStatus()
    }

    private fun loadInstalledApps() {
        val pm = packageManager
        val apps = pm.getInstalledApplications(0)
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 || it.packageName == packageName }
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .map { AppEntry(pm.getApplicationLabel(it).toString(), it.packageName) }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }

        appEntries = apps
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_multiple_choice,
            apps.map { it.label }
        )
        lvApps.adapter = adapter
    }

    private fun restoreSelection() {
        val selected = Prefs.getSelectedGames(this)
        appEntries.forEachIndexed { index, entry ->
            if (entry.packageName in selected) {
                lvApps.setItemChecked(index, true)
            }
        }
    }

    private fun saveSelection() {
        val checked = lvApps.checkedItemPositions
        val selected = mutableSetOf<String>()
        for (i in appEntries.indices) {
            if (checked.get(i)) selected.add(appEntries[i].packageName)
        }
        Prefs.setSelectedGames(this, selected)
    }

    private fun hasOverlayPermission() = Settings.canDrawOverlays(this)

    private fun hasUsageAccess(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun hasDndAccess(): Boolean {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return nm.isNotificationPolicyAccessGranted
    }

    private fun allPermissionsGranted() = hasOverlayPermission() && hasUsageAccess() && hasDndAccess()

    private fun refreshPermStatus() {
        val overlay = if (hasOverlayPermission()) "✓" else "✗"
        val usage = if (hasUsageAccess()) "✓" else "✗"
        val dnd = if (hasDndAccess()) "✓" else "✗"
        tvPermStatus.text = "Overlay: $overlay   Usage access: $usage   DND access: $dnd"
    }
}
