package com.gameoverlay.app

import android.app.ActivityManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager

object BoosterUtils {

    data class BoostResult(val freedMb: Long, val closedCount: Int)

    fun freeRamMb(context: Context): Long {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return info.availMem / (1024 * 1024)
    }

    /**
     * Closes recently-used background apps that are not the foreground game and not system apps.
     * This cannot force-stop the foreground game itself or any app without root access.
     */
    fun boost(context: Context, foregroundPackage: String?): BoostResult {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val pm = context.packageManager
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager

        val before = freeRamMb(context)
        val myPackage = context.packageName

        val end = System.currentTimeMillis()
        val start = end - 1000 * 60 * 60 // last hour
        val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_BEST, start, end)

        var closed = 0
        stats?.forEach { usageStat ->
            val pkg = usageStat.packageName
            if (pkg == myPackage || pkg == foregroundPackage) return@forEach
            if (!isEligibleForKill(pm, pkg)) return@forEach
            try {
                am.killBackgroundProcesses(pkg)
                closed++
            } catch (_: Exception) {
                // Ignore packages we're not allowed to kill.
            }
        }

        val after = freeRamMb(context)
        return BoostResult(freedMb = (after - before).coerceAtLeast(0), closedCount = closed)
    }

    private fun isEligibleForKill(pm: PackageManager, packageName: String): Boolean {
        return try {
            val appInfo = pm.getApplicationInfo(packageName, 0)
            // Skip system apps to avoid killing something the OS depends on.
            (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) == 0
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }
}
