package com.gameoverlay.app

import android.app.ActivityManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

object BoosterUtils {

    /**
     * closedCount kept for compatibility with existing UI code — it now means
     * "attempted" (the OS call didn't throw), not "confirmed killed", since
     * killBackgroundProcesses() gives no feedback on whether anything actually died.
     * consideredCount / skippedSystemCount are new: they tell you WHY the number
     * you're seeing is what it is, instead of just showing a mystery 0.
     */
    data class BoostResult(
        val freedMb: Long,
        val closedCount: Int,
        val consideredCount: Int,
        val skippedSystemCount: Int
    )

    fun freeRamMb(context: Context): Long {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return info.availMem / (1024 * 1024)
    }

    /**
     * Closes recently-used background apps that are not the foreground game and not system apps.
     * This cannot force-stop the foreground game itself or any app without root access, and
     * Android gives no confirmation that a targeted app actually terminated — apps holding a
     * foreground service or notification are commonly left running with no error reported.
     */
    fun boost(context: Context, foregroundPackage: String?): BoostResult {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager

        val before = freeRamMb(context)
        val myPackage = context.packageName

        val end = System.currentTimeMillis()
        val start = end - 1000 * 60 * 60 // last hour
        val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_BEST, start, end)

        var attempted = 0
        var considered = 0
        var skippedSystem = 0
        stats?.forEach { usageStat ->
            val pkg = usageStat.packageName
            if (pkg == myPackage || pkg == foregroundPackage) return@forEach
            considered++
            if (!isEligibleForKill(context, pkg)) {
                skippedSystem++
                return@forEach
            }
            try {
                am.killBackgroundProcesses(pkg)
                attempted++
            } catch (_: Exception) {
                // Ignore packages we're not allowed to kill.
            }
        }

        val after = freeRamMb(context)
        return BoostResult(
            freedMb = (after - before).coerceAtLeast(0),
            closedCount = attempted,
            consideredCount = considered,
            skippedSystemCount = skippedSystem
        )
    }

    // A real, short deny-list — not "anything that shipped preinstalled". FLAG_SYSTEM
    // covers far too much on most OEM phones (stock keyboard, browser, even bundled
    // consumer apps carriers preinstalled) to use as the filter. This only protects
    // packages that would actually break something visible if killed.
    private val HARD_PROTECTED_PACKAGES = setOf(
        "android",
        "com.android.systemui",
        "com.android.phone",
        "com.android.dialer",
        "com.android.settings"
    )

    private fun isEligibleForKill(context: Context, packageName: String): Boolean {
        if (packageName in HARD_PROTECTED_PACKAGES) return false
        if (packageName == defaultLauncherPackage(context)) return false
        return try {
            context.packageManager.getApplicationInfo(packageName, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    // Detected dynamically instead of hardcoded, since the launcher package name
    // differs by OEM (Samsung, MIUI, stock, etc.) — killing your own home screen
    // app causes a visible flicker even though it's harmless, so it's worth skipping.
    private fun defaultLauncherPackage(context: Context): String? {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val resolveInfo = context.packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
        return resolveInfo?.activityInfo?.packageName
    }
}
