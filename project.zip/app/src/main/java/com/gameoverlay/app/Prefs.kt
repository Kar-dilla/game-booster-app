package com.gameoverlay.app

import android.content.Context

object Prefs {
    private const val FILE = "game_overlay_prefs"
    private const val KEY_GAMES = "selected_games"
    private const val KEY_DND_WAS_ON = "dnd_prev_state"

    fun getSelectedGames(context: Context): Set<String> {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return sp.getStringSet(KEY_GAMES, emptySet()) ?: emptySet()
    }

    fun setSelectedGames(context: Context, packages: Set<String>) {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        sp.edit().putStringSet(KEY_GAMES, packages).apply()
    }

    fun setDndWasOn(context: Context, wasOn: Boolean) {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        sp.edit().putBoolean(KEY_DND_WAS_ON, wasOn).apply()
    }

    fun getDndWasOn(context: Context): Boolean {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return sp.getBoolean(KEY_DND_WAS_ON, false)
    }
}
