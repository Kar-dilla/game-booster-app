package com.gameoverlay.app

import android.content.Context

object Prefs {
    private const val FILE = "game_overlay_prefs"
    private const val KEY_GAMES = "selected_games"
    private const val KEY_DND_WAS_ON = "dnd_prev_state"
    private const val KEY_AUTO_MODE = "auto_mode"

    fun getSelectedGames(context: Context): Set<String> {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return sp.getStringSet(KEY_GAMES, emptySet()) ?: emptySet()
    }

    fun setSelectedGames(context: Context, packages: Set<String>) {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        sp.edit().putStringSet(KEY_GAMES, packages).apply()
    }

    fun setDndWasOn(context: Context, wasOn: Boolean) {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        sp.edit().putBoolean(KEY_DND_WAS_ON, wasOn).apply()
    }

    fun getDndWasOn(context: Context): Boolean {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return sp.getBoolean(KEY_DND_WAS_ON, false)
    }

    /**
     * Auto-mode (DND + Wi-Fi lock + one-shot boost on game launch).
     * Defaults to ON so existing installs silently get the improvement;
     * the main screen switch can turn it off.
     */
    fun isAutoModeEnabled(context: Context): Boolean {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return sp.getBoolean(KEY_AUTO_MODE, true)
    }

    fun setAutoModeEnabled(context: Context, enabled: Boolean) {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        sp.edit().putBoolean(KEY_AUTO_MODE, enabled).apply()
    }
}
