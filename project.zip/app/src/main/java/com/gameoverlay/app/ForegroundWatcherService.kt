package com.gameoverlay.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat

class ForegroundWatcherService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var lastForegroundPackage: String? = null
    private var overlayActive = false
    private var selectedGames: Set<String> = emptySet()

    // Tracks the last app we know for certain was foregrounded, and the
    // timestamp we've already scanned up to. We never reset this to null
    // just because no *new* transition event has fired recently — staying
    // in one app for a while produces zero events, and that must mean
    // "nothing changed", not "nothing is foreground".
    private var currentForegroundPackage: String? = null
    private var lastQueryTime = System.currentTimeMillis()

    private val pollRunnable = object : Runnable {
        override fun run() {
            checkForegroundApp()
            handler.postDelayed(this, POLL_INTERVAL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIF_ID, buildNotification("Watching for your games…"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        selectedGames = Prefs.getSelectedGames(this)
        handler.removeCallbacks(pollRunnable)
        handler.post(pollRunnable)
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(pollRunnable)
        if (overlayActive) {
            stopService(Intent(this, OverlayService::class.java))
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun checkForegroundApp() {
        selectedGames = Prefs.getSelectedGames(this) // pick up library edits without restart

        // Only overwrite our tracked foreground app if we actually saw a new
        // transition event. No new event just means the same app is still
        // in front of you — that is the fix for the DND/overlay flapping bug.
        val newlySeen = queryForegroundPackage()
        if (newlySeen != null) {
            currentForegroundPackage = newlySeen
        }
        val current = currentForegroundPackage
        if (current == lastForegroundPackage) return
        lastForegroundPackage = current

        val shouldShow = current != null && current in selectedGames
        if (shouldShow && !overlayActive) {
            val intent = Intent(this, OverlayService::class.java)
            intent.putExtra(OverlayService.EXTRA_GAME_PACKAGE, current)
            startService(intent)
            overlayActive = true
        } else if (!shouldShow && overlayActive) {
            stopService(Intent(this, OverlayService::class.java))
            overlayActive = false
        }
    }

    private fun queryForegroundPackage(): String? {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        // A small overlap (2s) guards against any event that lands right at
        // the boundary between two polls, without re-processing stale events
        // forever the way a fixed "look back 10s" window did.
        val start = (lastQueryTime - 2_000).coerceAtMost(end)
        lastQueryTime = end
        val events = usm.queryEvents(start, end)
        var lastPackage: String? = null
        val event = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND ||
                (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && event.eventType == UsageEvents.Event.ACTIVITY_RESUMED)
            ) {
                lastPackage = event.packageName
            }
        }
        return lastPackage
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Game watcher", NotificationManager.IMPORTANCE_MIN
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Game Overlay")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "watcher_channel"
        private const val NOTIF_ID = 1001
        private const val POLL_INTERVAL_MS = 1500L
    }
}
