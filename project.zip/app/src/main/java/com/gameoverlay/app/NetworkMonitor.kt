package com.gameoverlay.app

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import java.net.InetSocketAddress
import java.net.Socket

object NetworkMonitor {

    /** Human-readable connection type: "Wi-Fi", "Mobile data", "Ethernet" or "No connection". */
    fun connectionType(context: Context): String {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return "No connection"
        val caps = cm.getNetworkCapabilities(network) ?: return "No connection"
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Connected"
        }
    }

    /**
     * Measures round-trip time to a reference host by timing a raw TCP connect.
     * This reflects general local connection health, not any specific game server's latency.
     * Must be called off the main thread. Returns -1 on failure/timeout.
     */
    fun pingMs(host: String = "1.1.1.1", port: Int = 443, timeoutMs: Int = 1500): Long {
        return try {
            val start = System.currentTimeMillis()
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), timeoutMs)
            }
            System.currentTimeMillis() - start
        } catch (e: Exception) {
            -1L
        }
    }
}
