package com.gameoverlay.app

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.abs

object NetworkMonitor {

    /** Human-readable connection type: "Wi-Fi", "Mobile data", "Ethernet" or "No connection". */
    fun connectionType(context: Context): String {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return "No connection"
        val caps = cm.getNetworkCapabilities(network) ?: return "No connection"
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Connected"
        }
    }

    /**
     * Measures round-trip time to a reference host by timing a raw TCP connect.
     * This reflects general local connection health, not any specific game server's latency.
     * Must be called off the main thread. Returns -1 on failure/timeout.
     */
    fun pingMs(host: String = "1.1.1.1", port: Int = 443, timeoutMs: Int = 1500): Long {
        return try {
            val start = System.currentTimeMillis()
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), timeoutMs)
            }
            System.currentTimeMillis() - start
        } catch (e: Exception) {
            -1L
        }
    }

    /** Result of a multi-probe latency measurement. See [measurePingStats]. */
    data class PingStats(
        val host: String,
        val probesSent: Int,
        val probesOk: Int,
        val minMs: Long,
        val avgMs: Long,
        val maxMs: Long,
        /** Mean absolute deviation from the average RTT — what players feel as rubber-banding. */
        val jitterMs: Long
    ) {
        /** Failed probes as a percentage. A proxy for packet loss (TCP connect failures). */
        val lossPercent: Int
            get() = if (probesSent == 0) 0 else ((probesSent - probesOk) * 100) / probesSent

        val reachable: Boolean get() = probesOk > 0
    }

    /**
     * Fires [probes] TCP connects [intervalMs] apart and reports min/avg/max plus
     * jitter. A single ping hides the variance that actually ruins gameplay — a
     * connection at a steady 40ms plays fine; one alternating 20/200ms is misery
     * even though its average looks similar. This exposes the difference.
     * Must be called off the main thread. Sleeps between probes, so never call it
     * from a thread you need to cancel promptly.
     */
    fun measurePingStats(
        host: String = "1.1.1.1",
        port: Int = 443,
        probes: Int = 6,
        intervalMs: Long = 250,
        timeoutMs: Int = 1500
    ): PingStats {
        val samples = ArrayList<Long>(probes)
        var ok = 0
        repeat(probes) { index ->
            val rtt = pingMs(host, port, timeoutMs)
            if (rtt >= 0) {
                samples.add(rtt)
                ok++
            }
            if (index < probes - 1) {
                try {
                    Thread.sleep(intervalMs)
                } catch (_: InterruptedException) {
                    // Caller thread is being torn down — keep whatever we have.
                }
            }
        }
        if (samples.isEmpty()) {
            return PingStats(host, probes, 0, -1, -1, -1, -1)
        }
        val min = samples.min()
        val max = samples.max()
        val avg = samples.sum() / samples.size
        val jitter = samples.sumOf { abs(it - avg) } / samples.size
        return PingStats(host, probes, ok, min, avg, max, jitter)
    }
}
