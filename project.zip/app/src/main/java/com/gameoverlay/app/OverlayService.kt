package com.gameoverlay.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import android.widget.ToggleButton
import androidx.core.app.NotificationCompat
import kotlin.concurrent.thread

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var panelView: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null

    private val handler = Handler(Looper.getMainLooper())
    private var expanded = false
    private var gamePackage: String? = null
    private var sessionStartMs = 0L
    private var lastBoostFreedMb = 0L
    private var wifiLock: WifiManager.WifiLock? = null
    private var autoModeApplied = false
    private var pingGeneration = 0

    private val statsRunnable = object : Runnable {
        override fun run() {
            if (expanded) updateStats()
            handler.postDelayed(this, STATS_INTERVAL_MS)
        }
    }

    private val collapseOnIdle = Runnable { setExpanded(false) }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        startForeground(NOTIF_ID, buildNotification())
        sessionStartMs = System.currentTimeMillis()
        addBubble()
        handler.post(statsRunnable)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val pkg = intent?.getStringExtra(EXTRA_GAME_PACKAGE)
        if (pkg != null && pkg != gamePackage) {
            gamePackage = pkg
            // Auto-mode fires once per session, on first positive game
            // identification — not on every re-delivery of the same package.
            if (!autoModeApplied) {
                autoModeApplied = true
                applyAutoModeOnce()
            }
        }
        return START_STICKY
    }

    /**
     * Auto-mode, applied the first time we know which game is running.
     * Only non-interactive actions are allowed here: DND turns on only if the
     * permission was already granted (never a mid-game settings dialog), the
     * Wi-Fi lock is purely internal, and the one-shot boost is silent.
     * Gated behind Prefs.isAutoModeEnabled so the main-screen switch can
     * disable the whole behavior.
     */
    private fun applyAutoModeOnce() {
        if (!Prefs.isAutoModeEnabled(this)) return
        if (DndController.hasAccess(this)) DndController.enable(this)
        acquireWifiLock()
        thread {
            val result = BoosterUtils.boost(this, gamePackage)
            lastBoostFreedMb += result.freedMb
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        showSessionSummary()
        DndController.revert(this)
        releaseWifiLock()
        removePanel()
        bubbleView?.let { windowManager.removeView(it) }
        bubbleView = null
    }

    private fun showSessionSummary() {
        val minutes = ((System.currentTimeMillis() - sessionStartMs) / 60000).coerceAtLeast(0)
        android.widget.Toast.makeText(
            this,
            "Session ended: ${minutes} min, ~${lastBoostFreedMb} MB freed",
            android.widget.Toast.LENGTH_LONG
        ).show()
    }

    // ---------- Bubble ----------

    private fun addBubble() {
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_bubble, null)
        bubbleView = view

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 0
        params.y = 200
        bubbleParams = params

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false

        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    windowManager.updateViewLayout(view, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) v.performClick()
                    true
                }
                else -> false
            }
        }
        view.setOnClickListener { setExpanded(true) }

        windowManager.addView(view, params)
    }

    // ---------- Panel ----------

    private fun setExpanded(show: Boolean) {
        expanded = show
        handler.removeCallbacks(collapseOnIdle)
        if (show) {
            if (panelView == null) addPanel()
            bubbleView?.visibility = View.GONE
            updateStats()
            scheduleAutoCollapse()
        } else {
            removePanel()
            bubbleView?.visibility = View.VISIBLE
        }
    }

    private fun addPanel() {
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_panel, null)
        panelView = view

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = bubbleParams?.x ?: 0
        params.y = bubbleParams?.y ?: 200

        view.findViewById<View>(R.id.btnCollapse).setOnClickListener { setExpanded(false) }

        view.findViewById<View>(R.id.btnBoost).setOnClickListener {
            resetAutoCollapse()
            val resultView = view.findViewById<TextView>(R.id.tvBoostResult)
            thread {
                val result = BoosterUtils.boost(this, gamePackage)
                lastBoostFreedMb += result.freedMb
                handler.post {
                    resultView.visibility = View.VISIBLE
                    resultView.text = if (result.consideredCount == 0) {
                        "No recent background apps found to target (last hour)"
                    } else {
                        "Freed ~${result.freedMb} MB · attempted ${result.closedCount}/${result.consideredCount}" +
                            (if (result.skippedSystemCount > 0) " (skipped ${result.skippedSystemCount} system)" else "")
                    }
                    updateStats()
                }
            }
        }

        val dndToggle = view.findViewById<ToggleButton>(R.id.toggleDnd)
        dndToggle.isChecked = DndController.isDndOn(this)
        dndToggle.setOnClickListener {
            resetAutoCollapse()
            if (!DndController.hasAccess(this)) {
                dndToggle.isChecked = false
                return@setOnClickListener
            }
            if (dndToggle.isChecked) DndController.enable(this) else DndController.revert(this)
        }

        val wifiToggle = view.findViewById<ToggleButton>(R.id.toggleWifiLock)
        wifiToggle.isChecked = wifiLock?.isHeld == true
        wifiToggle.setOnClickListener {
            resetAutoCollapse()
            if (wifiToggle.isChecked) acquireWifiLock() else releaseWifiLock()
        }

        view.findViewById<View>(R.id.btnBatteryExempt).setOnClickListener {
            resetAutoCollapse()
            requestBatteryExemption()
        }

        view.findViewById<View>(R.id.btnDataUsage).setOnClickListener {
            resetAutoCollapse()
            openDataUsageSettings()
        }

        view.setOnTouchListener { _, _ -> resetAutoCollapse(); false }

        windowManager.addView(view, params)
    }

    private fun removePanel() {
        panelView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        panelView = null
    }

    // ---------- Jitter/stutter reduction ----------

    /**
     * Holds the Wi-Fi radio in low-latency (API 29+) or high-performance (older) mode so it
     * doesn't cycle into power-save between packets, a real, documented source of periodic
     * latency spikes on Android. Only affects this device's own radio behavior — it cannot
     * touch routing, so it does nothing for latency introduced upstream of the phone.
     * No-op if the device is on mobile data, since the lock only applies to Wi-Fi.
     */
    private fun acquireWifiLock() {
        if (wifiLock?.isHeld == true) return
        try {
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            val lockType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            else
                @Suppress("DEPRECATION") WifiManager.WIFI_MODE_FULL_HIGH_PERF
            val lock = wm.createWifiLock(lockType, "GameOverlay:WifiLock")
            lock.setReferenceCounted(false)
            lock.acquire()
            wifiLock = lock
        } catch (_: Exception) {
            // Some OEM Wi-Fi stacks refuse this lock type; fail quietly rather than crash the overlay.
        }
    }

    private fun releaseWifiLock() {
        wifiLock?.let { if (it.isHeld) it.release() }
        wifiLock = null
    }

    /**
     * Shows the system dialog to exempt the selected GAME (not this app) from battery
     * optimization/Doze, so its background network access isn't throttled during play.
     * Requires a specific package, so this does nothing if we haven't detected a game yet.
     */
    private fun requestBatteryExemption() {
        val target = gamePackage
        if (target == null) {
            Toast.makeText(this, "No game detected yet", Toast.LENGTH_SHORT).show()
            return
        }
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(target)) {
            Toast.makeText(this, "Already exempted from battery optimization", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
            data = Uri.parse("package:$target")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "Couldn't open battery settings for this app", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Deep-links to the system Data Usage screen. There's no API for one app to restrict
     * another app's background data directly — this just gets the user one tap from doing
     * it manually for whatever's competing with the game for bandwidth.
     */
    private fun openDataUsageSettings() {
        val intent = Intent(Settings.ACTION_DATA_USAGE_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(intent)
            Toast.makeText(this, "Tap an app there to restrict its background data", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Couldn't open data usage settings", Toast.LENGTH_SHORT).show()
        }
    }

    private fun scheduleAutoCollapse() {
        handler.postDelayed(collapseOnIdle, AUTO_COLLAPSE_MS)
    }

    private fun resetAutoCollapse() {
        handler.removeCallbacks(collapseOnIdle)
        scheduleAutoCollapse()
    }

    // ---------- Stats ----------

    private fun updateStats() {
        val view = panelView ?: return
        val freeMb = BoosterUtils.freeRamMb(this)
        view.findViewById<TextView>(R.id.tvRam).text = "RAM free: $freeMb MB"
        view.findViewById<TextView>(R.id.tvNetwork).text = "Network: ${NetworkMonitor.connectionType(this)}"
        view.findViewById<TextView>(R.id.tvBattery).text = "Battery: ${batteryPercent()}%"

        val pingView = view.findViewById<TextView>(R.id.tvPing)
        pingView.text = "Ping: measuring…"
        // Generation guard: updateStats() re-fires on a fixed interval while the
        // probe below sleeps between pings, so overlapping probe threads are
        // guaranteed — the stale one must lose and stay silent.
        val generation = ++pingGeneration
        thread {
            val stats = NetworkMonitor.measurePingStats()
            handler.post {
                if (generation != pingGeneration) return@post
                pingView.text = when {
                    !stats.reachable ->
                        "Ping: timed out (${stats.probesSent - stats.probesOk}/${stats.probesSent} probes failed)"
                    else ->
                        "Ping: ${stats.avgMs} ms avg \u00B7 jitter ${stats.jitterMs} ms \u00B7 loss ${stats.lossPercent}% (to 1.1.1.1, not the game)"
                }
            }
        }
    }

    private fun batteryPercent(): Int {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    // ---------- Notification ----------

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Overlay active", NotificationManager.IMPORTANCE_MIN
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Game Overlay active")
            .setContentText("Tap the bubble for stats")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
    }

    companion object {
        const val EXTRA_GAME_PACKAGE = "extra_game_package"
        private const val CHANNEL_ID = "overlay_channel"
        private const val NOTIF_ID = 1002
        private const val STATS_INTERVAL_MS = 3000L
        private const val AUTO_COLLAPSE_MS = 12000L
    }
}
