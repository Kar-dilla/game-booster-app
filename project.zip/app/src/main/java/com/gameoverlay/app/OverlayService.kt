package com.gameoverlay.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.ToggleButton
import androidx.core.app.NotificationCompat
import kotlin.concurrent.thread

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var panelView: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null

    private val handler = Handler(Looper.getMainLooper())
    private var expanded = false
    private var gamePackage: String? = null
    private var sessionStartMs = 0L
    private var lastBoostFreedMb = 0L

    private val statsRunnable = object : Runnable {
        override fun run() {
            if (expanded) updateStats()
            handler.postDelayed(this, STATS_INTERVAL_MS)
        }
    }

    private val collapseOnIdle = Runnable { setExpanded(false) }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        startForeground(NOTIF_ID, buildNotification())
        sessionStartMs = System.currentTimeMillis()
        addBubble()
        handler.post(statsRunnable)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        gamePackage = intent?.getStringExtra(EXTRA_GAME_PACKAGE) ?: gamePackage
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        showSessionSummary()
        DndController.revert(this)
        removePanel()
        bubbleView?.let { windowManager.removeView(it) }
        bubbleView = null
    }

    private fun showSessionSummary() {
        val minutes = ((System.currentTimeMillis() - sessionStartMs) / 60000).coerceAtLeast(0)
        android.widget.Toast.makeText(
            this,
            "Session ended: ${minutes} min, ~${lastBoostFreedMb} MB freed",
            android.widget.Toast.LENGTH_LONG
        ).show()
    }

    // ---------- Bubble ----------

    private fun addBubble() {
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_bubble, null)
        bubbleView = view

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 0
        params.y = 200
        bubbleParams = params

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false

        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    windowManager.updateViewLayout(view, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) v.performClick()
                    true
                }
                else -> false
            }
        }
        view.setOnClickListener { setExpanded(true) }

        windowManager.addView(view, params)
    }

    // ---------- Panel ----------

    private fun setExpanded(show: Boolean) {
        expanded = show
        handler.removeCallbacks(collapseOnIdle)
        if (show) {
            if (panelView == null) addPanel()
            bubbleView?.visibility = View.GONE
            updateStats()
            scheduleAutoCollapse()
        } else {
            removePanel()
            bubbleView?.visibility = View.VISIBLE
        }
    }

    private fun addPanel() {
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_panel, null)
        panelView = view

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = bubbleParams?.x ?: 0
        params.y = bubbleParams?.y ?: 200

        view.findViewById<View>(R.id.btnCollapse).setOnClickListener { setExpanded(false) }

        view.findViewById<View>(R.id.btnBoost).setOnClickListener {
            resetAutoCollapse()
            val resultView = view.findViewById<TextView>(R.id.tvBoostResult)
            thread {
                val result = BoosterUtils.boost(this, gamePackage)
                lastBoostFreedMb += result.freedMb
                handler.post {
                    resultView.visibility = View.VISIBLE
                    resultView.text = if (result.consideredCount == 0) {
                        "No recent background apps found to target (last hour)"
                    } else {
                        "Freed ~${result.freedMb} MB · attempted ${result.closedCount}/${result.consideredCount}" +
                            (if (result.skippedSystemCount > 0) " (skipped ${result.skippedSystemCount} system)" else "")
                    }
                    updateStats()
                }
            }
        }

        val dndToggle = view.findViewById<ToggleButton>(R.id.toggleDnd)
        dndToggle.isChecked = DndController.isDndOn(this)
        dndToggle.setOnClickListener {
            resetAutoCollapse()
            if (!DndController.hasAccess(this)) {
                dndToggle.isChecked = false
                return@setOnClickListener
            }
            if (dndToggle.isChecked) DndController.enable(this) else DndController.revert(this)
        }

        view.setOnTouchListener { _, _ -> resetAutoCollapse(); false }

        windowManager.addView(view, params)
    }

    private fun removePanel() {
        panelView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        panelView = null
    }

    private fun scheduleAutoCollapse() {
        handler.postDelayed(collapseOnIdle, AUTO_COLLAPSE_MS)
    }

    private fun resetAutoCollapse() {
        handler.removeCallbacks(collapseOnIdle)
        scheduleAutoCollapse()
    }

    // ---------- Stats ----------

    private fun updateStats() {
        val view = panelView ?: return
        val freeMb = BoosterUtils.freeRamMb(this)
        view.findViewById<TextView>(R.id.tvRam).text = "RAM free: $freeMb MB"
        view.findViewById<TextView>(R.id.tvNetwork).text = "Network: ${NetworkMonitor.connectionType(this)}"
        view.findViewById<TextView>(R.id.tvBattery).text = "Battery: ${batteryPercent()}%"

        val pingView = view.findViewById<TextView>(R.id.tvPing)
        pingView.text = "Ping: measuring…"
        thread {
            val ms = NetworkMonitor.pingMs()
            handler.post {
                pingView.text = if (ms >= 0) "Ping: ${ms} ms (to reference server, not the game)" else "Ping: timed out"
            }
        }
    }

    private fun batteryPercent(): Int {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    // ---------- Notification ----------

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Overlay active", NotificationManager.IMPORTANCE_MIN
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Game Overlay active")
            .setContentText("Tap the bubble for stats")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
    }

    companion object {
        const val EXTRA_GAME_PACKAGE = "extra_game_package"
        private const val CHANNEL_ID = "overlay_channel"
        private const val NOTIF_ID = 1002
        private const val STATS_INTERVAL_MS = 3000L
        private const val AUTO_COLLAPSE_MS = 12000L
    }
}
